## GiasBinaryButtonGroupTemplateComponent (`gias-binary-button-group-template`)

### Description
Binary button group bound to a boolean reactive form control, rendered as two buttons (Yes/No) and synchronized with the underlying `FormControl`.

### Inputs

| **Name**              | **Type**    | **Description**                                                                                      |
| --------------------- | ----------- | ---------------------------------------------------------------------------------------------------- |
| `value`               | `boolean`   | Current boolean value of the control. Kept in sync with the bound `FormControl`.                    |
| `giasFormControlName` | `string`    | Name of the control in the parent `FormGroup`.                                                      |
| `disabledsibutton`    | `boolean`   | If `true`, disables the "Yes" button. Automatically managed when the control is disabled.           |
| `disablednobutton`    | `boolean`   | If `true`, disables the "No" button. Automatically managed when the control is disabled.            |
| `silabel`             | `string`    | Label for the "Yes" button.                                                                         |
| `nolabel`             | `string`    | Label for the "No" button.                                                                          |

### Outputs

| **Name**      | **Type**        | **Description**                                  |
| ------------- | --------------- | ------------------------------------------------ |
| `valueChange` | `EventEmitter<boolean>` | Emits the new value when the selection changes. |

### Example

```html
<form [formGroup]="form">
  <gias-binary-button-group-template
    giasFormControlName="isActive"
    [silabel]="'Yes'"
    [nolabel]="'No'"
    (valueChange)="onActiveChange($event)">
  </gias-binary-button-group-template>
</form>
```

```ts
form = this.fb.group({
  isActive: [false]
});

onActiveChange(val: boolean) {
  console.log('Active changed:', val);
}
```

---

## GiasButtonGroupTemplateComponent (`gias-button-group-template`)

### Description
Wrapper around Kendo ButtonGroup that binds a selection (single or multiple) to a reactive form control.

### Inputs

| **Name**              | **Type**            | **Description**                                                                                             |
| --------------------- | ------------------- | ----------------------------------------------------------------------------------------------------------- |
| `name`                | `string`           | HTML name/id for the group.                                                                                |
| `value`               | `any`              | Current selected value (or values). Kept in sync with the bound `FormControl`.                             |
| `giasFormControlName` | `string`           | Name of the control in the parent `FormGroup`.                                                             |
| `isdisabled`          | `boolean`          | Disables the button group.                                                                                 |
| `listItems`           | `Array<any>`       | Items rendered as buttons.                                                                                 |
| `textField`           | `string`           | Property name used for button text.                                                                        |
| `valueField`          | `string`           | Property name used as value.                                                                               |
| `valuePrimitive`      | `boolean`          | If `true`, the control holds `item[valueField]`; otherwise it holds the whole item.                        |
| `multiple`            | `boolean`          | If `true`, enables multiple selection (`selection = 'multiple'`).                                          |

### Outputs

| **Name**      | **Type**           | **Description**                                                  |
| ------------- | ------------------ | ---------------------------------------------------------------- |
| `valueChange` | `EventEmitter<any>` | Emits the selected item (or items) when selection changes.       |

### Example

```html
<form [formGroup]="form">
  <gias-button-group-template
    giasFormControlName="status"
    [listItems]="statusOptions"
    textField="label"
    valueField="value"
    [multiple]="false"
    (valueChange)="onStatusChange($event)">
  </gias-button-group-template>
</form>
```

```ts
statusOptions = [
  { label: 'Open', value: 'OPEN' },
  { label: 'Closed', value: 'CLOSED' }
];

form = this.fb.group({
  status: ['OPEN']
});
```

---

## GiasCheckboxTemplateComponent (`gias-checkbox-template`)

### Description
Checkbox template bound to a boolean value and master service styling; optionally connected to a reactive form control.

### Inputs

| **Name**              | **Type**    | **Description**                                                |
| --------------------- | ----------- | -------------------------------------------------------------- |
| `name`                | `string`    | Name/label of the checkbox.                                   |
| `value`               | `boolean`   | Checked state; defaults to `false` if `undefined`.            |
| `isDisabled`          | `boolean`   | If `true`, disables the checkbox.                             |
| `giasFormControlName` | `string`    | Optional form control name to integrate with a `FormGroup`.   |

### Outputs

| **Name**      | **Type**                 | **Description**                               |
| ------------- | ------------------------ | --------------------------------------------- |
| `valueChange` | `EventEmitter<boolean>`  | Emits the new checked state on user changes.  |

### Example

```html
<gias-checkbox-template
  name="AcceptTerms"
  [(value)]="acceptTerms"
  (valueChange)="onAcceptChange($event)">
</gias-checkbox-template>
```

```ts
acceptTerms = false;
```

---

## GiasCodiceTemplateComponent (`gias-codice-template`)

### Description
Template for selecting and displaying a `Codice` (code/description pair) with optional date range handling.

### Inputs

| **Name**        | **Type**      | **Description**                                             |
| --------------- | ------------- | ----------------------------------------------------------- |
| `codice`        | `Codice`      | Current selected code object.                               |
| `lista_codici`  | `Array<any>`  | Available codes to choose from.                             |
| `text_field`    | `string`      | Property used for display text.                             |
| `value_field`   | `string`      | Property used as the code value.                            |
| `dateControl`   | `boolean`     | Enables associated date controls when `true`.               |
| `formEnable`    | `boolean`     | Toggles enabled/disabled state of the inner form UI.        |

### Outputs

| **Name**       | **Type**              | **Description**                                |
| -------------- | --------------------- | ---------------------------------------------- |
| `changeValue`  | `EventEmitter<any>`   | Emits when the selected code or dates change.  |

### Example

```html
<gias-codice-template
  [codice]="currentCode"
  [lista_codici]="codes"
  text_field="descrizione"
  value_field="codice"
  [dateControl]="true"
  (changeValue)="onCodeChange($event)">
</gias-codice-template>
```

---

## GiasDataTemplateComponent (`gias-data-template`)

### Description
Date-only picker template using Kendo DateTimePicker bound to a reactive form control, with support for min/max dates and special null values.

### Inputs

| **Name**              | **Type**                    | **Description**                                                                 |
| --------------------- | --------------------------- | ------------------------------------------------------------------------------- |
| `name`                | `string`                   | Label/name of the date field.                                                  |
| `value`               | `Date`                     | Current value; converted from string if needed.                                |
| `nullValue`           | `Date`                     | Special value treated as "empty" and rendered as blank.                        |
| `startValue`          | `Date`                     | Minimum selectable date (defaults to `AGRODATAINIZIO`).                        |
| `endValue`            | `Date`                     | Maximum selectable date (defaults to `AGRODATAFINE`).                          |
| `obligatory`          | `boolean`                  | Marks the control as required in the UI.                                       |
| `isDisabled`          | `boolean`                  | Disables the input.                                                            |
| `giasFormControlName` | `string`                   | Name of the bound `FormControl`.                                               |
| `parentGroup`         | `FormGroup`                | Parent form group (if not using `FormGroupDirective`).                         |
| `readOnlyInput`       | `boolean`                  | If `true`, makes the text input read-only.                                     |
| `format`              | `FormatSettings`           | Display and input format (default: `dd/MM/yyyy`).                              |
| `disabledDates`       | `(date: Date) => boolean`  | Predicate to disable specific dates.                                           |
| `inlineLabels`        | `Boolean`                  | If `true`, applies inline label styling.                                       |

### Outputs

| **Name**      | **Type**                 | **Description**                                  |
| ------------- | ------------------------ | ------------------------------------------------ |
| `valueChange` | `EventEmitter<Date>`     | Emits when the date value changes.              |
| `onBlur`      | `EventEmitter<void>`     | Emits when the input loses focus.               |

### Example

```html
<form [formGroup]="form">
  <gias-data-template
    name="Start date"
    giasFormControlName="startDate"
    [obligatory]="true"
    [inlineLabels]="true"
    (valueChange)="onStartDateChange($event)">
  </gias-data-template>
</form>
```

```ts
form = this.fb.group({
  startDate: [new Date()]
});
```

---

## GiasDateTimePickerTemplateComponent (`gias-date-time-picker-template`)

### Description
Date-time picker template bound to a reactive form control with debounced year-adjustment logic and optional disabled dates list.

### Inputs

| **Name**                    | **Type**          | **Description**                                                        |
| --------------------------- | ----------------- | ---------------------------------------------------------------------- |
| `name`                      | `string`         | Label/name of the field.                                              |
| `value`                     | `Date`           | Current date-time value.                                              |
| `nullValue`                 | `Date`           | Special "empty" value.                                                |
| `startValue`                | `Date`           | Minimum allowed date-time (default `AGRODATAINIZIO`).                 |
| `endValue`                  | `Date`           | Maximum allowed date-time (default `AGRODATAFINE`).                   |
| `obligatory`                | `boolean`        | Marks the control as required in UI.                                  |
| `isDisabled`                | `boolean`        | Disables the input.                                                   |
| `giasFormControlName`       | `string`         | Name of the bound `FormControl`.                                      |
| `parentGroup`               | `FormGroup`      | Parent form group (optional).                                         |
| `readOnlyInput`             | `boolean`        | If `true`, disables manual text editing.                              |
| `disabledDatesValidation`   | `boolean`        | Enables/disables validation related to `disabledDates`.               |
| `disabledDates`             | `Date[]`         | Array of specific disabled dates.                                     |

### Outputs

| **Name**      | **Type**               | **Description**                                  |
| ------------- | ---------------------- | ------------------------------------------------ |
| `valueChange` | `EventEmitter<Date>`   | Emits when the date-time value changes.         |
| `onBlur`      | `EventEmitter<void>`   | Emits when the component loses focus.           |

### Example

```html
<form [formGroup]="form">
  <gias-date-time-picker-template
    name="Appointment"
    giasFormControlName="appointment"
    [disabledDates]="holidays"
    (valueChange)="onAppointmentChange($event)">
  </gias-date-time-picker-template>
</form>
```

```ts
form = this.fb.group({
  appointment: [new Date()]
});

holidays = [new Date(2026, 0, 1)];
```

---

## GiasDialogComponent (`gias-dialog`)

### Description
Simple dialog content component used in conjunction with `GiasDialogService`, supporting customizable title, content, type, and height handling.

### Inputs

| **Name**      | **Type**            | **Description**                                                           |
| ------------- | ------------------- | ------------------------------------------------------------------------- |
| `content`     | `string`           | HTML/text content of the dialog body.                                    |
| `title`       | `string`           | Dialog title text.                                                        |
| `dialogType`  | `string`           | Optional dialog type (e.g. info, warning) for styling.                    |
| `height`      | `number \| string` | Explicit dialog height or `'auto'`; used by `CalculateHeight()` helper.  |

### Outputs

None directly on the component; interactions are handled through the associated service and Kendo window events.

### Example

```html
<ng-template kendoWindowContainer></ng-template>
<!-- dialogs opened via GiasDialogService -->
```

```ts
this.giasDialogService.open({
  title: 'Confirm',
  content: 'Do you want to proceed?'
});
```

---

## GiasDropDownTemplateComponent (`gias-drop-down-template`)

### Description
Kendo `DropDownList` template integrated with reactive forms and optional server-side filtering.

### Inputs

| **Name**                        | **Type**                                   | **Description**                                                                                               |
| ------------------------------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------------------- |
| `id`                            | `string`                                  | Identifier for events coming from this dropdown.                                                              |
| `name`                          | `string`                                  | Label/name of the dropdown.                                                                                   |
| `value`                         | `any`                                     | Current selected value.                                                                                       |
| `listItems`                     | `Array<any>`                              | List of options.                                                                                              |
| `itemDisabledFn`                | `(i: any) => boolean`                     | Function to determine disabled items.                                                                         |
| `obligatory`                    | `boolean`                                 | Marks as required in the UI.                                                                                  |
| `clearButton`                   | `boolean`                                 | Enables clear button.                                                                                         |
| `isDisabled`                    | `boolean`                                 | Disables the dropdown.                                                                                        |
| `textField`                     | `string`                                  | Property used for option display.                                                                             |
| `valueField`                    | `string`                                  | Property used as the bound value.                                                                             |
| `filterable`                    | `boolean`                                 | Enables filter box (default `true`).                                                                          |
| `defaultItem`                   | `any`                                     | Default "empty" item.                                                                                         |
| `giasFormControlName`           | `string`                                  | Name of the `FormControl` in the parent form.                                                                 |
| `parentGroup`                   | `FormGroup`                               | Optional parent form group.                                                                                   |
| `parentFormControl`             | `FormControl`                             | Direct reference to the bound form control.                                                                   |
| `valuePrimitive`                | `boolean`                                 | If `true`, value is `item[valueField]`; otherwise the full object.                                           |
| `applyMinimumFilterLength`      | `boolean`                                 | If `true`, only filters when input length ≥ `MinimumFilterLength`.                                           |
| `MinimumFilterLength`           | `number`                                  | Minimum length for filter text.                                                                               |
| `ddlServerFiltering`            | `boolean`                                 | Enables server-side filtering.                                                                                |
| `loadFunctionddlServerFiltering`| `(filter: string) => Observable<any>`     | Callback used to load items from server on filter change.                                                     |
| `virtual`                       | `any`                                     | Virtualization settings for large lists.                                                                      |

### Outputs

| **Name**       | **Type**                               | **Description**                                                                   |
| -------------- | -------------------------------------- | --------------------------------------------------------------------------------- |
| `valueChange`  | `EventEmitter<DropdownListEvent>`      | Emits when the value changes (id, type, data, listItems).                        |
| `open`         | `EventEmitter<GiasDropDownTemplateComponent>` | Emits when the dropdown is opened.                                               |
| `filterChange` | `EventEmitter<any>`                    | Emits when the filter text changes.                                              |

### Example

```html
<form [formGroup]="form">
  <gias-drop-down-template
    id="cityDdl"
    name="City"
    giasFormControlName="city"
    [listItems]="cities"
    textField="name"
    valueField="id"
    (valueChange)="onCityChange($event)">
  </gias-drop-down-template>
</form>
```

---

## GiasDropDownTemplateSComponent (`gias-drop-down-template-s`)

### Description
Specialized dropdown template with optional info tooltip, customizable popup, and integration with `GiasDropDownTemplateService`.

### Inputs

| **Name**                        | **Type**                     | **Description**                                                         |
| ------------------------------- | ---------------------------- | ----------------------------------------------------------------------- |
| `id`                            | `string`                    | Identifier for dropdown instance.                                       |
| `name`                          | `string`                    | Label/name.                                                             |
| `value`                         | `any`                       | Current value.                                                          |
| `listItems`                     | `Array<any>`                | Options list.                                                           |
| `obligatory`                    | `boolean`                   | Required in UI.                                                         |
| `clearButton`                   | `boolean`                   | Enables clear button.                                                   |
| `isDisabled`                    | `boolean`                   | Disables input.                                                         |
| `textField`                     | `string`                    | Display property (default `'descrizione'`).                             |
| `valueField`                    | `string`                    | Value property (default `'codice'`).                                    |
| `filterable`                    | `boolean`                   | Enables filtering.                                                      |
| `defaultItem`                   | `any`                       | Default empty item.                                                     |
| `giasFormControlName`           | `string`                    | Name of bound `FormControl`.                                           |
| `parentGroup`                   | `FormGroup`                 | Parent form group.                                                      |
| `parentFormControl`             | `FormControl`               | Reference to control.                                                   |
| `valuePrimitive`                | `boolean`                   | If `true`, control holds primitive value.                               |
| `applyMinimumFilterLength`      | `boolean`                   | Enables minimum filter length logic.                                    |
| `MinimumFilterLength`           | `number`                    | Minimum filter text length.                                             |
| `ddlServerFiltering`            | `boolean`                   | Enables server-side filtering.                                          |
| `loadFunctionddlServerFiltering`| `(filter: string) => Observable<any>` | Server-side loader.                                         |
| `popupSettings`                 | `PopupSettings`             | Popup configuration (default `{ width: 'auto' }`).                      |
| `hasInfo`                       | `boolean`                   | Shows an additional info icon when `true`.                              |
| `infoTitle`                     | `string`                    | Tooltip/info title text.                                                |
| `isRequired`                    | `boolean`                   | Indicates required state for validation/star.                           |
| `showStar`                      | `boolean`                   | Controls visibility of required star.                                   |
| `virtual`                       | `any`                       | Virtualization settings.                                                |

### Outputs

| **Name**       | **Type**                                   | **Description**                                |
| -------------- | ------------------------------------------ | ---------------------------------------------- |
| `open`         | `EventEmitter<GiasDropDownTemplateSComponent>` | Emits when dropdown is opened.            |
| `filterChange` | `EventEmitter<any>`                        | Emits when filter text changes.                |

### Example

```html
<gias-drop-down-template-s
  id="province"
  name="Province"
  giasFormControlName="province"
  [listItems]="provinces"
  [hasInfo]="true"
  infoTitle="Select your province">
</gias-drop-down-template-s>
```

---

## GiasExpansionPanelComponent (`gias-expansionpanel`)

### Description
Wrapper around Kendo ExpansionPanel with support for persisted expand/collapse state via cookies (per-user and per-route).

### Inputs

| **Name**          | **Type**     | **Description**                                                                 |
| ----------------- | ------------ | ------------------------------------------------------------------------------- |
| `id`              | `string`    | Unique identifier used as key for storing cookie state.                        |
| `disabled`        | `boolean`   | Disables the panel.                                                             |
| `isExpanded`      | `boolean`   | Initial expanded/collapsed state.                                              |
| `willStoreCookies`| `boolean`   | If `true`, stores and restores state from cookies.                             |

### Outputs

| **Name**  | **Type**                              | **Description**                                         |
| --------- | ------------------------------------- | ------------------------------------------------------- |
| `action`  | `EventEmitter<ExpansionPanelActionEvent>` | Emits Kendo expand/collapse action events.         |

### Example

```html
<gias-expansionpanel id="detailsPanel" [isExpanded]="true">
  <kendo-expansionpanel>
    <ng-template kendoExpansionPanelTitle>
      <div headerContent><strong>Details</strong></div>
    </ng-template>
    <ng-template kendoExpansionPanelContent>
      <!-- panel content -->
    </ng-template>
  </kendo-expansionpanel>
</gias-expansionpanel>
```

---

## GiasFormErrorVisualizerComponent (`gias-form-error-visualizer`)

### Description
Global form error visualizer; subscribes to `GiasFormErrorVisualizerService` and renders an error tree with ability to scroll to invalid controls.

### Inputs

| **Name** | **Type**    | **Description**                               |
| -------- | ----------- | --------------------------------------------- |
| `form`   | `FormGroup` | Form to visualize errors for.                 |

### Outputs

None directly; navigation is handled via internal methods.

### Example

```html
<form [formGroup]="form">
  <!-- form fields -->
</form>

<gias-form-error-visualizer [form]="form"></gias-form-error-visualizer>
```

---

## GiasGeneralInputTemplateComponent (`gias-general-input-template`)

### Description
Generic input template that can render different control types (text, textarea, dropdown, checkbox, multiselect, etc.) based on `controlType`, and propagate changes to a reactive form control.

### Inputs

| **Name**              | **Type**                                          | **Description**                                                               |
| --------------------- | ------------------------------------------------- | ----------------------------------------------------------------------------- |
| `id`                  | `string`                                         | Identifier for this template.                                                 |
| `name`                | `string`                                         | Label of the field.                                                           |
| `label`               | `string`                                         | Display label text.                                                           |
| `value`               | `any`                                            | Initial value.                                                                |
| `listItems`           | `Array<BaseCodeDescr \| BaseCodeDescrStr>`       | Options for dropdown/multiselect controls.                                   |
| `controlType`         | `enum_TipoControllo \| number`                   | Type of control to render (text, dropdown, checkbox, etc.).                  |
| `giasFormControlName` | `string`                                         | Name of the bound `FormControl`.                                             |
| `tooltip`             | `string`                                         | Tooltip text.                                                                 |
| `defaultItem`         | `any`                                            | Default option for selection controls.                                       |
| `obligatory`          | `boolean`                                        | Required flag in UI.                                                          |
| `valuePrimitive`      | `boolean`                                        | If `true`, store primitive instead of object.                                |
| `clearButton`         | `boolean`                                        | Show clear button where applicable.                                          |
| `isDisabled`          | `boolean`                                        | Disable the control.                                                          |
| `maxValue`            | `number`                                         | Max numeric value (for numeric controls).                                    |
| `minValue`            | `number`                                         | Min numeric value (for numeric controls).                                    |

### Outputs

| **Name**      | **Type**               | **Description**                          |
| ------------- | ---------------------- | ---------------------------------------- |
| `valueChange` | `EventEmitter<any>`    | Emits when underlying value changes.     |

### Example

```html
<form [formGroup]="form">
  <gias-general-input-template
    name="Category"
    label="Category"
    giasFormControlName="category"
    [controlType]="enum_TipoControllo.MENU_DISCESA"
    [listItems]="categories">
  </gias-general-input-template>
</form>
```

---

## GiasIFrameWindowComponent (`gias-iframe-window`)

### Description
Component that renders an `<iframe>` and exposes a method to post messages to the child window once it is loaded.

### Inputs

| **Name** | **Type** | **Description**                              |
| -------- | -------- | -------------------------------------------- |
| `url`    | `string` | URL to load inside the iframe.              |

### Outputs

None.

### Example

```html
<gias-iframe-window [url]="'https://example.com'"></gias-iframe-window>
```

---

## ListviewComponent (`app-listview`)

### Description
Wrapper for Kendo `ListViewComponent` that exposes reactive streams for data, loading, and item removal; intended for advanced/custom integrations.

### Inputs

| **Name**          | **Type**                            | **Description**                                              |
| ----------------- | ----------------------------------- | ------------------------------------------------------------ |
| `height$`         | `ReplaySubject<number>`             | Stream defining list height.                                 |
| `loading$`        | `ReplaySubject<boolean>`            | Stream controlling loading state.                            |
| `data$`           | `BehaviorSubject<IListViewItem[]>`  | Stream with the list of items.                              |
| `removeDataItem$` | `Subject<{ index: number; deleteCount: number }>` | Requests item removal.                           |
| `resetStates$`    | `Subject<boolean>`                  | Resets item state flags.                                     |
| `showListHeader`  | `(...args) => boolean`              | Predicate to show list header.                               |
| `showAddBtn`      | `(...args) => boolean`              | Predicate for add button visibility.                         |
| `showEditBtn`     | `(...args) => boolean`              | Predicate for edit button visibility.                        |
| `showSaveBtn`     | `(...args) => boolean`              | Predicate for save button visibility.                        |
| `showCancelBtn`   | `(...args) => boolean`              | Predicate for cancel button visibility.                      |
| `showRemoveBtn`   | `(...args) => boolean`              | Predicate for remove button visibility (default `true`).     |
| `showDeleteBtn`   | `(...args) => boolean`              | Predicate for delete button visibility.                      |
| `removeBtnTitle`  | `string`                            | Tooltip/title for remove button.                             |
| `deleteBtnTitle`  | `string`                            | Tooltip/title for delete button.                             |

### Outputs

| **Name**   | **Type**                                  | **Description**                                 |
| ---------- | ----------------------------------------- | ----------------------------------------------- |
| `add`      | `Subject<AddEvent>`                       | Emits when an item is added.                    |
| `edit`     | `Subject<EditEvent>`                      | Emits when an item goes into edit mode.         |
| `save`     | `Subject<SaveEvent>`                      | Emits when an item is saved.                    |
| `cancel`   | `Subject<CancelEvent>`                    | Emits when edit is cancelled.                   |
| `remove`   | `Subject<RemoveEvent>`                    | Emits when item remove is triggered.            |
| `delete`   | `Subject<{ item: IListViewItem; itemIndex: number }>` | Emits when custom delete is triggered. |

### Example

```html
<app-listview
  [data$]="items$"
  [loading$]="loading$"
  [removeDataItem$]="remove$">
</app-listview>
```

---

## GiasDropDownButtonComponent (`app-drop-down-button`)

### Description
Wrapper around Kendo `DropDownButtonComponent` with FontAwesome icon support and configurable button/popup options.

### Inputs

| **Name**          | **Type**                           | **Description**                                   |
| ----------------- | ---------------------------------- | ------------------------------------------------- |
| `item`            | `any`                              | Context item associated with this button.         |
| `iconDefinition`  | `IconDefinition`                   | FontAwesome icon (default `faEllipsis`).          |
| `arrowIcon`       | `boolean`                          | Shows arrow icon when `true`.                     |
| `buttonAttributes`| `{ [key: string]: string }`        | Additional HTML attributes for the button.        |
| `buttonClass`     | `any`                              | CSS class(es) for the button.                     |
| `data`            | `GiasDropDownButtonActionItem[]`   | List of actions shown in the dropdown.           |
| `disabled`        | `boolean`                          | Disables the button.                              |
| `fillMode`        | `ButtonFillMode`                   | Kendo button fill mode.                           |
| `icon`            | `string`                           | Kendo icon name.                                  |
| `iconClass`       | `string`                           | CSS class for icon.                               |
| `imageUrl`        | `string`                           | Image URL for button.                             |
| `popupSettings`   | `PopupSettings`                    | Popup configuration.                              |
| `rounded`         | `ButtonRounded`                    | Button border radius.                             |
| `size`            | `ButtonSize`                       | Button size.                                      |
| `svgIcon`         | `SVGIcon`                          | Kendo SVG icon.                                   |
| `tabIndex`        | `number`                           | Tab index.                                        |
| `textField`       | `string`                           | Field to use for action text.                     |
| `themeColor`      | `ButtonThemeColor`                 | Button theme color.                               |

### Outputs

| **Name** | **Type**                         | **Description**                          |
| -------- | -------------------------------- | ---------------------------------------- |
| `close`  | `EventEmitter<PreventableEvent>` | Emits when popup is closed.              |
| `itemClick` | `EventEmitter<any>`          | Emits when an action item is clicked.    |
| `blur`   | `EventEmitter<any>`             | Emits on blur.                           |
| `focus`  | `EventEmitter<any>`             | Emits on focus.                          |
| `open`   | `EventEmitter<PreventableEvent>`| Emits when popup opens.                  |

### Example

```html
<app-drop-down-button
  [data]="rowActions"
  [item]="row"
  (itemClick)="onRowActionClick($event)">
</app-drop-down-button>
```

---

## GiasInfoTemplateComponent (`gias-info-template`)

### Description
Simple info icon with optional tooltip template.

### Inputs

| **Name**          | **Type**          | **Description**                             |
| ----------------- | ----------------- | ------------------------------------------- |
| `title`           | `string`         | Info title text.                            |
| `size`            | `any`            | Icon size (CSS or logical size).           |
| `tooltipTemplate` | `TemplateRef<any>`| Template used as tooltip content.          |

### Outputs

None.

### Example

```html
<ng-template #infoTpl>
  <p>This field controls advanced options.</p>
</ng-template>

<gias-info-template
  title="More info"
  [tooltipTemplate]="infoTpl">
</gias-info-template>
```

---

## GiasKendoWindowTemplates (`gias-kendo-window-templates`)

### Description
Container for kendo window title bar templates, synchronized with `GiasIFrameWindowService` to control window chrome (minimize, maximize, restore, close) and title.

### Inputs

None explicit; uses internal subscriptions to `GiasIFrameWindowService`.

### Outputs

None.

### Example

```html
<gias-kendo-window-templates></gias-kendo-window-templates>
<!-- Service wires the template into a kendo Window instance -->
```

---

## GiasMasterSpinnerComponent (`gias-master-spinner`)

### Description
Global loading spinner component to indicate application-level busy state.

### Inputs / Outputs

None directly; visibility is typically controlled by including or excluding the component and/or CSS.

### Example

```html
<gias-master-spinner *ngIf="isLoading"></gias-master-spinner>
```

---

## GiasMultiColumnComboboxTemplateComponent (`gias-multi-column-combobox-template`)

### Description
Multi-column Kendo ComboBox template with optional server filtering, virtualization, custom item templates, and integration with `MultiColumnComboboxService`.

### Inputs

| **Name**                                | **Type**                        | **Description**                                                           |
| --------------------------------------- | ------------------------------- | ------------------------------------------------------------------------- |
| `id`                                    | `string`                       | Identifier.                                                               |
| `name`                                  | `string`                       | Label.                                                                    |
| `value`                                 | `any`                          | Current selected value.                                                   |
| `listItems`                             | `Array<any>`                   | Items to display.                                                         |
| `obligatory`                            | `boolean`                      | Required flag.                                                            |
| `clearButton`                           | `boolean`                      | Show clear button (default `true`).                                      |
| `isDisabled`                            | `boolean`                      | Disable input.                                                            |
| `textField`                             | `string`                       | Display field (default `'descrizione'`).                                  |
| `valueField`                            | `string`                       | Value field (default `'codice'`).                                         |
| `filterable`                            | `boolean`                      | Enables filtering.                                                        |
| `giasFormControlName`                   | `string`                       | Name of bound `FormControl`.                                             |
| `parentGroup`                           | `FormGroup`                    | Parent group.                                                             |
| `parentFormControl`                     | `FormControl`                  | Direct form control reference.                                            |
| `valuePrimitive`                        | `boolean`                      | If `true`, store `valueField` value.                                     |
| `applyMinimumFilterLength`              | `boolean`                      | Use minimum filter length.                                                |
| `MinimumFilterLength`                   | `number`                       | Minimum filter text length.                                               |
| `columns`                               | `Array<ColumnCombobox>`        | Column configuration.                                                     |
| `ddlServerFiltering`                    | `boolean`                      | Enables server-side filtering.                                            |
| `popupSettings`                         | `PopupSettings`                | Popup settings.                                                           |
| `class`                                 | `string`                       | CSS class for wrapper.                                                    |
| `loadFunctionMultiColumnComboboxServerFiltering` | `(filter: string) => Observable<any>` | Server loader.                                             |
| `ColumnComboBoxColumnCellTemplate`      | `boolean`                      | Enables custom column cell templates.                                     |
| `readonly`                              | `boolean`                      | Makes input read-only.                                                    |
| `itemTemplate`                          | `TemplateRef<any>`             | Custom item template.                                                     |
| `placeholder`                           | `string`                       | Placeholder text.                                                         |
| `emptyObj`                              | `any`                          | Special empty object for value normalization.                             |
| `allowCustom`                           | `boolean`                      | If `true`, allows custom values.                                         |
| `virtualization`                        | `VirtualizationSettings`       | Virtualization config (page size, item height).                           |

### Outputs

| **Name**       | **Type**                                      | **Description**                                |
| -------------- | --------------------------------------------- | ---------------------------------------------- |
| `open`         | `EventEmitter<GiasMultiColumnComboboxTemplateComponent>` | Emits on open.                      |
| `filterChange` | `EventEmitter<any>`                           | Emits filter string.                           |
| `close`        | `EventEmitter<any>`                           | Emits on close.                                |
| `onclosed`     | `EventEmitter<any>`                           | Emits after close handling completes.          |
| `blur`         | `EventEmitter<any>`                           | Emits on blur.                                 |

### Example

```html
<gias-multi-column-combobox-template
  giasFormControlName="customer"
  [columns]="customerColumns"
  [listItems]="customers"
  textField="name"
  valueField="id">
</gias-multi-column-combobox-template>
```

---

## GiiasMultiselectTemplateSComponent (`gias-multiselect-template-s`)

### Description
Kendo MultiSelect template with optional grouping, server filtering, and integration with `GiasMultiSelectTemplateService`.

### Inputs

| **Name**                    | **Type**            | **Description**                                                   |
| --------------------------- | ------------------- | ----------------------------------------------------------------- |
| `id`                        | `string`           | Identifier.                                                       |
| `name`                      | `string`           | Label.                                                            |
| `value`                     | `Array<any>`       | Current selected values.                                          |
| `listItems`                 | `Array<any>`       | Available options.                                                |
| `obligatory`                | `boolean`          | Required flag.                                                    |
| `clearButton`               | `boolean`          | Show clear button.                                                |
| `isDisabled`                | `boolean`          | Disable input.                                                    |
| `textField`                 | `string`           | Display field.                                                    |
| `valueField`                | `string`           | Value field.                                                      |
| `filterable`                | `boolean`          | Enables filtering.                                                |
| `defaultItem`               | `any`              | Default item.                                                     |
| `giasFormControlName`       | `string`           | Name of bound `FormControl`.                                     |
| `parentGroup`               | `FormGroup`        | Parent group.                                                     |
| `parentFormControl`         | `FormControl`      | Direct control ref.                                               |
| `valuePrimitive`            | `boolean`          | If `true`, control holds primitive values.                        |
| `applyMinimumFilterLength`  | `boolean`          | Enables minimum filter length.                                    |
| `MinimumFilterLength`       | `number`           | Minimum filter characters.                                        |
| `autoClose`                 | `boolean`          | Closes popup automatically after selection.                       |
| `hasInfo`                   | `boolean`          | Enables info indicators.                                          |
| `placeholder`               | `string`           | Placeholder text.                                                 |
| `showRedAsterisk`           | `boolean`          | Shows red asterisk for required.                                  |
| `labelTemplate`             | `TemplateRef<any>` | Custom label template.                                            |
| `popupSettings`             | `PopupSettings`    | Popup configuration.                                              |
| `virtual`                   | `any`              | Virtualization configuration.                                     |
| `groupBy`                   | `boolean`          | If `true`, expects grouped data.                                  |

### Outputs

| **Name**        | **Type**                                | **Description**                               |
| --------------- | --------------------------------------- | --------------------------------------------- |
| `open`          | `EventEmitter<GiiasMultiselectTemplateSComponent>` | Emits when opened.                  |
| `filterChange`  | `EventEmitter<any>`                     | Emits filter string.                          |
| `removeItem`    | `EventEmitter<RemoveTagEvent>`          | Emits when a tag is removed.                  |
| `selectionItem` | `EventEmitter<any>`                     | Emits with the full selected values array.    |

### Example

```html
<gias-multiselect-template-s
  giasFormControlName="roles"
  [listItems]="roles"
  textField="name"
  valueField="id">
</gias-multiselect-template-s>
```

---

## GiasNumericTemplateComponent (`gias-numeric-template`)

### Description
Numeric input template bound to a reactive `FormControl`, with validation visualization and auto-correction on blur.

### Inputs

| **Name**              | **Type**     | **Description**                                                             |
| --------------------- | ------------ | --------------------------------------------------------------------------- |
| `name`                | `string`    | Label.                                                                      |
| `value`               | `number`    | Current numeric value.                                                      |
| `format`              | `string`    | Numeric format string.                                                      |
| `placeholder`         | `string`    | Placeholder text.                                                           |
| `decimals`            | `number`    | Number of decimal places.                                                   |
| `obligatory`          | `boolean`   | Required in UI.                                                             |
| `clearButton`         | `boolean`   | Enables clear button.                                                       |
| `isDisabled`          | `boolean`   | Disables the input.                                                         |
| `readonly`            | `boolean`   | Read-only input flag.                                                       |
| `giasFormControlName` | `string`    | Name of bound `FormControl`.                                               |
| `parentGroup`         | `FormGroup` | Parent group.                                                               |
| `maxValue`            | `number`    | Maximum allowed value (default `Number.MAX_SAFE_INTEGER`).                  |
| `minValue`            | `number`    | Minimum allowed value (default `Number.MIN_SAFE_INTEGER`).                  |
| `errorMsg`            | `string`    | Custom error message.                                                       |
| `autoCorrect`         | `boolean`   | If `true`, auto-corrects out-of-range values.                               |
| `step`                | `number`    | Step for increment/decrement (default `1`).                                 |
| `spinners`            | `boolean`   | Enables spinner buttons.                                                    |
| `changeValueOnScroll` | `boolean`   | If `true`, mouse wheel changes value.                                      |
| `title`               | `string`    | Title/tooltip.                                                              |
| `selectOnFocus`       | `boolean`   | Selects the entire value on focus.                                          |

### Outputs

| **Name**      | **Type**                | **Description**                        |
| ------------- | ----------------------- | -------------------------------------- |
| `valueChange` | `EventEmitter<number>`  | Emits when the numeric value changes.  |
| `onBlur`      | `EventEmitter<void>`    | Emits when the input loses focus.      |
| `onFocus`     | `EventEmitter<void>`    | Emits when the input gains focus.      |

### Example

```html
<gias-numeric-template
  name="Amount"
  giasFormControlName="amount"
  [minValue]="0"
  [maxValue]="1000"
  [decimals]="2">
</gias-numeric-template>
```

---

## GiasPanelBar (`gias-panelbar`)

### Description
Wrapper around Kendo PanelBar item that persists expand state per user/route and supports lazy loading of content.

### Inputs

| **Name**         | **Type**             | **Description**                                                |
| ---------------- | -------------------- | -------------------------------------------------------------- |
| `id`             | `string`            | Unique identifier for cookie key.                             |
| `disabled`       | `boolean`           | Disables the panel.                                           |
| `expand`         | `boolean`           | Current expand state (two-way via `IsExpanded` `BehaviorSubject`). |
| `headerTemplate` | `TemplateRef<any>`  | Header template.                                              |
| `contentTemplate`| `TemplateRef<any>`  | Content template.                                             |
| `willStoreCookies` | `boolean`         | Enables state persistence.                                    |
| `keepItemContent`  | `boolean`         | If `false`, reload content each expand; if `true`, keep once loaded. |
| `loadContent`    | `boolean`           | Controls whether content should be rendered.                  |

### Outputs

| **Name**        | **Type**                    | **Description**                         |
| --------------- | --------------------------- | --------------------------------------- |
| `OnExpandPanel` | `EventEmitter<PanelBarExpandEvent>` | Emits when the panel is expanded. |

### Example

```html
<gias-panelbar
  id="filtersPanel"
  [headerTemplate]="hdr"
  [contentTemplate]="cnt">
</gias-panelbar>

<ng-template #hdr>Filters</ng-template>
<ng-template #cnt>...content...</ng-template>
```

---

## GiasPasswordTemplateComponent (`gias-password-template`)

### Description
Password input template bound to a reactive form control with required/length validators and toggleable visibility.

### Inputs

| **Name**              | **Type**     | **Description**                                      |
| --------------------- | ------------ | ---------------------------------------------------- |
| `name`                | `string`    | Label of the field.                                  |
| `placeholder`         | `string`    | Placeholder text.                                    |
| `obligatory`          | `boolean`   | Adds `Validators.required` when `true`.              |
| `isDisabled`          | `boolean`   | Disables the control.                                |
| `giasFormControlName` | `string`    | Name of bound `FormControl`.                         |
| `parentGroup`         | `FormGroup` | Parent form group (optional, resolved if missing).   |
| `maxlength`           | `number`    | Adds `Validators.maxLength`.                         |
| `minlength`           | `number`    | Adds `Validators.minLength`.                         |

### Outputs

| **Name**      | **Type**                 | **Description**                         |
| ------------- | ------------------------ | --------------------------------------- |
| `valueChange` | `EventEmitter<string>`   | Emits when the password value changes.  |

### Example

```html
<gias-password-template
  name="Password"
  giasFormControlName="password"
  [obligatory]="true"
  [minlength]="8">
</gias-password-template>
```

---

## GiasRadioButtonTemplateComponent (`gias-radio-button-template`)

### Description
Radio button group template bound to a list of `RadioButtonValue` objects.

### Inputs

| **Name**           | **Type**             | **Description**                               |
| ------------------ | -------------------- | --------------------------------------------- |
| `radioButtonValues`| `RadioButtonValue[]` | List of radio options (name, value, enabled). |
| `value`            | `any`                | Current selected value.                        |
| `formEnable`       | `boolean`            | Enables/disables entire group.                 |
| `formControlName`  | `string`             | Optional form control name.                    |

### Outputs

| **Name**      | **Type**              | **Description**                      |
| ------------- | --------------------- | ------------------------------------ |
| `valueChange` | `EventEmitter<any>`   | Emits when selection changes.        |

### Example

```html
<gias-radio-button-template
  [radioButtonValues]="genderOptions"
  [(value)]="gender">
</gias-radio-button-template>
```

---

## GiasSideFiltersTemplateComponent (`gias-side-filters-template`)

### Description
Side drawer template for advanced filters, showing either a custom template or a form-generated list of filter fields.

### Inputs

| **Name**          | **Type**            | **Description**                                                     |
| ----------------- | ------------------- | ------------------------------------------------------------------- |
| `filtersTemplate` | `TemplateRef<any>`  | Custom template for filter content.                                 |
| `filtersFormGroup`| `FormGroup`         | Form group containing `giasGenericFormControl` filter controls.     |

### Outputs

| **Name** | **Type**            | **Description**                         |
| -------- | ------------------- | --------------------------------------- |
| `search` | `Subject<void>`     | Emits when the search/apply button is pressed. |

### Example

```html
<gias-side-filters-template [filtersTemplate]="filtersTpl" (search)="applyFilters()">
</gias-side-filters-template>

<ng-template #filtersTpl>
  <!-- filter controls here -->
</ng-template>
```

---

## GiasSwitchTemplateComponent (`gias-switch-template`)

### Description
Boolean switch template with customizable labels and integration with the master service styling.

### Inputs

| **Name**          | **Type**   | **Description**                           |
| ----------------- | ---------- | ----------------------------------------- |
| `name`            | `string`  | Field label.                              |
| `value`           | `boolean` | Checked state (defaults to `false`).      |
| `placeholder`     | `string`  | Placeholder/tooltip.                      |
| `isDisabled`      | `boolean` | Disables the switch.                      |
| `giasFormControlName` | `string` | Optional form control name.             |
| `siLabel`         | `string`  | Label for the "on" state.                 |
| `noLabel`         | `string`  | Label for the "off" state.                |
| `isBlue`          | `boolean` | Uses alternative blue theme when `true`.  |
| `hideLabel`       | `boolean` | Hides the labels.                         |
| `hideformfield`   | `boolean` | Hides the outer form field wrapper.       |

### Outputs

| **Name**      | **Type**                 | **Description**                       |
| ------------- | ------------------------ | ------------------------------------- |
| `valueChange` | `EventEmitter<boolean>`  | Emits when switch value changes.      |

### Example

```html
<gias-switch-template
  name="Enabled"
  [(value)]="enabled"
  siLabel="Yes"
  noLabel="No">
</gias-switch-template>
```

---

## GiasTextAreaTemplateComponent (`gias-text-area-template`)

### Description
Textarea template bound to a reactive form control with optional resize behavior and input-type-specific rendering.

### Inputs

| **Name**              | **Type**         | **Description**                                     |
| --------------------- | ---------------- | --------------------------------------------------- |
| `name`                | `string`        | Label.                                              |
| `value`               | `string`        | Current value.                                      |
| `placeholder`         | `string`        | Placeholder text.                                   |
| `obligatory`          | `boolean`       | Required flag.                                      |
| `isDisabled`          | `boolean`       | Disables the textarea.                              |
| `giasFormControlName` | `string`        | Name of bound `FormControl`.                       |
| `parentGroup`         | `FormGroup`     | Parent group (optional).                            |
| `resizable`           | `TextAreaResize`| Resize mode (e.g. `'vertical'`, `'horizontal'`).    |

### Outputs

| **Name**      | **Type**                  | **Description**                     |
| ------------- | ------------------------- | ----------------------------------- |
| `valueChange` | `EventEmitter<string>`    | Emits when content changes.         |

### Example

```html
<gias-text-area-template
  name="Notes"
  giasFormControlName="notes"
  [resizable]="'vertical'">
</gias-text-area-template>
```

---

## GiasTimePickerTemplateComponent (`gias-time-picker-template`)

### Description
Time picker template using Kendo `TimePickerComponent`, bound to a reactive form control with date-range and validation handling.

### Inputs

| **Name**              | **Type**           | **Description**                                         |
| --------------------- | ------------------ | ------------------------------------------------------- |
| `name`                | `string`          | Label.                                                  |
| `value`               | `Date`            | Current time value (date component used for range logic). |
| `nullValue`           | `Date`            | Special "empty" value.                                  |
| `startValue`          | `Date`            | Minimum allowed time/date.                              |
| `endValue`            | `Date`            | Maximum allowed time/date.                              |
| `obligatory`          | `boolean`         | Required flag.                                          |
| `isDisabled`          | `boolean`         | Disables the control.                                   |
| `giasFormControlName` | `string`          | Bound `FormControl` name.                               |
| `parentGroup`         | `FormGroup`       | Parent group.                                           |
| `readOnlyInput`       | `boolean`         | Makes text input read-only.                             |

### Outputs

| **Name**      | **Type**               | **Description**                     |
| ------------- | ---------------------- | ----------------------------------- |
| `valueChange` | `EventEmitter<Date>`   | Emits when time changes.           |
| `onBlur`      | `EventEmitter<void>`   | Emits when input loses focus.      |

### Example

```html
<gias-time-picker-template
  name="Start time"
  giasFormControlName="startTime">
</gias-time-picker-template>
```

---

## GiasTextTemplateComponent (`gias-text-template`)

### Description
Standard single-line text input template wired to reactive forms and error visualization.

### Inputs

| **Name**              | **Type**    | **Description**                                   |
| --------------------- | ----------- | ------------------------------------------------- |
| `name`                | `string`   | Label.                                            |
| `value`               | `string`   | Current text value.                               |
| `placeholder`         | `string`   | Placeholder text.                                 |
| `obligatory`          | `boolean`  | Required flag.                                    |
| `clearButton`         | `boolean`  | Shows clear button.                               |
| `isDisabled`          | `boolean`  | Disables input.                                   |
| `giasFormControlName` | `string`   | Name of bound `FormControl`.                     |
| `parentGroup`         | `FormGroup`| Parent group (optional).                          |
| `maxlength`           | `number`   | Maximum length constraint.                        |
| `minlength`           | `number`   | Minimum length constraint.                        |

### Outputs

| **Name**      | **Type**                 | **Description**                         |
| ------------- | ------------------------ | --------------------------------------- |
| `valueChange` | `EventEmitter<string>`   | Emits when text changes.                |

### Example

```html
<gias-text-template
  name="First name"
  giasFormControlName="firstName"
  [maxlength]="50">
</gias-text-template>
```

---

## GiasUpdateToolbarComponent (`gias-update-toolbar`)

### Description
Toolbar component for CRUD/update pages with save/undo/redo and optional company context, tightly integrated with `UpdateToolbarService`.

### Inputs

| **Name**           | **Type**                 | **Description**                                           |
| ------------------ | ------------------------ | --------------------------------------------------------- |
| `TipoOperazioneDB` | `number`                | Operation type (insert/update/read) from backend enum.    |
| `disabled`         | `boolean`               | Disables toolbar actions.                                 |
| `submit`           | `boolean`               | Enables submit behavior.                                  |
| `salvaNuovo`       | `boolean`               | Shows "Save & New" button when `true`.                    |
| `salva`            | `boolean`               | Shows "Save" button (default `true`).                     |
| `formGroup`        | `FormGroup`             | Form to track changes for undo/redo.                      |
| `trackChanges`     | `boolean`               | Enables undo/redo tracking when `true`.                   |
| `showCompanyName`  | `boolean`               | Shows company name context.                               |
| `openInIFrame`     | `boolean`               | Indicates iframe context.                                 |
| `position`         | `AppBarPosition`        | Toolbar position (`'top'`, etc.).                         |
| `positionMode`     | `AppBarPositionMode`    | Position mode (`'sticky'`, etc.).                         |

### Outputs

| **Name**             | **Type**                 | **Description**                         |
| -------------------- | ------------------------ | --------------------------------------- |
| `clickEvent`         | `EventEmitter<string>`   | Emits `'Salva'` when save is clicked.   |
| `clickSalvaNuovoEvent` | `EventEmitter<string>` | Emits `'SalvaNuovo'` when save-new is clicked. |

### Example

```html
<gias-update-toolbar
  [formGroup]="form"
  [trackChanges]="true"
  (clickEvent)="onToolbarClick($event)">
</gias-update-toolbar>
```

---

## GiasValiditaComponent (`gias-validita`)

### Description
Validity interval component for date ranges, validating that the start date is not after the end date.

### Inputs

| **Name**           | **Type**   | **Description**                                                            |
| ------------------ | ---------- | -------------------------------------------------------------------------- |
| `formGroupName`    | `string`  | Name of inner `FormGroup` with controls `inizio` and `fine`.              |
| `inizioFormControlName` | `string` | Name of start control when not using `formGroupName`.                |
| `fineFormControlName`   | `string` | Name of end control when not using `formGroupName`.                  |
| `enableAltRender`  | `boolean` | Disables default CSS when `true`.                                         |
| `inlineLabels`     | `Boolean` | Shows labels inline when `true`.                                          |

### Outputs

| **Name**   | **Type**                | **Description**                               |
| ---------- | ----------------------- | --------------------------------------------- |
| `onBlur`   | `EventEmitter<string>`  | Emits field identifier on blur.              |

### Example

```html
<form [formGroup]="form">
  <gias-validita formGroupName="validity"></gias-validita>
</form>
```

```ts
form = this.fb.group({
  validity: this.fb.group({
    inizio: [AGRODATAINIZIO],
    fine: [AGRODATAFINE]
  }, { asyncValidators: validityValidator() })
});
```

---

## GiasValiditaDateTimeComponent (`gias-validita-datetime`)

### Description
Validity interval component for date-time ranges, working with an inner `FormGroup` of type `IntervalloTemporaleForm`.

### Inputs

| **Name**        | **Type**   | **Description**                                        |
| --------------- | ---------- | ------------------------------------------------------ |
| `formGroupName` | `string`  | Name of `FormGroup` containing `inizio` and `fine`.    |

### Outputs

| **Name**  | **Type**                | **Description**                    |
| --------- | ----------------------- | ---------------------------------- |
| `onBlur`  | `EventEmitter<string>`  | Emits which field blurred.        |

### Example

```html
<gias-validita-datetime formGroupName="validityDateTime"></gias-validita-datetime>
```

---

## GiasWaitFrameComponent (`gias-wait-frame`)

### Description
Simple overlay/placeholder frame showing a message while waiting for operations to complete.

### Inputs

| **Name**  | **Type**   | **Description**                        |
| --------- | ---------- | -------------------------------------- |
| `message` | `string`  | Message displayed inside the wait frame. |

### Outputs

None.

### Example

```html
<gias-wait-frame message="Loading data, please wait..." *ngIf="loading"></gias-wait-frame>
```

