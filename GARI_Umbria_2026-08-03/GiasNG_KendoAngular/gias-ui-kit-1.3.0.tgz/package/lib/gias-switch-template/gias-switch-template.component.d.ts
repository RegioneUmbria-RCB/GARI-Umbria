import { EventEmitter, OnInit } from '@angular/core';
import { IGiasMasterService } from '../utils/gias-master.service';
import { enum_InputType } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasSwitchTemplateComponent implements OnInit {
    private giasMasterService;
    name: string;
    value: boolean;
    placeholder: string;
    isDisabled: boolean;
    giasFormControlName: string;
    siLabel: string;
    noLabel: string;
    isBlue: boolean;
    hideLabel: boolean;
    hideformfield: boolean;
    valueChange: EventEmitter<boolean>;
    inputType: enum_InputType;
    constructor(giasMasterService: IGiasMasterService);
    ngOnInit(): void;
    changeValue(newValue: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasSwitchTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasSwitchTemplateComponent, "gias-switch-template", never, { "name": { "alias": "name"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; "siLabel": { "alias": "siLabel"; "required": false; }; "noLabel": { "alias": "noLabel"; "required": false; }; "isBlue": { "alias": "isBlue"; "required": false; }; "hideLabel": { "alias": "hideLabel"; "required": false; }; "hideformfield": { "alias": "hideformfield"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
