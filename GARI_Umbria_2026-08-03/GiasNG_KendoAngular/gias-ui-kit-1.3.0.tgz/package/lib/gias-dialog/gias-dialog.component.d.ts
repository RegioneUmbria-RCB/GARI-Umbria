import * as i0 from "@angular/core";
export declare class GiasDialogComponent {
    content?: string;
    title?: string;
    dialogType?: string;
    height?: number | string;
    CalculateHeight(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasDialogComponent, "gias-dialog", never, {}, {}, never, never, false, never>;
}
