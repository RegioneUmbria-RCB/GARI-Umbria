import { Codice } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasCodiceTemplateComponent {
    codice: Codice;
    lista_codici: Array<any>;
    text_field: string;
    value_field: string;
    dateControl: boolean;
    formEnable: boolean;
    changeValue: any;
    AGRODATAINIZIO: Date;
    AGRODATAFINE: Date;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasCodiceTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasCodiceTemplateComponent, "gias-codice-template", never, { "codice": { "alias": "codice"; "required": false; }; "lista_codici": { "alias": "lista_codici"; "required": false; }; "text_field": { "alias": "text_field"; "required": false; }; "value_field": { "alias": "value_field"; "required": false; }; "dateControl": { "alias": "dateControl"; "required": false; }; "formEnable": { "alias": "formEnable"; "required": false; }; }, { "changeValue": "changeValue"; }, never, never, false, never>;
}
