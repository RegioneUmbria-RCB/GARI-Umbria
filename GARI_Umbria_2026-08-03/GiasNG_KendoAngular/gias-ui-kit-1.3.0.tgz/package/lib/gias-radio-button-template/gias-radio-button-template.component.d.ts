import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class RadioButtonValue {
    name?: string;
    value?: any;
    enable?: boolean;
    constructor(name?: string, value?: any, enable?: boolean);
}
export declare class GiasRadioButtonTemplateComponent {
    radioButtonValues: RadioButtonValue[];
    value: any;
    formEnable: boolean;
    formControlName: string;
    valueChange: EventEmitter<any>;
    onItemChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasRadioButtonTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasRadioButtonTemplateComponent, "gias-radio-button-template", never, { "radioButtonValues": { "alias": "radioButtonValues"; "required": false; }; "value": { "alias": "value"; "required": false; }; "formEnable": { "alias": "formEnable"; "required": false; }; "formControlName": { "alias": "formControlName"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
