import * as i0 from "@angular/core";
export declare class GiasMasterSpinnerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasMasterSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasMasterSpinnerComponent, "gias-master-spinner", never, {}, {}, never, never, false, never>;
}
