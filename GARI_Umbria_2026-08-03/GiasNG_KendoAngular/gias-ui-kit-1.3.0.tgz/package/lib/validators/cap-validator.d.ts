import { ValidatorFn } from '@angular/forms';
export declare function capValidatorAppezzamenti(): ValidatorFn;
export declare function capValidatorCentriGrid(): ValidatorFn;
export declare function capValidatorAziendeGrid(): ValidatorFn;
export declare function capValidatorCentriEdit(): ValidatorFn;
export declare function capValidatorAziendeEdit(): ValidatorFn;
