import { AbstractControl, ValidationErrors, Validator } from '@angular/forms';
export declare class MultiSelectValidator implements Validator {
    private ValuePrimitive;
    private valuefield;
    constructor(ValuePrimitive: boolean, valuefield?: string);
    validate(control: AbstractControl): ValidationErrors;
}
