import { ElementRef } from '@angular/core';
export declare const AGRODATAINIZIO: Date;
export declare const AGRODATAFINE: Date;
export declare class BaseCodeDescr {
    codice: number;
    descrizione: string;
    constructor(codice: number, descrizione?: string);
}
export declare class BaseCodeDescrStr {
    codice: string;
    descrizione: string;
    constructor(codice: string, descrizione?: string);
}
export declare class BaseCodeDescrVal extends BaseCodeDescr {
    valore: string;
    constructor(codice?: number, descrizione?: string, valore?: string);
}
export declare class Codice {
    chiave: number;
    Descrizione: string;
    Id_Cod: string;
    Val_Cod: string;
    Validita_Inizio: Date;
    Validita_Fine: Date;
}
export declare class CodiciNazioniISO3166 {
    codice: string;
    descrizione: string;
    codiceNumerico: string;
    codiceAlpha3: string;
    gestioneGerarchia: number;
    constructor(codice: string, descrizione: string, codiceNumerico: string, codiceAlpha3: string, gestioneGerarchia: number);
}
export declare enum enum_InputType {
    Gias_Classic = 0,
    Angular_Material = 1,
    Due_righe = 2
}
export declare class FormaGiuridica {
    Fg_Cod: number;
    Fg_Des: string;
}
export declare class Provincia {
    sigla: string;
    regione_cod: string;
    regione_des: string;
    Provincia_Des: string;
    Istat_Prov: string;
    Stato_Country: string;
    comuneDefault: string;
}
export declare class Comune {
    provincia: Provincia;
    codice: string;
    descrizione: string;
}
export declare class Stato {
    codice: string;
    descrizione: string;
}
export declare class DestinazioneUso {
    codice: number;
    descrizione: string;
}
export declare class SpecieVegetale {
    veg_cod: number;
    veg_des: string;
    constructor(codice?: number, descrizione?: string);
}
export declare class Cultivar {
    cul_cod: number;
    cul_des: string;
    constructor(codice?: number, descrizione?: string);
}
export declare class CultivarxSpecie {
    Veg_Cod: number;
    Cultivar: Cultivar[];
}
export declare class Finalita {
    grfi_cod: number;
    grfi_des: string;
}
export declare class FinalitaxSpecie {
    Veg_Cod: number;
    Finalita: Finalita[];
}
export declare class ColturePrecedenti {
    Codice: string;
    Descrizione: string;
}
export declare class Ditta {
    codice: number;
    descrizione: string;
}
export declare class Tipo {
    CLASS_CODE: string;
    CLASS_DESC: string;
}
export declare class Tipo1 {
    id: string;
    name: string;
}
export declare class Marca {
    codice: number;
    descrizione: string;
}
export declare class LoadingObject {
    isLoading: boolean;
    message?: string;
    component?: ElementRef<any>;
    zIndex?: number;
}
export declare enum enum_ErroreGias_Tipo {
    Generico = 1,
    NonGestito = 999
}
export declare enum ErroreGias_Severity {
    Bloccante = 0,//Errore in basso a dx rosso, l'utente non può procedere (sia errori gestiti che exceptions)
    Warning = 1,//Pop-up di n warning accodati con possibilità per l'utente di proseguire ("Si desidera proseguire?"   -   Annulla/Prosegui)
    Info = 2,
    WarningBloccante = 3
}
export declare class ErroreGias {
    severity: ErroreGias_Severity;
    messaggio: string;
    ex: string;
    tipo: enum_ErroreGias_Tipo;
}
export declare class RispostaStandard {
    Sessione: boolean;
    RispostaOK: boolean;
    RispostaConferma: boolean;
    ParametroDue: boolean;
    ParametroDue_stringa: string;
    Tipo: string;
    RispostaCompressa: Uint8Array;
    Compressa: boolean;
    Errore: string;
    RispostaStringa: string;
    ErroriGias: ErroreGias[];
}
export declare class rispostaStandard<T> {
    Sessione: boolean;
    RispostaOK: boolean;
    RispostaConferma: boolean;
    ParametroDue: boolean;
    ParametroDue_stringa: string;
    Tipo: string;
    RispostaCompressa: Uint8Array;
    Compressa: boolean;
    Errore: string;
    RispostaStringa: T;
    ErroriGias: ErroreGias[];
}
export declare class Parametri {
    objP_super_server: string;
    objP_server: string;
    objP_utenti: string;
}
export declare class CoreWSRequest<T> {
    objP_super_server: string;
    objP_server: string;
    objP_utenti: string;
    InData: T;
}
export declare class ErrorMsg {
    show: boolean;
    msg: string;
    errorNumber: number;
}
export declare class WindowErrorMsg {
    show: boolean;
    msg: string;
    showWarningIcon?: boolean;
    TitleBarMessage?: string;
    errorNumber: number;
}
export declare class LoadingComponentObject {
    isLoading: boolean;
    message?: string;
    component: ElementRef<any>;
}
export declare class Leggi_Forme_Giuridiche_Request {
    FG_cod: number;
    objP_server: string;
}
export declare class ISTAT_GetProvincie_Request {
    valori_regioni: string;
    objP_Server: string;
}
export declare class ISTAT_GetComuni_Request {
    valori_provincia: string;
    objP_Server: string;
}
export declare class ISTAT_GetCAP_Request {
    Prov: string;
    Com: string;
}
export declare class GetProvince {
    stato: string;
    regione: string;
}
export declare class GetRegionsByProvince {
    stato: string;
    prov: string;
}
export declare class DropdownListEvent {
    type: DropdownEventType;
    id: string;
    data: any;
    listItems: any;
    constructor(type: DropdownEventType, id: string, data: any, listItems: any);
}
export declare enum DropdownEventType {
    ON_CHANGE_VALUE = "value-changed",
    ON_PRE_UPDATE_DROPDOWN = "pre-update-dropdown",
    ON_UPDATE_DROPDOWN = "update-dropdown",
    ON_OPEN_DROPDOWN = "open-dropdown",
    ON_CLOSE_DROPDOWN = "close-dropdown",
    ON_FOCUS_DROPDOWN = "focus-dropdown",
    ON_BLUR_DROPDOWN = "blur-dropdown",
    ON_OPENED_DROPDOWN = "opened-dropdown"
}
export declare class DropdownListFormItem {
    Id: string;
    FormControlName: string;
    Value: any;
}
export declare class DropdownListItem {
    readonly id: any;
    readonly name: string;
    readonly data?: any;
    constructor(id: any, name: string, data?: any);
}
export declare class Utente {
    Username?: string;
    Nome?: string;
    Cognome?: string;
    Rag_Soc?: string;
    Cod_Fisc?: string;
    UsernameCommerciale?: string;
    Permessi: Utente_Permesso[];
    Impostazioni: Utente_Impostazioni[];
    ValiditaUtentePermessiLicenza?: Messaggio_Utente_Permessi;
    constructor(Username?: string, Nome?: string, Cognome?: string, Rag_Soc?: string, Cod_Fisc?: string, UsernameCommerciale?: string, Permessi?: Utente_Permesso[], Impostazioni?: Utente_Impostazioni[], ValiditaUtentePermessiLicenza?: Messaggio_Utente_Permessi);
}
export declare class Messaggio_Utente_Permessi {
    Permessi_Scaduta_O_In_Scadenza: boolean;
    Licenza_Scaduta_O_In_Scadenza: boolean;
    Messaggio: string;
}
export declare class Utente_Permesso {
    Permesso_ID?: number;
    Permesso_Tipo?: number | enum_TipoPermesso;
    /**
     * @param Permesso_ID corrisponde al codice attività del permesso
     * @param Permesso_Tipo livello di permessi sull'attività
     */
    constructor(Permesso_ID?: number, Permesso_Tipo?: number | enum_TipoPermesso);
}
export declare enum enum_TipoPermesso {
    LETTURA = 0,
    DISABILITATO = 1,
    LETTURA_SCRITTURA = 2
}
export declare class Utente_Impostazioni {
    Impostazione_Cod?: number;
    Valore?: string;
    constructor(Impostazione_Cod?: number, Valore?: string);
}
export declare enum Enum_DBTypeOperation {
    Read = 0,
    Write = 1,
    Update = 2,
    Delete = 3
}
export declare class PostMessageStrutturata<T> {
    messaggio: messaggioPostMessage;
    contesto: contestoPostMessage;
    inData: T;
    constructor(messaggio: messaggioPostMessage, contesto: contestoPostMessage, inData: T);
}
export declare enum messaggioPostMessage {
    chiudiWindowGiasNG = "chiudiWindowGiasNG",
    chiudiFinestra = "chiudiFinestra"
}
export declare enum contestoPostMessage {
    SalvaAppezzamento = 1,
    SalvaCampo = 2,
    FiltroneImpianti = 3,
    FiltroneVisibilitaAziendale = 4
}
export declare class PostMessageSelezioneFiltrone {
    contestoPostMessage: contestoPostMessage;
    tipoChiavi: string;
    elencoChiavi: string[];
    parametri: string[][];
}
export declare enum CELL_TYPES {
    STRING = "string",
    DATE = "date",
    DATETIME = "datetime",
    DROPDOWNLIST = "dropdownlist",
    MULTI_DROPDOWNLIST = "multi_dropdownlist",
    NUMBER = "number",
    BOOLEAN = "boolean",
    OBJECT = "object",
    CUSTOM = "custom"
}
export declare enum enum_TipoControllo {
    UNDEFINED = 0,
    CASELLA_TESTO = 1,
    AREA_TESTO = 2,
    MENU_DISCESA = 3,
    CASELLA_SPUNTA = 4,// boolean switch / checkbox
    CALENDARIO = 5,
    ALLEGATO = 6,
    LINK = 7,
    PASSWORD = 8,
    MULTISELECT_ESTESA_SERVER = 9,
    PULSANTE_SCELTA = 10,
    IMMAGINE = 11,
    DDL_ESTESA_CLIENT = 12,
    GIS_VIEWER = 13,
    DDL_ESTESA_SERVER_LIGHT = 14,
    NUMERO_INTERO = 15,
    NUMERO_DECIMALE = 16,
    MULTISELECT = 17
}
export interface IGuidaValoreImpostazione {
    codice: any;
    descrizione: string;
    valore: string;
    Tipo_campo: string;
    Note: string;
}
/**
 * Modella i possibili valori legati a un'impostazione.
 * Modello creato sulla base della tabella Guida_Impostazioni_Valori.
 */
export declare class GuidaValoreImpostazione extends BaseCodeDescrVal implements IGuidaValoreImpostazione {
    Tipo_campo: string;
    Note: string;
    Username: string;
    constructor(codice?: number, descrizione?: string, valore?: string, Tipo_campo?: string, Note?: string, Username?: string);
}
export declare class GenericGuidaValoreImpostazione<T> implements IGuidaValoreImpostazione {
    codice: T;
    descrizione: string;
    valore: string;
    Tipo_campo: string;
    Note: string;
    constructor(codice: T, descrizione?: string, valore?: string, Tipo_campo?: string, Note?: string);
}
/**
 * Modello d'impostazione usato come base per il form impostazioni.
 */
export declare class ImpostazioniFormItem {
    guida: Impostazione;
    valoreCorrente: string | any;
    valori: IGuidaValoreImpostazione[];
}
/** Descrive la struttura delle impostazioni come salvate su DB.
 */
export declare class Impostazione {
    Data_Creazione: Date;
    Data_Modifica: Date;
    Data_Invio: Date;
    Impostazione_Cod: number;
    Impostazione_Des: string;
    Impostazione_SuperUser: number;
    Impostazione_Azienda: number;
    Impostazione_AziendaCentro: number;
    Impostazione_AziendaCentroSpecie: number;
    Flag_InApp: number;
    Inviato: number;
    Note: string;
    Ordine: number;
    Tipo_Campo: string;
    Valore_Default: string;
    Sezione_Cod: number;
    Sezione_Des: string;
    SottoSezione_Cod: number;
    SottoSezione_Des: string;
    Livello_Cod: number;
    Livello_Des: string;
    Username_Creazione: string;
    Username_Modifica: string;
    Validita_Inizio: Date;
    Validita_Fine: Date;
    value: string;
    descrizione: string;
    codice: number;
    constructor(Impostazione_Cod: number, Impostazione_Des?: string, tipoControllo?: string);
    setVisibility(visibility: {
        isSuperUser?: 0 | 1;
        isAzienda?: 0 | 1;
        isUtente?: 0 | 1;
        isInApp?: 0 | 1;
        isAziendaCentro?: 0 | 1;
        isAziendaCentroSpecie?: 0 | 1;
    }): void;
    setSection(sezione?: number, sottoSezione?: number, livello?: number, ordine?: number): void;
}
