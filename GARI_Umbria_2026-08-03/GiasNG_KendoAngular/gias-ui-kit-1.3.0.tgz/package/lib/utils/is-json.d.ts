export declare function isJSON(str: string): boolean;
