export declare function compareObjects(o: any, p: any): boolean;
