export declare class SvgColor {
    r: any;
    g: any;
    b: any;
    constructor(r: any, g: any, b: any);
    toString(): string;
    set(r: any, g: any, b: any): void;
    hueRotate(angle?: number): void;
    grayscale(value?: number): void;
    sepia(value?: number): void;
    saturate(value?: number): void;
    multiply(matrix: any): void;
    brightness(value?: number): void;
    contrast(value?: number): void;
    linear(slope?: number, intercept?: number): void;
    invert(value?: number): void;
    hsl(): {
        h: number;
        s: number;
        l: number;
    };
    clamp(value: any): any;
}
export declare class SvgSolver {
    target: any;
    targetHSL: any;
    reusedColor: any;
    constructor(target: any);
    solve(): {
        values: any;
        loss: number;
        filter: string;
    };
    solveWide(): {
        loss: number;
    };
    solveNarrow(wide: any): {
        values: any;
        loss: number;
    };
    spsa(A: any, a: any, c: any, values: any, iters: any): {
        values: any;
        loss: number;
    };
    loss(filters: any): number;
    css(filters: any): string;
}
export declare function hex2rgb(hex: string): {
    r: number;
    g: number;
    b: number;
};
export declare class RgbUtility {
    rgb2hex(r: number, g: number, b: number): string;
    private component2hex;
}
