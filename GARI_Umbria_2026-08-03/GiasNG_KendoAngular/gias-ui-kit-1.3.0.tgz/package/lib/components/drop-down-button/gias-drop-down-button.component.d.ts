import { EventEmitter, OnInit } from '@angular/core';
import { ButtonFillMode, ButtonRounded, ButtonSize, ButtonThemeColor, DropDownButtonComponent, PreventableEvent } from '@progress/kendo-angular-buttons';
import { SVGIcon } from '@progress/kendo-svg-icons';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { PopupSettings } from '@progress/kendo-angular-dropdowns';
import * as i0 from "@angular/core";
export declare class GiasDropDownButtonComponent implements OnInit {
    item: any | undefined;
    iconDefinition: IconDefinition;
    arrowIcon: boolean;
    buttonAttributes: {
        [key: string]: string;
    };
    buttonClass: any;
    data: GiasDropDownButtonActionItem[];
    disabled: boolean;
    fillMode: ButtonFillMode;
    icon: string;
    iconClass: string;
    imageUrl: string;
    popupSettings: PopupSettings;
    rounded: ButtonRounded;
    size: ButtonSize;
    svgIcon: SVGIcon;
    tabIndex: number;
    textField: string;
    themeColor: ButtonThemeColor;
    close: EventEmitter<PreventableEvent>;
    itemClick: EventEmitter<any>;
    blur: EventEmitter<any>;
    focus: EventEmitter<any>;
    open: EventEmitter<PreventableEvent>;
    ddb: DropDownButtonComponent;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasDropDownButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasDropDownButtonComponent, "app-drop-down-button", never, { "item": { "alias": "item"; "required": false; }; "iconDefinition": { "alias": "iconDefinition"; "required": false; }; "arrowIcon": { "alias": "arrowIcon"; "required": false; }; "buttonAttributes": { "alias": "buttonAttributes"; "required": false; }; "buttonClass": { "alias": "buttonClass"; "required": false; }; "data": { "alias": "data"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "fillMode": { "alias": "fillMode"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconClass": { "alias": "iconClass"; "required": false; }; "imageUrl": { "alias": "imageUrl"; "required": false; }; "popupSettings": { "alias": "popupSettings"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "size": { "alias": "size"; "required": false; }; "svgIcon": { "alias": "svgIcon"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "textField": { "alias": "textField"; "required": false; }; "themeColor": { "alias": "themeColor"; "required": false; }; }, { "close": "close"; "itemClick": "itemClick"; "blur": "blur"; "focus": "focus"; "open": "open"; }, never, never, false, never>;
}
export interface GiasDropDownButtonActionItem {
    text: string;
    disabled: boolean;
    icon: string;
    click: (...data: any[]) => any;
}
