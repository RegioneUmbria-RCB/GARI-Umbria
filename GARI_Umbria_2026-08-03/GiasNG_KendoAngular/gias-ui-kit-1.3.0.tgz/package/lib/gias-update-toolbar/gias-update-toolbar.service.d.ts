import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
declare class FormGroupChange {
    changedAt: Date;
    changes: FormGroup;
}
declare class AvailableChangeOperation {
    canUndo: boolean;
    canRedo: boolean;
}
export declare class UpdateToolbarService {
    private lastIndex;
    private saveValueChanges;
    private userForm;
    private changes;
    availableChangeOperation: AvailableChangeOperation;
    private availableChangeOperationObjectSource;
    currentAvailableChangeOperation: Observable<AvailableChangeOperation>;
    setAvailableChangeOperation(availableChangeOperation: AvailableChangeOperation): void;
    undo(): void;
    redo(): void;
    initializeChanges(userForm: FormGroup): void;
    getLastIndex(): number;
    getChanges(): Array<FormGroupChange>;
    updateAvailableChangeOperation(): void;
    updateComplexFormGroup(values: FormGroup): void;
    formHasChanges(values: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateToolbarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UpdateToolbarService>;
}
export {};
