import { Observable } from 'rxjs';
import { CELL_TYPES } from '../utils/models';
import * as i0 from "@angular/core";
export declare class MultiColumnComboboxService {
    private MultiColumnComboboxValueObject;
    private MultiColumnComboboxValueObjectSource;
    currentMultiColumnComboboxValueObject: Observable<MultiColumnComboboxFormItem>;
    setMultiColumnComboboxValue(MultiColumnComboboxValueObject: MultiColumnComboboxFormItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiColumnComboboxService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiColumnComboboxService>;
}
export declare class MultiColumnComboboxFormItem {
    FormControlName: string;
    Value: any;
}
export declare class ColumnCombobox {
    field: string;
    title: string;
    /**
     * @description
     * Formatta la colonna numero con la lingua del LOCALE_ID.
     * Se formatNumbertolocal è true allora la colonna la proprietà type deve essere CELL_TYPES.number
     */
    formatNumbertolocal?: boolean;
    digitsInfo: string;
    type?: CELL_TYPES;
    hidden?: boolean;
    media?: string;
    width?: number;
    isArray?: boolean;
    Arrayfield?: string;
    Arrayseparator?: string;
    ColumnComboBoxColumnCellTemplate?: boolean;
    style?: {
        [key: string]: string;
    };
    class?: string;
    constructor(required: {
        field: string;
        title: string;
    }, optional?: Partial<ColumnCombobox>);
}
export declare class MultiColumnComboboxGiasTemplate {
    Codice_Concatenato: string;
    Descrizione_Concatenata: string;
}
