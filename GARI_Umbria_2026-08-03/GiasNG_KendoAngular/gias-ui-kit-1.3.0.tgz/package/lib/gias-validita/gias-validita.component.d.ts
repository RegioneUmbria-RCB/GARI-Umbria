import { OnInit, EventEmitter } from '@angular/core';
import { AsyncValidatorFn, FormGroup, FormGroupDirective } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class GiasValiditaComponent implements OnInit {
    private rootFormGroup;
    /** Nome del controllo di riferimento all'interno del FormGroup padre.
     * Deve far riferimento a un FormGroup contenente i controlli `inizio` e `fine`.
     */
    formGroupName: string;
    /** Nome del controllo di riferimento per l'inizio dell'intervallo di validità
     *  all'interno del FormGroup padre. Usato solo se {@link formGroupName} non è valorizzato.
     */
    inizioFormControlName: string;
    /** Nome del controllo di riferimento per la fine dell'intervallo di validità
     *  all'interno del FormGroup padre. Usato solo se {@link formGroupName} non è valorizzato.
     */
    fineFormControlName: string;
    /**
     * Disattiva il css di default.
     *  @default `false`
     */
    enableAltRender: boolean;
    /**
     * If `true` shows the labels inline.
     * @default `false`
     */
    inlineLabels: Boolean;
    onBlurEvent: EventEmitter<string>;
    form: FormGroup;
    AGRODATA_INIZIO: Date;
    AGRODATA_FINE: Date;
    constructor(rootFormGroup: FormGroupDirective);
    /** @returns il nome del FormControl che governa l'inizio dell'intervallo. */
    get inizio(): string;
    /** @returns il nome del FormControl che governa la fine dell'intervallo. */
    get fine(): string;
    get controlClass(): string;
    ngOnInit(): void;
    handleBlur(field: string): void;
    private valorizeInnerForm;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasValiditaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasValiditaComponent, "gias-validita", never, { "formGroupName": { "alias": "formGroupName"; "required": false; }; "inizioFormControlName": { "alias": "inizioFormControlName"; "required": false; }; "fineFormControlName": { "alias": "fineFormControlName"; "required": false; }; "enableAltRender": { "alias": "enableAltRender"; "required": false; }; "inlineLabels": { "alias": "inlineLabels"; "required": false; }; }, { "onBlurEvent": "onBlur"; }, never, never, false, never>;
}
export declare function validityValidator(fcStartName?: string, fcEndName?: string): AsyncValidatorFn;
