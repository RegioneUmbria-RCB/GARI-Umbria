import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class GiasInfoTemplateComponent {
    title: string;
    size: any;
    tooltipTemplate: TemplateRef<any>;
    faInfo: import("@fortawesome/fontawesome-common-types").IconDefinition;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasInfoTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasInfoTemplateComponent, "gias-info-template", never, { "title": { "alias": "title"; "required": false; }; "size": { "alias": "size"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; }, {}, never, never, false, never>;
}
