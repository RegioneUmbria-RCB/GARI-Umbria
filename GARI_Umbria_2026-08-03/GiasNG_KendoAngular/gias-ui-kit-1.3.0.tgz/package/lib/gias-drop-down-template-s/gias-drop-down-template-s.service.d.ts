import { Observable } from 'rxjs';
import { DropdownListFormItem } from '../utils/models';
import * as i0 from "@angular/core";
export declare class GiasDropDownTemplateService {
    private DropDownValueObject;
    private DropDownValueObjectSource;
    currentDropDownValueObject: Observable<DropdownListFormItem>;
    setDropDownValue(DropDownValueObject: DropdownListFormItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasDropDownTemplateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasDropDownTemplateService>;
}
