import { AfterViewInit, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective } from "@angular/forms";
import * as i0 from "@angular/core";
export declare class GiasPasswordTemplateComponent implements OnInit, AfterViewInit {
    private rootFormGroup;
    textbox: any;
    name: string;
    placeholder: string;
    obligatory: boolean;
    isDisabled: boolean;
    giasFormControlName: string;
    parentGroup: FormGroup;
    maxlength: number;
    minlength: number;
    valueChange: EventEmitter<string>;
    showPassword: boolean;
    iconClass: string;
    constructor(rootFormGroup: FormGroupDirective);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private addValidators;
    togglePasswordVisibility(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasPasswordTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasPasswordTemplateComponent, "gias-password-template", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "obligatory": { "alias": "obligatory"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "giasFormControlName": { "alias": "giasFormControlName"; "required": false; }; "parentGroup": { "alias": "parentGroup"; "required": false; }; "maxlength": { "alias": "maxlength"; "required": false; }; "minlength": { "alias": "minlength"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}
