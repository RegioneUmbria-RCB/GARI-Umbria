import { OnInit, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class GiasValiditaDateTimeComponent implements OnInit {
    private rootFormGroup;
    formGroupName: string;
    onBlurEvent: EventEmitter<string>;
    form: FormGroup<IntervalloTemporaleForm>;
    AGRODATA_INIZIO: Date;
    AGRODATA_FINE: Date;
    constructor(rootFormGroup: FormGroupDirective);
    ngOnInit(): void;
    handleBlur(field: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasValiditaDateTimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasValiditaDateTimeComponent, "gias-validita-datetime", never, { "formGroupName": { "alias": "formGroupName"; "required": false; }; }, { "onBlurEvent": "onBlur"; }, never, never, false, never>;
}
export interface IntervalloTemporaleForm {
    inizio: FormControl<Date>;
    fine: FormControl<Date>;
}
