import * as i0 from "@angular/core";
export declare class GiasWaitFrameComponent {
    message: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasWaitFrameComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasWaitFrameComponent, "gias-wait-frame", never, { "message": { "alias": "message"; "required": false; }; }, {}, never, never, false, never>;
}
