import { AbstractControl, ValidationErrors } from "@angular/forms";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class ErrorTree {
    name: string;
    field: string;
    form: AbstractControl;
    errors: ValidationErrors;
}
export declare class GiasFormErrorVisualizerService {
    private errors;
    currentErrors: Observable<ErrorTree[]>;
    resetFormError(): void;
    getErrors(): ErrorTree[];
    private setError;
    private removeError;
    handleFormControl(name: string, field: string, form: AbstractControl, isSavings?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasFormErrorVisualizerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasFormErrorVisualizerService>;
}
