import { AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { ErrorTree, GiasFormErrorVisualizerService } from './gias-form-error-visualizer.service';
import * as i0 from "@angular/core";
export declare class GiasFormErrorVisualizerComponent implements OnInit, OnDestroy, AfterViewInit {
    private formErrorVisualizerService;
    private route;
    form: FormGroup;
    signal$: Subject<void>;
    errorTree: ErrorTree[];
    windowS: Window & typeof globalThis;
    constructor(formErrorVisualizerService: GiasFormErrorVisualizerService, route: ActivatedRoute);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    fragment: string;
    ngOnInit(): void;
    goToAnchorTag(idtogo: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasFormErrorVisualizerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasFormErrorVisualizerComponent, "gias-form-error-visualizer", never, { "form": { "alias": "form"; "required": false; }; }, {}, never, never, false, never>;
}
