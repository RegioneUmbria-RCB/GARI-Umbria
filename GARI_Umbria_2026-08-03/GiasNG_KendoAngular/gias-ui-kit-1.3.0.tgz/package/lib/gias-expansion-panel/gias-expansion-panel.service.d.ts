import { CookieService } from 'ngx-cookie-service';
import * as i0 from "@angular/core";
export declare class GiasExpansionPanelService {
    private cookieService;
    constructor(cookieService: CookieService);
    getConfigCookies(id: string): Promise<IPanelCookie>;
    storeConfigCookie(id: string, data: IPanelCookie): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasExpansionPanelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasExpansionPanelService>;
}
export declare class ExpansionPanelCookie implements IPanelCookie {
    isExpanded: boolean;
}
export interface IPanelCookie {
    isExpanded: boolean;
}
