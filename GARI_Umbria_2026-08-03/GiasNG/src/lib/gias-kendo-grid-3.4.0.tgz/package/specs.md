## GiasKendoGridComponent (`<gias-kendo-grid>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/kendo-grid.component.ts`  
**Selector**: `gias-kendo-grid`

### What it does

High‑level wrapper around Kendo Grid that centralizes configuration (columns, model, rows, pagination, selection, editing modes, custom command columns, master/detail, Excel export, aggregate footers, views customization, etc.). It coordinates several internal services to render and manage a data grid with rich behavior.

### Inputs

| Name                             | Type                                   | Description |
| -------------------------------- | -------------------------------------- | ----------- |
| `columns`                        | `KendoGridColumn[]`                    | Grid column configuration describing fields, types, editors, and dropdown settings. |
| `rows`                           | `KendoGridRow[]`                       | Data rows to show when using HTML/service loading modes. |
| `model`                          | `KendoGridModel`                       | Model metadata describing each field’s type and behavior used for editors and filters. |
| `gridId`                         | `string`                               | Identifier for the grid instance; used for persisted views and master/detail scenarios. |
| `customCommandColumnCellTemplate`   | `TemplateRef<ElementRef>`            | Custom template to render the command column cell content. |
| `customCommandColumnHeaderTemplate` | `TemplateRef<any>`                   | Custom template for the command column header. |
| `showSwitchViewsPrivatePublic`   | `boolean`                              | Enables the UI switch between private/public saved views. |

> Many other settings (editingMode, loader, generalSettings, pagination, behavior, aggregates, toolbar, etc.) are configured via the injected services (`KendoGridService`, `GridPublicService`, configuration models) rather than via direct `@Input()`s.

### Outputs

- **`rowsLoaded: EventEmitter<void>`**: Fired after rows and columns are initialized and the grid view is ready.
- **`cellClick: EventEmitter<CellClickEvent>`**: Emits when a grid cell is clicked (after internal handling).
- **`pageChangeEvent: EventEmitter<{ grid: GridComponent; event: PageChangeEvent }>`**: Emits when the page changes (non‑virtual scrolling).
- **`selectionChange: EventEmitter<SelectionEvent>`**: Emits when row selection changes.
- **`columnVisibilityChange: EventEmitter<ColumnVisibilityChangeEvent>`**: Emits when a column’s visibility changes (e.g. via column menu).
- **`numericTextBox: EventEmitter<number>`**: Emits when the numeric filter/control bound to the grid changes.
- **`detailCollapse: EventEmitter<DetailCollapseEvent>`**: Emits when a master row detail is collapsed.
- **`detailExpand: EventEmitter<DetailExpandEvent>`**: Emits when a master row detail is expanded.

### Example

```ts
// host.component.ts
import { Component } from '@angular/core';
import { KendoGridColumn, KendoGridModel, KendoGridRow } from 'gias-kendo-grid';

@Component({
  selector: 'app-example-grid',
  templateUrl: './example-grid.component.html'
})
export class ExampleGridComponent {
  gridId = 'customers-grid';
  columns: KendoGridColumn[] = [
    { field: 'id', title: 'ID' },
    { field: 'name', title: 'Name' }
  ];
  model: KendoGridModel = {
    id: { type: 'number' },
    name: { type: 'string' }
  };
  rows: KendoGridRow[] = [
    { id: 1, name: 'Alice' },
    { id: 2, name: 'Bob' }
  ];

  onRowsLoaded() { /* hook for post‑init logic */ }
}
```

```html
<!-- example-grid.component.html -->
<gias-kendo-grid
  [gridId]="gridId"
  [columns]="columns"
  [model]="model"
  [rows]="rows"
  (rowsLoaded)="onRowsLoaded()"
  (selectionChange)="onSelectionChange($event)">
</gias-kendo-grid>
```

---

## GridCustomComponent (`<gias-grid-custom>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/custom/grid-custom.component.ts`  
**Selector**: `gias-grid-custom`

### What it does

Host component that dynamically creates and injects a custom cell component implementing `CustomComponent` into a grid cell, wiring shared `input`, `field`, `edit` and `formGroup` values.

### Inputs

| Name         | Type                    | Description |
| ------------ | ----------------------- | ----------- |
| `component`  | `Type<CustomComponent>` | Component type to dynamically create. Must accept the same input contract (`input`, `field`, `edit`, `formGroup`). |
| `input`      | `any`                   | The current row data item. |
| `field`      | `any`                   | Field identifier used by the custom component. |
| `edit`       | `any`                   | Flag or context indicating whether the cell is in edit mode. |
| `formGroup`  | `FormGroup`             | Form group for the current row so the custom component can bind controls. |

### Outputs

None directly; events are expected to be emitted by the dynamically created component.

### Example

```html
<!-- Inside a Kendo Grid cell template -->
<gias-grid-custom
  [component]="customCellComponent"
  [input]="dataItem"
  [field]="'priceSettings'"
  [edit]="isInEditMode"
  [formGroup]="formGroup">
</gias-grid-custom>
```

```ts
// host.ts
import { Type } from '@angular/core';
import { CustomPriceCellComponent } from './custom-price-cell.component';

customCellComponent: Type<any> = CustomPriceCellComponent;
```

---

## GridCustomizationsComponent (`<gias-grid-customizations>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-customizations/grid-customizations.component.ts`  
**Selector**: `gias-grid-customizations`

### What it does

Provides the UI and logic to manage grid views (saved layouts): applying, creating, saving, and deleting views, optionally with a “public/private” switch.

### Inputs

| Name              | Type               | Description |
| ----------------- | ------------------ | ----------- |
| `canApplyChanges` | `boolean`          | When set to `true`, forces applying any pending layout changes. |
| `options`         | `GridCustomizations` | Configuration for the customizations dropdown and views behavior. |
| `showSwitch`      | `boolean`          | Enables the toggle for publishing (public/private) a view. |
| `selectedDDLItem` | `DropdownListItem` | Currently selected view item in the underlying dropdown. |

### Outputs

- **`canApplyChangesChange: EventEmitter<boolean>`**: Emits when the internal flag is reset after applying modifications.
- **`applyView: EventEmitter<InMemoryView>`**: Emits the view that should be applied to the grid.
- **`applyViewAndJSON: EventEmitter<InMemoryView>`**: Emits a view and triggers additional JSON‑based form field updates via the service.

### Example

```html
<gias-grid-customizations
  [(canApplyChanges)]="canApplyChanges"
  [options]="gridCustomizations"
  [showSwitch]="true"
  (applyView)="onApplyView($event)">
</gias-grid-customizations>
```

```ts
canApplyChanges = false;
gridCustomizations: GridCustomizations = {/* ... */};

onApplyView(view: InMemoryView) {
  this.grid.applyView(view);
}
```

---

## DynamicInputComponent (`<gias-dynamic-input>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/dynamic-input/dynamic-input.component.ts`  
**Selector**: `gias-dynamic-input`

### What it does

Renders a dynamic input control (text, textarea, dropdown, checkbox, date, numeric, etc.) based on a `DynamicInputSettigs` object stored on the current row, and synchronizes changes back to the row while invoking an optional `onEdit` callback.

### Inputs

| Name      | Type                  | Description |
| --------- | --------------------- | ----------- |
| `input`   | `any`                 | Current row data item that contains the dynamic settings and actual value fields. |
| `field`   | `any`                 | Property name on `input` holding a `DynamicInputSettigs` instance. |
| `edit`    | `boolean`             | Whether the control is rendered in edit mode. |

The `DynamicInputSettigs` object includes:

- `controlType: enum_TipoControllo` – which UI control to use (textbox, dropdown, checkbox, date, numeric, etc.).  
- `realField: string` – actual field on `input` that stores the value.  
- Optional settings objects: `ddl`, `numeric`, `boolean`, `date`, `string`.  
- Optional `onEdit(newValue: any)` callback executed after updates.

### Outputs

None directly; value updates happen by mutating `input[realField]` and calling `onEdit`.

### Example

```ts
row.dynamicSettings = new DynamicInputSettigs({
  controlType: enum_TipoControllo.NUMERO_DECIMALE,
  realField: 'price',
  onEdit: (updatedRow) => console.log('Row updated', updatedRow)
});
```

```html
<gias-dynamic-input
  [input]="row"
  [field]="'dynamicSettings'"
  [edit]="true">
</gias-dynamic-input>
```

---

## GridBooleanComponent (`<gias-grid-boolean>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-boolean/grid-boolean.component.ts`  
**Selector**: `gias-grid-boolean`

### What it does

Boolean cell editor/renderer tied to a reactive form control, optionally using a checkbox UI. It can create its own `FormGroup` when one is not provided.

### Inputs

| Name          | Type          | Description |
| ------------- | ------------- | ----------- |
| `formGroup`   | `FormGroup \| any` | Row form group containing the boolean control. If omitted, the component creates an internal group. |
| `controlName` | `string`      | Name of the control within `formGroup`. Defaults to `'value'` when an internal group is created. |
| `defaultValue`| `boolean`     | Initial value when creating an internal form group; also used to sync the underlying checkbox. |
| `editable`    | `boolean`     | Enables or disables the control. |
| `useCheckbox` | `boolean`     | Whether to use a checkbox visual (true) or alternative representation. |

### Outputs

- **`valueChange: EventEmitter<boolean>`**: Emits when the value changes (e.g. user toggles checkbox).

### Example

```html
<gias-grid-boolean
  [formGroup]="formGroup"
  controlName="isActive"
  [defaultValue]="true"
  [editable]="!readOnly"
  [useCheckbox]="true"
  (valueChange)="onActiveChange($event)">
</gias-grid-boolean>
```

---

## CustomizationDropdownComponent (`<gias-customization-dropdown>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-customizations/dropdown/customization-dropdown.component.ts`  
**Selector**: `gias-customization-dropdown`

### What it does

Dropdown used to select, filter, and create grid views for the customizations feature. It stays in sync with the internal `GridCustomizationsService` and emits view‑related events.

### Inputs

| Name       | Type             | Description |
| ---------- | ---------------- | ----------- |
| `selected` | `DropdownListItem` | Currently selected view item. |

### Outputs

- **`selectedChange: EventEmitter<DropdownListItem>`**: Emits when the selected item changes.
- **`applyView: EventEmitter<ApplyViewEvent>`**: Requests applying a view (regular path).
- **`applyViewAndJSON: EventEmitter<ApplyViewEvent>`**: Requests applying a view and JSON‑based form updates when there is an associated form.
- **`sourceChange: EventEmitter<DropdownListItem[]>`**: Emits when the list of available items is updated (e.g. after creating a new view).

### Example

```html
<gias-customization-dropdown
  [(selected)]="selectedView"
  (applyView)="onApplyView($event)"
  (applyViewAndJSON)="onApplyViewAndJson($event)">
</gias-customization-dropdown>
```

---

---

## GridDropdownListComponent (`<gias-grid-ddl>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-dropdownlists/grid-dropdownlist.component.ts`  
**Selector**: `gias-grid-ddl`

### What it does

Single‑select dropdown editor for grid cells integrated with reactive forms and internal grid services, including remote updates and dynamic data loading.

### Inputs

| Name          | Type                    | Description |
| ------------- | ----------------------- | ----------- |
| `useForm`     | `boolean`               | Toggles form integration mode. |
| `column`      | `KendoGridColumn`       | Column metadata associated with this dropdown. |
| `id`          | `string`                | Identifier used to correlate dropdown events. |
| `filterable`  | `boolean`               | Enables client‑side filtering of items. |
| `defaultItem` | `DropdownListItem`      | Default placeholder item. |
| `textField`   | `string`                | Field name for display text in items. |
| `valueField`  | `string`                | Field name for the item’s value. |
| `valuePrimitive` | `boolean`           | When true, the bound value is a primitive instead of an object. |
| `controlName` | `string`                | Form control name in `formGroup`. |
| `formGroup`   | `FormGroup`             | Parent row form group. |
| `selected`    | `DropdownListItem`      | Currently selected item. |
| `ddl`         | `DropdownListWithForm`  | Extended dropdown configuration (reload observable, etc.). |
| `source`      | `DropdownListItem[]`    | Initial list of items. |

### Outputs

- **`selectedChange: EventEmitter<DropdownListItem>`**: Emits when selection changes.
- **`valueChange: EventEmitter<DropdownListEvent>`**: Emits structured dropdown events on value change.
- **`open: EventEmitter<DropdownListEvent>`**: Emits when the dropdown is opened.
- **`reload: EventEmitter<DropdownListEvent>`**: Emits when a reload of items is requested. |
- **`sourceChange: EventEmitter<DropdownListItem[]>`**: Emits when the source list changes. |

### Example

```html
<gias-grid-ddl
  [formGroup]="formGroup"
  [column]="column"
  [id]="column.field"
  [controlName]="column.ddl.formControlName"
  [filterable]="true"
  [source]="countries"
  (valueChange)="onCountryChange($event)">
</gias-grid-ddl>
```

---

## GridMultiDropdownComponent (`<gias-grid-multi-ddl>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-multi-dropdownlist/grid-multi-dropdownlist.component.ts`  
**Selector**: `gias-grid-multi-ddl`

### What it does

Multi‑select dropdown editor for grid cells, using Kendo MultiSelect under the hood and integrating with reactive forms and grid services.

### Inputs

| Name          | Type                   | Description |
| ------------- | ---------------------- | ----------- |
| `useForm`     | `boolean`              | Enables integration with a row `FormGroup`. |
| `id`          | `string`               | Identifier for dropdown events. |
| `filterable`  | `boolean`              | Enables filtering of items. |
| `defaultItem` | `DropdownListItem`     | Default placeholder item. |
| `textField`   | `string`               | Display text field name. |
| `valueField`  | `string`               | Value field name. |
| `valuePrimitive` | `boolean`          | When true, selected values are primitives. |
| `controlName` | `string`               | Form control name in `formGroup`. |
| `formGroup`   | `FormGroup`            | Parent row form group. |
| `selected`    | `DropdownListItem`     | Currently selected entry (for convenience). |
| `ddl`         | `DropdownListWithForm` | Extended dropdown configuration (including `reload`). |
| `defaultOpen` | `boolean`              | When true, opens the dropdown by default. |
| `source`      | `DropdownListItem[]`   | Source items list. |

### Outputs

- **`valueChange: EventEmitter<DropdownListEvent>`**: Emits when the selection changes.
- **`open: EventEmitter<DropdownListEvent>`**: Emits on dropdown open.
- **`reload: EventEmitter<DropdownListEvent>`**: Emits when a reload is requested via `ddl.reload`. |
- **`sourceChange: EventEmitter<DropdownListItem[]>`**: Emits when `source` changes. |

### Example

```html
<gias-grid-multi-ddl
  [formGroup]="formGroup"
  controlName="tags"
  [id]="'tags'"
  [filterable]="true"
  [source]="tagOptions"
  [defaultOpen]="false"
  (valueChange)="onTagsChange($event)">
</gias-grid-multi-ddl>
```

---

## GridNumericComponent (`<gias-grid-numeric>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/grid-numeric/grid-numeric.component.ts`  
**Selector**: `gias-grid-numeric`

### What it does

Simple numeric display/editor component, usually used in grid templates to render numbers with optional constraints.

### Inputs

| Name   | Type    | Description |
| ------ | ------- | ----------- |
| `value`| `number`| Current numeric value. |
| `min`  | `number`| Minimum allowed value (used by the template). |
| `max`  | `number`| Maximum allowed value (used by the template). |

### Outputs

None (value changes, if any, are handled via the template and external bindings).

### Example

```html
<gias-grid-numeric
  [value]="item.amount"
  [min]="0"
  [max]="1000">
</gias-grid-numeric>
```

---

## DateRangeFilterComponent (`<gias-date-range-filter-cell>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/multicheck-filter/date-range-filter/date-range-filter.component.ts`  
**Selector**: `gias-date-range-filter-cell`

### What it does

Custom filter cell implementation that provides a date range picker with basic and advanced modes. It transforms selected dates into Kendo filter descriptors and emits them to be applied on a grid column.

### Inputs

| Name           | Type                      | Description |
| -------------- | ------------------------- | ----------- |
| `filter`       | `CompositeFilterDescriptor` | Current filter descriptor for the column. |
| `filterService`| `FilterService`           | Kendo grid filter service used to apply filters. |
| `manager`      | `IManager`                | Manager used to coordinate selection/all operations. |
| `field`        | `string`                  | Column field being filtered. |

### Outputs

- **`filterChange: EventEmitter<DateFilters>`**: Emits the selected start/end dates and the composed filter descriptor to be applied.

### Example

```html
<kendo-grid-column field="createdAt" title="Created at">
  <ng-template kendoGridFilterCellTemplate let-filter let-filterService="filterService">
    <gias-date-range-filter-cell
      [field]="'createdAt'"
      [filter]="filter"
      [filterService]="filterService"
      [manager]="dateRangeManager"
      (filterChange)="onDateRangeFilter($event)">
    </gias-date-range-filter-cell>
  </ng-template>
</kendo-grid-column>
```

---

## MultiCheckFilterComponent (`<gias-multicheck-filter>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/multicheck-filter/multicheck-filter.component.ts`  
**Selector**: `gias-multicheck-filter`

### What it does

Multi‑check filter UI that displays distinct values for a column (string, number, date, dropdown, multi‑dropdown) and allows selecting multiple values to build filter descriptors via specialized managers.

### Inputs

| Name           | Type         | Description |
| -------------- | ------------ | ----------- |
| `type`         | `CELL_TYPES` | Cell type for the column (string, date, dropdown, etc.). |
| `isPrimitive`  | `boolean`    | Whether underlying values are primitives. |
| `currentFilter`| `any`        | Current filter state for the column. |
| `textField`    | `any`        | Field used as display text. |
| `valueField`   | `any`        | Field used as value. |
| `filterService`| `FilterService` | Kendo filter service instance. |
| `field`        | `string`     | Column field name. |
| `multiIndex`   | `number`     | Multi‑grid index when multiple grids share services. |
| `showHTMLAsString` | `boolean`| Whether HTML should be treated as plain text. |
| `ordering`     | `(rows: any) => any \| null` | Optional custom ordering of filter items. |

### Outputs

- **`valueChange: EventEmitter<number[]>`**: Emits the selected value IDs when the filter selection changes.

### Example

```html
<gias-multicheck-filter
  [type]="STRING"
  [field]="'customerName'"
  [filterService]="filterService"
  [currentFilter]="filter"
  (valueChange)="onNameFilterChange($event)">
</gias-multicheck-filter>
```

---

## ToolbarColumnMenuComponent (`<gias-toolbar-column-menu>`)

**Location**: `projects/gias-kendo-grid/src/lib/Template/kendo-grid/components/toolbar-column-menu/toolbar-column-menu.component.ts`  
**Selector**: `gias-toolbar-column-menu`

### What it does

Simple toolbar component that toggles column visibility by flipping the `hidden` flag on `KendoGridColumn` items.

### Inputs

| Name      | Type              | Description |
| --------- | ----------------- | ----------- |
| `columns` | `KendoGridColumn[]` | Collection of columns to show/hide. |

### Outputs

None; it mutates the `hidden` property directly on the provided column objects.

### Example

```html
<gias-toolbar-column-menu
  [columns]="columns">
</gias-toolbar-column-menu>
```

