import { HttpClient, HttpResponseBase } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IGiasMasterService, rispostaStandard, RispostaStandard, ErroreGias, ConversionService, GiasDialogService } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class CoreWS_GenericPayload {
    obj: CoreWS_GenericObjP;
    constructor(obj: CoreWS_GenericObjP);
}
export declare class CoreWS_Generic<T> extends CoreWS_GenericPayload {
    InData: T;
    constructor(objP: CoreWS_GenericObjP, InData: T);
}
export declare class CoreWS_GenericObjP {
    objP_super_server: string;
    objP_server: string;
    objP_utenti: string;
}
export declare class AjaxAgronicaService {
    private http;
    private giasMasterService;
    private conversionService;
    private giasDialogService;
    constructor(http: HttpClient, giasMasterService: IGiasMasterService, conversionService: ConversionService, giasDialogService: GiasDialogService);
    ajaxAgronicaCoreWS_Promise<InType, OutType>(url: any, parametri: CoreWS_Generic<OutType>, setLoading?: boolean, showErroriGestiti?: boolean): Promise<rispostaStandard<InType>>;
    ajaxCoreWSPost<InType, OutType>(url: string, parametri: CoreWS_Generic<InType>, setLoading?: boolean, compressione?: boolean, showErroriGestiti?: boolean): Observable<rispostaStandard<OutType>>;
    ajaxAgronica(url: any, parametri: any, compressione?: boolean, showErroriGestiti?: boolean): Promise<RispostaStandard>;
    ajaxAgronicaObs(url: any, parametri: any, compressione?: boolean, showErroriGestiti?: boolean): Observable<RispostaStandard>;
    ajaxAgronicaG<T>(url: any, parametri: any, compressione?: boolean, showErroriGestiti?: boolean): Promise<rispostaStandard<T>>;
    /**
   * Per le chiamate utilizzando codice vecchio non ancora adattato alla
   * nuova modalità di caricare i dati (tramite RispostaStandard generic).
   * @param url Endpoint.
   * @param parametri I parametri che compaiono nella testata della chiamata.
   * @returns il risultato della chiamata http.
   */
    legacy_get(url: any, parametri: any, displayErrorMessage?: boolean, compressione?: boolean): Observable<RispostaStandard>;
    post<T>(url: any, parametri: any, compressione?: boolean, gestisciErrore?: boolean, showErroriGestiti?: boolean): Observable<rispostaStandard<T>>;
    ajaxAgronicaCoreWS_GenericsObs<T1, T2>(url: any, parametri: CoreWS_Generic<T2>, compressione?: boolean, showErroriGestiti?: boolean): Observable<rispostaStandard<T1>>;
    ajaxCoreWSGet<OutType>(url: string, showErroriGestiti?: boolean): Observable<rispostaStandard<OutType>>;
    private ajaxPost;
    errorHandling(error: HttpResponseBase): Observable<any>;
    rispostaOK_FalseHandling(r: rispostaStandard<any>, showErroriGestiti: boolean): Observable<any>;
    handleErrori_NonGestiti(errori: ErroreGias[]): void;
    handleErrori_Gestiti(errori: ErroreGias[]): void;
    private decomprimi;
    static ɵfac: i0.ɵɵFactoryDeclaration<AjaxAgronicaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AjaxAgronicaService>;
}
