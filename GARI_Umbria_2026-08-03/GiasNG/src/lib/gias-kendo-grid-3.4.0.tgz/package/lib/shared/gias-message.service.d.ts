import { TranslocoService } from '@jsverse/transloco';
import { NotificationRef, NotificationService } from "@progress/kendo-angular-notification";
import { CustomMessageComponent, CustomMessageService } from './custom-message.service';
import { Dialog_Type } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class GiasMessageService {
    private notificationService;
    private transloco;
    private customMessageService;
    private hideAfter;
    private errorOpen;
    private errorsVisible;
    customMessageComponent: typeof CustomMessageComponent;
    constructor(notificationService: NotificationService, transloco: TranslocoService, customMessageService: CustomMessageService);
    successMessage(content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    infoMessagge(content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    errorMessage(content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    warningMessage(content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    noneMessage(content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    setErrorOpen(status: boolean): void;
    message(messageType: Dialog_Type, content: string, closable?: boolean, useTransloco?: boolean, translocoParams?: string[], hideAfter?: number): NotificationRef;
    customMessage(contentString: string, actionString: string, color: string, customFunction: any, closable?: boolean, hideAfter?: number): NotificationRef;
    private showMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GiasMessageService>;
}
