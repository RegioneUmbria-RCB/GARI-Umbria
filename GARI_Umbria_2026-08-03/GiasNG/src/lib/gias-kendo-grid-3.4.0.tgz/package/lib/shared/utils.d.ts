import { ServerResult, KendoServerResult, KendoGridColumn, KendoGridModel, KendoGridRow, ModelEntry } from '../Template/kendo-grid/models/grid.model';
import { enum_logDebugArea, enum_logDebugTipo } from './log-debug';
import { HashMap } from '@jsverse/transloco';
import { CommandsDropDownEvents } from '../Template/kendo-grid/models/configuration.model';
import * as i0 from "@angular/core";
export declare class UtilsService {
    getPrimitiveValueDDL(value: any): any;
    getPrimitiveValue(obj: any, field: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UtilsService>;
}
export declare const isNullOrUndefined: (obj: any) => boolean;
export declare const isUndefined: (obj: any) => boolean;
export declare const separatoreChiaveAlbero = "\u00A7";
export declare const separatoreFiltroAlbero = "<$&\u00A7>";
export declare const qualsiasiLogDebug = "*";
export declare function parseServerResult(table: ServerResult): KendoServerResult;
export declare function NumToStr(num: number): string;
export declare function StringToDate(data: any): Date;
export declare function DateToString(data: Date): string;
export declare function getServiceIdAndLog(nomeServizio: string, messaggio: string): string;
export declare function getComponentIdAndLog(nomeComponente: string, messaggio: string): string;
export declare function consoleLogDebug(debugArea: enum_logDebugArea, debugTipo: enum_logDebugTipo, nomeComponenteServizio: string, messaggio: string): void;
export declare function consoleLogDebugParam(debugArea: enum_logDebugArea, debugTipo: enum_logDebugTipo, nomeComponenteServizio: string, messaggio: string, param: any): void;
export declare function consoleLogDebugMultiParam(debugArea: enum_logDebugArea, debugTipo: enum_logDebugTipo, nomeComponenteServizio: string, messaggio: string, param: any[]): void;
export declare const TableQdCLink = "Agenda/CaricaOperazioni";
export declare class ReadDataFilters {
    filtro: string;
    piva: string;
    objP_server: string;
    objP_utenti: string;
}
export declare class Filters {
    TipoGriglia: string;
    xFiltroAggiuntivo_colturali: string;
    txt_Data1: string;
    txt_Data2: string;
    flag_TerrenoNudo: boolean;
    sa_cod: string;
    veg_cod: string;
    mode: string;
    ricetta_cod: string;
    tipoOperazione: number[];
    impianti: string[];
    constructor(params: Required<Filters>);
}
export declare class RicetteServerResult extends KendoServerResult {
    constructor(model: KendoGridModel, columns: KendoGridColumn[], rows: RicettaRow[]);
}
export declare class BrogliaccioServerResult extends KendoServerResult {
    constructor(model: KendoGridModel, columns: KendoGridColumn[], rows: KendoGridRow[]);
}
export type DDLs = (CentroItem[] | SpecieItem[] | OperazioneItem[] | ImpiantoItem[] | TipoVisitaItem[])[];
export declare function ValidValuesFor(specie: SpecieItem, centro: CentroItem): boolean;
export declare function GetOperazioniParams(objServer: string): OperazioniParams;
export declare function GetCentriParams(obj_server: string, piva: string): CentriParams;
export declare function GetCentriParams_NG(obj_server: string, piva: string): CentriParams_NG;
export declare function GetSpeciParams(obj_server: string, piva: string): SpeciParams;
export declare const IMPIANTI_LNK: string;
export declare const OPERAZIONI_LNK: string;
export declare const SPECI_LNK: string;
export declare const CENTRI_LNK: string;
export interface OperazioniParams {
    objP_server: string;
    Flag_OpColturali: boolean;
    Flag_OpZoo: boolean;
    Flag_OpMacchine: boolean;
    Flag_OpContabili: boolean;
}
export interface ImpiantiParams {
    piva: string;
    Sa_Cod: string;
    Veg_Cod: string;
    Data_Inizio: Date;
    Data_Fine: Date;
}
export interface SpeciParams {
    PrimaRiga_Flag: boolean;
    PrimaRiga_Text: string;
    PrimaRiga_Value: string;
    Piva: string;
    Sa_Cod: number;
    Data_Da: Date;
    Data_A: Date;
    ConsideraTerrenoNudo: boolean;
    leggiAncheBloccati: boolean;
}
export interface CentriParams {
    objP_server: string;
    PrimaRiga_Flag: boolean;
    PrimaRiga_Text: string;
    PrimaRiga_Value: string;
    Piva: string;
    Flag_SoloCentriAttivi: boolean;
    Tipo_Value: number;
}
export interface CentriParams_NG {
    PrimaRiga_Flag: boolean;
    PrimaRiga_Text: string;
    PrimaRiga_Value: string;
    Piva: string;
    Flag_SoloCentriAttivi: boolean;
    Tipo_Value: number;
}
export interface CentroItem {
    sa_nome: string;
    sa_cod: string;
}
export interface SpecieItem {
    veg_cod: string;
    veg_des: string;
}
export interface OperazioneItem {
    gru_cod: number;
    gru_des: string;
    tipo: string;
}
export interface ImpiantoItem {
    chiave: string;
    des: string;
}
export interface TipoVisitaItem {
    chiave: number;
    des: string;
}
export declare class RicettaForm {
    dataInizio: Date;
    dataFine: Date;
    numero: string;
    descrizione: string;
    nota: string;
}
export declare class CreateRecipeData {
    lblHtmlRicettaDaCreare: string;
    piva_ricetta: string;
    sa_cod: number;
    id_agenda: string;
    stesso_vag_cod: boolean;
    ErroreSingolaSpecie: string;
    data_operazione: string;
    ricettaForm: RicettaForm;
    prevent: boolean;
    constructor();
}
export declare class GridMassiveEvent {
    items: KendoGridRow[];
    type: emun_MassiveEventType;
}
export declare enum emun_MassiveEventType {
    REMOVE = 0,
    LOCK = 1
}
export declare const RicetteNumLink = "Agenda/ricetta_numero_default";
export declare const CreateRicettaLink = "Agenda/crea_ricetta";
export declare const CopiaOperazioneSingola = "Agenda/CopiaOperazioneSingola";
export declare const BloccaAttivitaAgendaLink = "Agenda/BloccaAttivitaAgenda";
export declare const SbloccaAttivitaAgendaLink = "Agenda/SbloccaAttivitaAgenda";
export declare class RicettaModalParams {
}
export declare const lav_cod_non_editabili: number[];
export declare const lav_cod_copiabili: number[];
export declare enum TabTypes {
    QuadernoDiCampagna = 0,
    Ricette = 1,
    Brogliaccio = 2,
    Initializer
}
export declare enum RibaltamentoTypes {
    Nessuno = 0,
    Da_Brogliaccio_ad_Agenda = 1,
    Da_Ricetta_a_Brogliaccio = 2,
    Da_Ricetta_ad_Agenda = 3
}
export declare class RicettaRow extends KendoGridRow {
    App_Nome: string;
    APP_Ricetta_Operazione_ID: string;
    blocco_flag: string;
    Costi_Macchine: string;
    Costi_Operatori: string;
    Descrizione_Unica: string;
    Dettaglio_Tecnico: string;
    in_uso: string;
    Invia_App: string;
    lav_cod: number;
    lav_des: string;
    PermessoModifica: string;
    piva: string;
    Ricetta_Cod: number;
    Ricetta_Des: string;
    Ricetta_Numero: string;
    Ricetta_Operazione_Cod: number;
    Ricetta_Operazione_Data: Date;
    Sa_Cod: number;
    sa_nome: string;
    Sup_Trattata: number;
    Tipo_Ricetta_des: string;
    Tipo_Ricetta: number;
    Validita_Fine: Date;
    Validita_Inizio: Date;
    veg_cod_op: number;
    veg_cod_r: number;
    veg_des_unificato: string;
    WAnagraficaStati_Cod: number;
    WAnagraficaStati_Colore: string;
}
export declare class QdCRow extends KendoGridRow {
    Appezzamenti_Coinvolti: string;
    Avversita: string;
    blocco_flag: string;
    Centro_Aziendale: string;
    Centro_Campo: string;
    chiave_composita: string;
    contabilizzato: string;
    Costi_Macchine: string;
    Costi_Operatori: string;
    Creatore_Intervento: string;
    cul_Des: string;
    Data: Date;
    Data_Ultima_Modifica_Intervento: Date;
    Data2: Date;
    Descrizione_Unica: string;
    Dettaglio_Tecnico: string;
    gru_des: string;
    ID: string;
    id_agenda: string;
    id_mov_det: string;
    Lav_cod: string;
    Lav_Des: string;
    LottiImpianto: string;
    LottiProduzione: string;
    Note: string;
    Operazione_DES: string;
    PermessoModifica: boolean;
    Piva: string;
    Prodotti_Utilizzati: string;
    Rag_Soc: string;
    Ricetta_Cod: string;
    Ricetta_Des: string;
    sa_cod: string;
    Specie: string;
    Specie_Varieta: string;
    Sup_Trattata: number;
    tipo: string;
    Veg_cod: string;
}
export interface BrogliaccioRow extends KendoGridRow {
    App_Nome: string;
    APP_Ricetta_Operazione_ID: string;
    blocco_flag: string;
    Costi_Macchine: string;
    Costi_Operatori: string;
    Descrizione_Unica: string;
    Dettaglio_Tecnico: string;
    in_uso: string;
    lav_cod: number;
    lav_des: string;
    Origine: string;
    PermessoModifica: string;
    piva: string;
    Ricetta_Cod: number;
    Ricetta_Des: string;
    Ricetta_Numero: string;
    Ricetta_Operazione_Cod: number;
    Ricetta_Operazione_Data: string;
    Sa_Cod: number;
    sa_nome: string;
    Sup_Trattata: number;
    Tipo_Ricetta_des: string;
    Tipo_Ricetta: number;
    Validita_Fine: string;
    Validita_Inizio: string;
    veg_cod_op: number;
    veg_cod_r: number;
    veg_des_unificato: string;
    WAnagraficaStati_Cod: number;
    WAnagraficaStati_Colore: string;
}
export declare const SLIGHTLY_DIFFERENT_CODE_FROM_GIAS2010 = "Manca la gestione di .btnCreaOp. Sembra di essere commentato e non utilizzato in GIAS2010.";
export declare const DA_GESTIRE_PUA = "PUA non gestito";
export declare const DA_GESTIRE_PIANO_DISTRIBUZIONE_CONCIMI = "non gestito";
export declare class ImpostazioniApp {
    ImportaSoloAziendaSelezionata: boolean;
    SincroDatiApp: boolean;
}
export declare function isQdCRow(x: any): x is QdCRow;
export declare function isBrogliaccioRow(x: any): x is BrogliaccioRow;
export declare class GridZooResult extends KendoServerResult {
    constructor(model: ZooModel, columns: KendoGridColumn[], rows: KendoGridRow[]);
}
export declare class ZooModel extends KendoGridModel {
    [value: string]: ModelEntry;
}
export declare class ZooRow extends KendoGridRow {
    id_mov_det: 147915;
    id_agenda: string;
    Data2: Date;
    Lav_Des: string;
    Prodotti_Utilizzati: string;
    Dettaglio_Tecnico: string;
    Centro_Aziendale: string;
    chiave_composita: string;
    tipo: string;
    Data: Date;
    contabilizzato: string;
    LottiProduzione: string;
    Note: string;
    Costi_Operatori: string;
    Costi_Macchine: string;
    Creatore_Intervento: string;
    ID: number;
    Lav_cod: string;
    blocco_flag: string;
    Piva: string;
    sa_cod: string;
    Operazione_DES: string;
    Prodotti: string;
    Rag_Soc: string;
    PermessoModifica: string;
    Descrizione_Unica: string;
}
export declare const Link_ElimOpMultipla = "Agenda/EliminaOperazioneMultipla";
export declare function construisciChiaviComposite(rows: QdCRow[] | ZooRow[]): string;
export declare enum enum_menuAgendaGridCommands {
    RICERCA_DOCUMENTI = 0,
    NUOVO_ALLEGATO = 1,
    VAI_AI_COSTI = 2,
    COPIA = 3,
    AGGIUNGI_RICETTA = 4,
    STAMPA_RICETTA = 5,
    STAMPA_ORDINE_LAVORO = 6,
    BROGLIACCIO = 7,
    QUADERNO_DI_CAMPAGNA = 8,
    INFO = 9,
    MODIFICA = 10,
    CANCELLA = 11,
    VAI_AL_PIANO_CONCIMAZIONE = 12,
    IMPORTA_NEL_PUA = 13,
    VAI_ALLA_VISITA = 14
}
export interface IMenuAgendaGridCommand {
    action: enum_menuAgendaGridCommands;
    event: any;
    dataItem: any;
}
export declare class GridCommandItem {
    actionName: string;
    action: CommandsDropDownEvents | number;
    iconClass?: string;
    fontawesomeIcon?: any;
    isStatic: boolean;
    paramsforTrasloco: HashMap;
    constructor(actionName: string, action: CommandsDropDownEvents | number, iconClass?: string, fontawesomeIcon?: any, isStatic?: boolean, paramsforTrasloco?: HashMap);
}
