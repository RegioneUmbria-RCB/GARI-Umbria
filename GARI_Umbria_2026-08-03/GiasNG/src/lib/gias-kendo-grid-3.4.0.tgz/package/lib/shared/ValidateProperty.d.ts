import { AbstractControl, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';
import { KendoGridRow } from '../Template/kendo-grid/models/grid.model';
export declare class PropertyValidator implements Validator {
    private property;
    private validatorFn?;
    row: KendoGridRow;
    private validators;
    constructor(property: string, validatorFn?: CustomValidatorFn);
    validate(control: AbstractControl): ValidationErrors;
    setCurrentRow(row: KendoGridRow): void;
    private resetValidators;
}
type CustomValidatorFn = (formctrl: any) => ValidatorFn;
export declare class PropertyValidatorFields {
}
export {};
