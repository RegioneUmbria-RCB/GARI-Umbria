import * as i0 from "@angular/core";
export declare class CustomMessageService {
    private contextString;
    private action;
    private color;
    private customFunction;
    getContextString(): string;
    getAction(): string;
    getColor(): string;
    getCustomFunction(): any;
    createCustomMessage(contextString: string, action: string, color: string, customFunction: any): void;
    getCustomMessageComponent(): typeof CustomMessageComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomMessageService>;
}
export declare class CustomMessageComponent {
    private customMessageService;
    message: string;
    action: string;
    color: string;
    customFunction: any;
    constructor(customMessageService: CustomMessageService);
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomMessageComponent, "gias-custom-message-component", never, {}, {}, never, never, true, never>;
}
