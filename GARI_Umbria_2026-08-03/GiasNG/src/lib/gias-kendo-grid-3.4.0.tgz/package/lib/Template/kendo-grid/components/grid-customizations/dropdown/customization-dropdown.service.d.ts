import { TranslocoService } from '@jsverse/transloco';
import { BehaviorSubject } from 'rxjs';
import { DropdownList, DropdownListItem as DropdownItem, DropdownListItem } from '../../../models/grid.model';
import { DropdownChanged, InMemoryView } from '../model';
import { GiasMessageService } from '../../../../../shared/gias-message.service';
import * as i0 from "@angular/core";
export declare class CustomizeDropdownService extends BehaviorSubject<DropdownChanged> {
    private transloco;
    private giasMessageService;
    constructor(transloco: TranslocoService, giasMessageService: GiasMessageService);
    extractDropdownItems(data: InMemoryView[]): DropdownItem[];
    generateDropdownId(GridId: string): string;
    getItemId(GridId: string, id: string, NomeUtente: string): string;
    generateUID(): string;
    nextSelected(dropdown: DropdownList): DropdownItem;
    getNewDDL(input: DropdownList, items: DropdownListItem[]): DropdownList;
    showMessage(message: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomizeDropdownService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomizeDropdownService>;
}
