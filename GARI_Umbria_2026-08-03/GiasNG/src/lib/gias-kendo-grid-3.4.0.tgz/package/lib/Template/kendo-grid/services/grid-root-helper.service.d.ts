import { Subject } from 'rxjs';
import { NextDropdownValue } from '../components/grid-dropdownlists/grid-dropdown.service';
import * as i0 from "@angular/core";
export declare class GridRootHelper {
    nextDropdownValue: Subject<NextDropdownValue>;
    nextMultiDropdownValue: Subject<NextDropdownValue>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridRootHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridRootHelper>;
}
