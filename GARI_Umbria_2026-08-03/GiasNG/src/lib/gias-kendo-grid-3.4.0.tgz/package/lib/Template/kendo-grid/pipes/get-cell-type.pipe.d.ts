import { PipeTransform } from '@angular/core';
import { KendoGridColumn } from '../models/grid.model';
import { KendoGridService } from '../services/kendo-grid.service';
import * as i0 from "@angular/core";
export declare class CellTypePipe implements PipeTransform {
    services: KendoGridService;
    private service;
    constructor(services: KendoGridService);
    transform(column: KendoGridColumn): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CellTypePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CellTypePipe, "cellType", false>;
}
