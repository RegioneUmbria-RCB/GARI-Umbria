import { KendoServerResult } from "../models/grid.model";
export declare class GridDataWithFilter {
    stopPropagation?: boolean;
    data: KendoServerResult;
    forceRefresh: boolean;
    afterEdit: boolean;
    constructor(opts: Partial<GridDataWithFilter>);
}
