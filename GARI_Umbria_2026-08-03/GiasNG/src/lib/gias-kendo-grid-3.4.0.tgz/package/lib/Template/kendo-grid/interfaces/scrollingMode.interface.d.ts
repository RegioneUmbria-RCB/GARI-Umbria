import { GridDataResult } from '@progress/kendo-angular-grid';
import { GiasKendoGridComponent } from '../kendo-grid.component';
import { ScrollingMode } from '../models/configuration.model';
import { KendoServerResult } from '../models/grid.model';
import { ScrollableScrollingService } from '../useCases/scrollableScrolling.service';
import { VirtualScrollingService } from '../useCases/virtualScrolling.service';
export interface IScrollingMode {
    rowHeight: number;
    get pageSize(): number;
    get totalCount(): number;
    loadData(kData: KendoServerResult): GridDataResult;
    isVirtual(): this is VirtualScrollingService;
}
declare class ScrollingFactoryOpts {
    mode: ScrollingMode;
    componentContext: GiasKendoGridComponent;
}
export declare class ScrollingModeFactory {
    static Create(opts: ScrollingFactoryOpts): VirtualScrollingService | ScrollableScrollingService;
}
export {};
