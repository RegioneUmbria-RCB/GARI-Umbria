import { ElementRef } from '@angular/core';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { Subject } from 'rxjs';
import { DropdownListItem } from '../../models/grid.model';
export declare abstract class MulticheckInput {
    textField: string;
    valueField: string;
    currentFilter: CompositeFilterDescriptor;
    allRows: any[];
    store: {
        [key: string]: string[];
    };
    field: string;
    shutdownPagination: Subject<void>;
    ordering: (rows: any) => any | null;
}
export declare enum WorkType {
    String = 0,
    Dropdown = 1
}
export declare const operators: DropdownListItem[];
export declare const logicalOperators: DropdownListItem[];
export declare class PopupSettingsManager {
    settings: any;
    filterContainer: any;
    initializeFilterContainer(element: ElementRef<any>): void;
}
export declare const closest: (node: any, predicate: any) => any;
