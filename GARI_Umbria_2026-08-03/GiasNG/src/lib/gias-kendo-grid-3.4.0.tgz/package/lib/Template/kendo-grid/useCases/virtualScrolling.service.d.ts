import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs';
import { IScrollingMode } from '../interfaces/scrollingMode.interface';
import { GeneralSettings, PaginationSettings, ScrollingMode } from '../models/configuration.model';
import { KendoServerResult } from '../models/grid.model';
import { KendoGridService } from '../services/kendo-grid.service';
export interface VirtualScrollingParams {
    generalSettings: GeneralSettings;
    pagination: PaginationSettings;
    gridPrivate: KendoGridService;
}
export declare class VirtualScrollingService implements IScrollingMode {
    mode: ScrollingMode;
    rowHeight: number;
    private _pageSize;
    private _totalCount;
    private pagination;
    private gridPrivate;
    constructor(opts: VirtualScrollingParams);
    get pageSize(): number;
    get totalCount(): number;
    private get gridState();
    private get settings();
    private get skip();
    private set skip(value);
    isVirtual(): this is VirtualScrollingService;
    calculateRequiredFields(): void;
    pageChange(event: PageChangeEvent): Observable<GridDataResult>;
    loadData(data: KendoServerResult): GridDataResult;
    private computeGridStateBasedOn;
}
