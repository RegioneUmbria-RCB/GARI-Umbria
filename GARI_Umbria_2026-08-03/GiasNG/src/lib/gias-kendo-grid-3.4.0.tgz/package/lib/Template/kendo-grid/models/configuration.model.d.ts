import { GroupableSettings, PagerSettings, RowArgs, SelectableMode, SelectionEvent } from '@progress/kendo-angular-grid';
import { AggregateDescriptor, SortDescriptor, State } from '@progress/kendo-data-query';
import { KendoGridRow } from './grid.model';
import { TemplateRef } from '@angular/core';
import { GridCommandItem } from '../../../shared/utils';
import { TranslocoService } from '@jsverse/transloco';
import { Observable } from 'rxjs';
export declare class AgrSelectableSettings {
    selectable?: SelectableSettings;
    columnSettings?: SelectableColumnSettings;
    preselectedRows?: PreselectedRowsSettings;
    shouldShowCheckbox?: boolean;
    get checkboxIsEnabled(): boolean;
    constructor(selectable?: SelectableSettings, columnSettings?: SelectableColumnSettings, preselectedRows?: PreselectedRowsSettings, shouldShowCheckbox?: boolean);
}
/**
 * Angular Documentation SelectableSettings
 * https://www.telerik.com/kendo-angular-ui/components/grid/api/SelectableSettings/
 */
export declare class SelectableSettings {
    /**
     * cell? boolean (default: false)
     * Determines if cell selection is allowed.
     */
    cell: boolean;
    /**
     * checkboxOnly? boolean (default: true)
     * Determines if the selection is performed only through clicking a checkbox.
     * If enabled, clicking the row itself will not select the row.
     * Applicable if at least one checkbox column is present.
     */
    checkboxOnly: boolean;
    /**
     * drag? boolean (default: false)
     * Determines if drag selection is allowed.
     */
    drag: boolean;
    /**
     * enabled? boolean (default: true)
     * Determines if selection is allowed.
     */
    enabled: boolean;
    /**
     * mode? SelectableMode (default: "multiple")
     * The available values are: single, multiple
     */
    mode: SelectableMode;
    disableAllcheckbox: boolean;
    /**
     * metaKeyMultiSelect? boolean (default: true)
     * Determine whether pressing the `Ctrl` or `Command` keys is required for the selection of multiple rows
     * at the same time.
     * Referring to the method of selection over row, not through checkboxes.
     * The selection must be set to `"multiple"` to use this feature.
     */
    metaKeyMultiSelect: boolean;
    constructor(opts: Partial<SelectableSettings>);
}
export declare class PreselectedRowsSettings {
    /** For the following functions to work selectable.enabled must be true. */
    /**
     * Questa funziona viene chiamata per tutte le righe.
     */
    isRowSelectedFn: (e: RowArgs, component: any) => boolean;
    /**
     * Viene richiamata per ogni selezione soltanto una volta.
     */
    selectionChangeFn: (event: SelectionEvent, component: any) => void;
    /**
     * Default selected rows.
     * @deprecated
     */
    selectedRows: string[];
    constructor();
}
export declare class SelectableColumnSettings {
    /**
     * Determines whether a select-all checkbox will be displayed in the header.
     */
    showSelectAll: boolean;
    /**
     * The title of the column.
     */
    title: string;
    /**
     * The width of the column.
     */
    width: number;
    /**
     *   Specifies if the column will be included in the column-chooser list.
     */
    includeInChooser: boolean;
    /**
     * Sticky selectable column.
     */
    sticky: boolean;
    /**
     * Specifies whether the column is reorderable or not.
     */
    reorderable: boolean;
}
export declare class ToolbarSettings {
    newItem: boolean;
    resetChanges: boolean;
    title: string;
    width: number;
    title_save_button: string;
    SaveBtn: boolean;
    customToolbar: boolean;
    constructor(newItem?: boolean, resetChanges?: boolean, title?: string, width?: number, title_save_button?: string, SaveBtn?: boolean, customToolbar?: boolean);
    showToolbar(): boolean;
}
export declare class AggregateSettings {
    enabled: boolean;
    descriptors: GiasAggregateDescriptor[];
    constructor(opts: Partial<AggregateSettings>);
}
export declare class GiasAggregateDescriptor implements AggregateDescriptor {
    field: string;
    aggregate: 'count' | 'sum' | 'average' | 'min' | 'max';
    format?: string;
}
export declare class GroupSettings {
    private translocoService;
    groupable: GroupableSettings;
    constructor(options: Partial<GroupSettings>, translocoService: TranslocoService);
}
export declare class CommandsColumnSettings {
    editBtn: boolean;
    removeBtn: boolean;
    infoBtn: boolean;
    title: string;
    editBtnTitle: string;
    showEditBtn: (row: KendoGridRow) => boolean;
    onDisableInfoBtn: (row: KendoGridRow) => boolean;
    onDisableEditBtn: (row: KendoGridRow) => boolean;
    onDisableRemoveBtn: (row: KendoGridRow) => boolean;
    width: number;
    locked: boolean;
    media: string;
    sticky: boolean;
    reorderable: boolean;
    constructor(options?: Partial<CommandsColumnSettings>);
    showCmdColumn(): boolean;
}
export declare enum CommandsDropDownEvents {
    INLINE_EDIT = 8,
    FULL_EDIT = 10,// value chosen for compability with enum_menuAgendaGridCommands
    REMOVE = 11,// value chosen for compability with enum_menuAgendaGridCommands
    INFO = 9,// value chosen for compability with enum_menuAgendaGridCommands
    COPY = 3,// value chosen for compability with enum_menuAgendaGridCommands
    USER_BIND = 12
}
/**
 * Used to configure the grid commands' drop down button.
 *
 * ---
 * **Public APIs**
 *
 * `addCommand` - Adds an item in the dropdown. Takes as input an instance of
 * GridCommandItem.
 *
 * `removeCommand` - Removes an item from the dropdown. Takes as input the
 * command's action to remove.
 *
 * `resetCommands` - resets the commands to their default (only static are visible).
 *
 * `showCmdDropDown` - return whether the dropdown button is visible or not.
 *
 * ---
 * @usageNotes More commands can be added/removed dynamically on the dropdown's
 * opening by subscribing to `openCommands` from GridPublicService.
 */
export declare class CommandsDropDownSettings {
    sticky: boolean;
    width: number;
    title: string;
    inlineEditBtn: boolean;
    fullEditBtn: boolean;
    removeBtn: boolean;
    infoBtn: boolean;
    userBindBtn: boolean;
    cmdList: Array<GridCommandItem>;
    private _cmdList;
    hidecmdDropDown: (row: KendoGridRow) => boolean;
    constructor(options?: Partial<CommandsDropDownSettings>);
    addCommand(cmd: GridCommandItem): void;
    addCommandAt(cmd: GridCommandItem, index: number): void;
    /** Only removes non-static buttons */
    removeCommand(cmdAction: number): void;
    removeAllCommand(): void;
    showCmdDropDown(): boolean;
    resetCommands(): void;
    private addDefaultButtons;
}
export declare class DettagliColumnSettings {
    editBtn: boolean;
    infoBtn: boolean;
    title: string;
    edit: (data: any, isNew: boolean, rowIndex: number) => void;
    onDisableEditBtn: (row: KendoGridRow) => boolean;
    width: number;
    locked: boolean;
    sticky: boolean;
    constructor(options?: Partial<DettagliColumnSettings>);
    computeWidth(isMobileWidth: boolean, infoBtn: boolean): any;
}
export declare class CustomColumnSettings {
    title: string;
    action: (data: any, isNew: boolean, rowIndex: number) => any;
    onDisableActionBtn: (row: KendoGridRow) => boolean;
    width: number;
    locked: boolean;
    sticky: boolean;
    reorderable: boolean;
    set showColumn(value: boolean);
    get showColumn(): boolean;
    btnIcon: string;
    btnTooltip: string;
    fontawesomeIcon: any;
    headerStyle: {
        [key: string]: string;
    };
    includeInChooser: boolean;
    useCustomColumnCellTemplate: boolean;
    useCustomColumnHeaderTemplate: boolean;
    showBtn: boolean;
    private _showColumn$;
    showColumn$: Observable<boolean>;
    constructor(options?: Partial<CustomColumnSettings>);
    computeWidth(isMobileWidth: boolean, infoBtn: boolean): any;
}
export declare class ResizableSettings {
    isResizable: boolean;
    autoFitColumns: boolean;
    constructor(isResizable?: boolean, autoFitColumns?: boolean);
}
export declare class GeneralSettings {
    height: 'auto' | string | number;
    reordable: boolean;
    performOnEdit: boolean;
}
export declare class MasterDetailSettings {
    enable: boolean;
    flag_grid_master: boolean;
    flag_grid_detail: boolean;
    showDetailTemplate: (dataitem: any, rowIndex: number) => boolean;
    templateGridDetail: TemplateRef<any>;
    constructor(enable: boolean, optional?: Partial<MasterDetailSettings>);
    IsGridMaster(): boolean;
    IsGridDetail(): boolean;
}
export declare class SortSettings {
    sortable?: Sortable | boolean;
    sort?: SortDescriptor[];
    /**
     * @param sortable Set to false to disable sorting.
     */
    constructor(sortable?: Sortable | boolean, sort?: SortDescriptor[]);
    sortEnabled(): Sortable | boolean;
}
export declare enum ScrollingMode {
    None = "none",
    Scrollable = "scrollable",// default scrolling mode
    Virtual = "virtual"
}
export declare class VirtualScrollingOpts {
    rowHeight: number;
    viewportHeight: number;
}
export declare class PaginationSettings {
    /**
     * @param gridState Initial grid state. Take is page size.
     */
    gridState: State;
    /**
     * @param pageable If pagination should be applied.
     */
    pageable: boolean | PagerSettings;
    /**
     * @param navigable Allows to set keyboard shortcuts for navigating the grid.
     */
    navigable: boolean;
    scrollingType: ScrollingMode;
    /**
     * Virtual scrolling options.
     */
    virtualScrolling: VirtualScrollingOpts;
    /**
     * Sets the number of records shown in one page.
     * To do so, it sets the take property of gridState to the provided value n.
     * If gridState is null or undefined, it initializes gridState with default
     * values including setting take to the provided value n.
     * @param n the number of records shown in one page
     */
    take(n: number): void;
}
export declare enum DeletionMode {
    HandleSingleRowDeletionOnly = 0,
    HandleEachRowSeparately = 1,
    HandleAllRowsTogether = 2
}
/**
 * Settings for interacting with functionality not UI related.
 */
export declare class BehaviorSettings {
    createFormGroupFromOutside: boolean;
    saveExternalChanges: boolean;
    excelSettings: ExcelSettings;
    pdfSettings: PDFSettings;
    showDeletionConfirmation: boolean;
    deletionMode: DeletionMode;
    constructor(opts: Partial<BehaviorSettings>);
}
export declare class ExcelSettings {
    enabled: boolean;
    constructor(options: Partial<ExcelSettings>);
}
export declare class PDFSettings {
    enabled: boolean;
    allPages: boolean;
    constructor(options: Partial<PDFSettings>);
}
export declare class TemplateSettings {
    createNewColumnWithTemplate: boolean;
}
export declare class ColumnMenuSettings {
    /**
     * Abilita la colonna del menu a livello globale.
     */
    columnMenu: boolean;
    /**
     * Disabilitala colonna menu per colonne specifiche.
     * Questa funzionalità non ancora funziona.
     */
    disabledColumns: number[];
    /**
     * Filtrable. Deve essere true se column menu è abilitato.
     * Set to true to add a new row allowing to sort the grid.
     * Set to 'menu' to add a dropdown list used for sorting.
     */
    filterable: boolean | string;
    /**
     * Mostrare la Kendo Column Chooser. Fare comparire/scomparire alcune colonne.
     */
    kendoGridColumnChooser: boolean;
}
export declare class Sortable {
    allowUnsort: boolean;
    mode: SortMode;
}
export declare enum SortMode {
    SINGLE = "single",
    MULTIPLE = "multiple"
}
export declare class RemoveMultipleRowsParams {
    data: KendoGridRow[];
}
