import { ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AddEvent, CellClickEvent, CellCloseEvent, EditEvent } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { LocalStorageService } from 'ngx-webstorage';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { GeneralSettings } from '../models/configuration.model';
import { EditingMode, KendoGridColumn, KendoGridModel, KendoGridRow, KendoServerResult as GridServerResult } from '../models/grid.model';
import { AbstractGridConfigService } from './grid-config.service';
import { GridErrorService } from './grid-log.service';
import { GridPublicService } from './grid-public.service';
import { GridRootHelper } from './grid-root-helper.service';
import { TranslocoService } from "@jsverse/transloco";
import '@progress/kendo-angular-intl/locales/fr/calendar';
import '@progress/kendo-angular-intl/locales/pt/calendar';
import { State } from "@progress/kendo-data-query";
import { CELL_TYPES, DropdownListEvent } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class KendoGridService extends ReplaySubject<GridServerResult> {
    multiConfigs: AbstractGridConfigService<GridServerResult>;
    private transloco;
    pubServices: GridPublicService;
    private logService;
    private intlService;
    private gridRootHelper;
    private localStorage;
    private getLoadFn;
    nextDropdownValue(controlName: string, value: any, formGroup: FormGroup): void;
    clearKendoGridService(): void;
    /** Component context */
    _gridCtx: any;
    /**
     * Subjects for emitting events
     **/
    dropdownListSubject: Subject<DropdownListEvent>;
    /**
     * Non sottoscrivere a questo subject. Dovrebbe essere usato soltanto nel
     * questo modulo.
     */
    updateDropdownColumn: Subject<DropdownListEvent>;
    /**
     *  In cell editing mode variables
     **/
    private originalColumns;
    private originalModel;
    private originalData;
    private createdItems;
    private updatedItems;
    private deletedItems;
    clone<T>(obj: T): T;
    /**
     * In line editing mode
     */
    private kData;
    pubService: GridPublicService;
    freeMultiIndex: boolean;
    multiIndex: number;
    conf: AbstractGridConfigService<GridServerResult>;
    constructor(multiConfigs: AbstractGridConfigService<GridServerResult>, transloco: TranslocoService, pubServices: GridPublicService, logService: GridErrorService, intlService: IntlService, gridRootHelper: GridRootHelper, localStorage: LocalStorageService);
    initProviders(ctx: any): void;
    onCellClick(event: CellClickEvent): void;
    preventEdit(event: CellClickEvent): boolean;
    onCellClose(event: CellCloseEvent, inputElementRef: ElementRef): void;
    onCreateExternalFormGroup(event: CellClickEvent | AddEvent | EditEvent): FormGroup;
    ngOnInit(component: any): void;
    private initParams;
    /** Read fresh data from the beginning of the read pipeline. */
    idealRead(refresh: boolean, isPerformCallback?: boolean, cols?: KendoGridColumn[], afterEdit?: boolean): void;
    private _read;
    /**
     * isPerformCallback: è true quando si rileggono i dati appena perform è completato.
     */
    private allPurposeRead;
    /**
     * Utilizzato soltanto dalle viste.
     * @param cols Le colonne inizialmente caricate dal backend.
     */
    private storeDefaultColumnOrder;
    private storeDefaultGridState;
    /**
     *
     * @param isPerformCallback utilizzato per gestire il ricaricamento dei dati appena
     * perform è stato eseguito, in modo che le modifiche sono aggiornate nella griglia.
     */
    private decideNextBehavior;
    manageDates(data: GridServerResult): GridServerResult;
    customizationRowsSubject: Subject<KendoGridRow[]>;
    defaultColumnsOrder: KendoGridColumn[];
    defaultGridState: State;
    reReadRows(model: KendoGridModel, cols: KendoGridColumn[], applyServerColumns: boolean): void;
    sortColumnsByIndex(columns: KendoGridColumn[]): KendoGridColumn[];
    identifyRowsToSelect(ids: string[]): number[];
    applyDefaultView(): void;
    updatePubService(): void;
    save(data: KendoGridRow, id: string, isNew: boolean, rowIndex: number): Observable<any>;
    incellCreate(item: KendoGridRow): void;
    private incellCreatePerformOnEdit;
    private incellCreateDefault;
    inCellUpdate(item: KendoGridRow): void;
    private incellUpdatePerformOnEdit;
    private incellUpdateDefault;
    private incellUpdateBatchEdit;
    /**
     * @param row the selected rows. If only one row is passed and the deletion mode is different from `HandleSingleRowDeletionOnly`, it tries to reread all the selected rows.
     */
    remove(row: KendoGridRow | KendoGridRow[]): void;
    getAllSelectedRows(row: KendoGridRow): KendoGridRow[];
    doBatchDeletion(rows: KendoGridRow[]): void;
    /**
     * @param rows rows to delete
     * @history
     * **(12/03/2024)**: Add flag to reload grid data after deletion. This flag also helps to prevent the refresh of
     * grids with batch editing.
     */
    doOneByOneDeletion(rows: KendoGridRow[]): void;
    private inlineRemove;
    private incellRemovePerformOnEdit;
    itemsPreviouslyUpdated: KendoGridRow[];
    private incellRemoveDefault;
    highlightRowDeletion(row: KendoGridRow): boolean;
    private inlineSave;
    batchSave(data: any): Observable<any>;
    private generateNewRowId;
    /**
     *
     * @param gridGeneralSettings general settings of the grid
     * @history (09/04/2024): If the grid doesn't perform the actions on edit,
     * it creates a single event with all the interested rows. Rows can be sorted as follows:
     *  - toDelete: will have a hidden field (`pending-deletion-row`) valorized as true;
     *  - toCreate: will probably have the field `rowId` not valorized (see: {@link isNew})
     *  - toUpdate: all the others
     */
    incellSaveChanges(gridGeneralSettings?: GeneralSettings): Observable<any>;
    cancelChanges(): void;
    private incellCancelChanges;
    private inlineCancelChanges;
    reset(): void;
    inlineReset(): void;
    private incellReset;
    incellHasChanges(): boolean;
    /** Checks if the row is new.
     * @param item the row to check
     * @private
     * @return true if the field specified by `this.conf.rowId` is `null` or `undefined`
     */
    private isNew;
    assignValues(target: any, source: any): void;
    signal: Subject<void>;
    private registerSubscriptions;
    /**
     * Soon to be deprecated methods
     */
    getEditingMode(): EditingMode;
    /** Disables the editing of the grid. */
    disable(): void;
    /** Enables the editing of the grid. */
    enable(): void;
    setKendoData(rows: KendoGridRow[], model: KendoGridModel, cols: KendoGridColumn[]): void;
    getRows(): any[];
    getModel(): any;
    getColumns(): KendoGridColumn[];
    /**
     * Used for mapping the public grid service of the grid to an unused multi
     * index of the public service.
     */
    private mapFreePubService;
    /**
     * Used for mapping a configuration service to its corresponding service
     * (when multi: true in the providers array).
     */
    private mapMultiToken;
    setDataItem(dataItem: any): void;
    /**
     * [Section] Grid state
     */
    /**
     * [Context] Store/restore current page using cookies.
     */
    storeCurrentGridPage(skip: number): void;
    checkCacheForPreviousPage(): any;
    private _lastAccessedPageCookieId;
    /** END grid state */
    /** Some fields may be lost as a result of serialization. Here we restore
     * some of these fields (dropdown load functions and rendered custom
     * components).
     */
    restoreLostData(viewColumns: KendoGridColumn[]): KendoGridColumn[];
    mapComponentProp(col: KendoGridColumn): KendoGridColumn;
    mapLoadFn(col: KendoGridColumn): KendoGridColumn;
    isOfType(col: KendoGridColumn, type: CELL_TYPES): boolean;
    isDdl(col: KendoGridColumn): boolean;
    isCustom(col: KendoGridColumn): boolean;
    getColumnType(field: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<KendoGridService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KendoGridService>;
}
