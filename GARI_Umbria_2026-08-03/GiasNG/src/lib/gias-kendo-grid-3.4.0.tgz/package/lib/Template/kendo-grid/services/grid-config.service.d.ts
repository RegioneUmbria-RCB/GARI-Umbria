import { Injector, OnDestroy } from '@angular/core';
import { ColumnComponent } from '@progress/kendo-angular-grid';
import { Observable, Subject, Subscription } from 'rxjs';
import { AgrSelectableSettings, SortSettings, CommandsColumnSettings, GeneralSettings, ResizableSettings, ToolbarSettings, PaginationSettings, ColumnMenuSettings, BehaviorSettings, AggregateSettings, GroupSettings, DettagliColumnSettings, CustomColumnSettings, RemoveMultipleRowsParams, CommandsDropDownSettings, MasterDetailSettings } from '../models/configuration.model';
import { GridErrorService as GridLogService } from './grid-log.service';
import { EditingMode, GridCustomizations as GridCustomizations, KendoGridColumn, KendoGridModel, KendoServerResult, LoaderType, OnBeforeAfterEvents as IOnBeforeAfterEvents, RendererGridEvent } from '../models/grid.model';
import { ConfigTemplate, IOptionalConfigParameters as IOptionalConfigParams } from '../models/template.model';
import { GridPublicService } from './grid-public.service';
import { TranslocoService } from '@jsverse/transloco';
import { LoadingService } from 'gias-ui-kit';
import * as i0 from "@angular/core";
declare module 'rxjs' {
    interface Observable<T> {
        GiasSubscribe(next: (value: T) => void): Subscription;
    }
}
export interface IGridRequiredFields<Type> {
    read(options?: any): Observable<Type>;
    perform(action: HttpAction, items: any): Observable<any[]>;
    applyRendererRules(opts: RendererGridEvent): void;
    onRowClass(): any;
    editingMode: EditingMode;
    loader: LoaderType;
    rowId: string;
    gridId: string;
}
export interface IGridMessages {
    getRemoveMultipleRowsMessage(opts: any): any;
}
export declare abstract class AbstractGridConfigService<Type> implements IGridRequiredFields<Type>, IOptionalConfigParams, IOnBeforeAfterEvents, OnDestroy, IGridMessages {
    /** Emesso onDestory */
    signal: Subject<void>;
    /** Parametri obbligatori. */
    abstract editingMode: EditingMode;
    abstract loader: LoaderType;
    abstract rowId: string;
    abstract gridId: string;
    applyRendererRules(opts: RendererGridEvent): void;
    onRowClass: any;
    /** Parametri opzionali. */
    selectable: AgrSelectableSettings;
    toolbar: ToolbarSettings;
    cmdColumn: CommandsColumnSettings;
    cmdDropDown: CommandsDropDownSettings;
    dettagliColumn: DettagliColumnSettings;
    customColumn: CustomColumnSettings;
    resizable: ResizableSettings;
    generalSettings: GeneralSettings;
    sort: SortSettings;
    pagination: PaginationSettings;
    columnMenu: ColumnMenuSettings;
    behavior: BehaviorSettings;
    views: GridCustomizations;
    aggregates: AggregateSettings;
    groups: GroupSettings;
    masterdetailSettings: MasterDetailSettings;
    /** Funzione utilizzata per caricare le righe, le colonne e il modello della griglia. */
    abstract read(options?: any): Observable<Type>;
    /** Crea, modifica e cancella righe della griglia.
     * @param items - array contenete le righe su cui è stata eseguita l'operazione.
     * In caso si stia usando una griglia con modalità di editing `EditingMode.IN_CELL_BATCH`,
     * items sarà un oggetto rispettante l'interfaccia `InCellBatchSaveEventObject`.
     * @usageNotes
     * Se non volete eseguire alcuna operazione particolare è consigliato ritornare `null`
     * per non compromettere le normali funzionalità della griglia.
     * Eccetto che si tratti di una griglia con batch editing. In quel caso, ritornare `of([])`
     * se si desidera resettare l'oggetto `items` o `null` per lasciarlo così com'è.
     */
    abstract perform(actionType: HttpAction, items: any, oldRow?: any): Observable<any>;
    /** Configuration wide settings. */
    protected logService: GridLogService;
    protected gridPublicService: GridPublicService;
    protected transloco: TranslocoService;
    protected loadingService: LoadingService;
    /** Private params */
    protected injector: Injector;
    constructor(injector: Injector, template?: ConfigTemplate);
    getRemoveMultipleRowsMessage(opts: RemoveMultipleRowsParams): Promise<string>;
    private deletionMessage;
    getMessagePrefix(rows: any[]): string;
    ngOnDestroy(): void;
    protected model: KendoGridModel;
    protected columns: KendoGridColumn[];
    /** Used to define if the grid is editable or not.
     * Both the function `disableGrid` and `makeCellsUneditable` depend on the value of this field.
     */
    gridIsEditable: boolean;
    /** Shows the action buttons from the command column and the creation button from the toolbar
     * based on the value of `gridIsEditable`.
     */
    disableGrid(): void;
    /** Enables/disables every column based on the value of `gridIsEditable`. */
    makeCellsUneditable(): void;
    /**
   * Funzioni da eseguire prima dopo vari eventi.
   */
    onCellClose: any;
    onCellClick: any;
    /** Usato per gestire la prevenzione della modifica di una cella. Di default, non previene l'evento.
     * Possibile riassegnare la lambda.
     */
    preventEdit: ((dataItem: any, column: ColumnComponent) => boolean);
    onCreateExternalFormGroup: any;
    sayHi(): void;
    private init;
    private checkIfGridIsEditable;
    protected isLoading(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractGridConfigService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbstractGridConfigService<any>>;
}
export declare class DefaultHttpService extends AbstractGridConfigService<KendoServerResult> {
    gridId: string;
    editingMode: EditingMode;
    loader: LoaderType;
    rowId: string;
    constructor(injector: Injector);
    read(): Observable<KendoServerResult>;
    perform(actionType: HttpAction, items: any): Observable<any[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultHttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultHttpService>;
}
export declare enum HttpAction {
    CREATE = "create",
    UPDATE = "update",
    REMOVE = "destroy",
    BATCH_SAVE = "save"
}
