import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, Renderer2 } from '@angular/core';
import { FilterService, SinglePopupService } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor, FilterDescriptor } from '@progress/kendo-data-query';
import { TranslocoService } from '@jsverse/transloco';
import { IManager } from '../managers/manager';
import { PopupSettingsManager } from '../models';
import { filtersManager, FormValueManager, DateFilters } from '../utils';
import * as i0 from "@angular/core";
interface IDateRangeFilter {
    /**
     * Stores logic for handling multiple filter modes.
     * Basic filtering with data contained between two dates.
     * Extended filtering which supports all kendo operators.
     */
    filtersManager: filtersManager;
    /**
     * Used for setting the width of the popup, as well as preventing
     * the window from closing in certain situations.
     */
    popupManager: PopupSettingsManager;
    /**
     * Manages all the values within each form of the view.
     */
    formValueManager: FormValueManager;
}
export declare class DateRangeFilterComponent implements IDateRangeFilter, AfterViewInit, OnDestroy {
    changeDetector: ChangeDetectorRef;
    private element;
    private transloco;
    private renderer;
    filter: CompositeFilterDescriptor;
    filterService: FilterService;
    manager: IManager;
    field: string;
    filterChange: EventEmitter<DateFilters>;
    formValueManager: FormValueManager;
    filtersManager: filtersManager;
    popupManager: PopupSettingsManager;
    private signal;
    constructor(changeDetector: ChangeDetectorRef, element: ElementRef, popupService: SinglePopupService, transloco: TranslocoService, renderer: Renderer2);
    get filters(): filtersManager;
    get values(): FormValueManager;
    ngAfterViewInit(): void;
    switchActiveMode(): void;
    clearFilter(): void;
    filterRange(start: Date, end: Date): void;
    transformOperator(operatorType: string, date: Date): CompositeFilterDescriptor | FilterDescriptor;
    refreshFilters(): void;
    onSelectAll(): void;
    ngOnDestroy(): void;
    private setFilterContainerWidth;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeFilterComponent, "gias-date-range-filter-cell", never, { "filter": { "alias": "filter"; "required": false; }; "filterService": { "alias": "filterService"; "required": false; }; "manager": { "alias": "manager"; "required": false; }; "field": { "alias": "field"; "required": false; }; }, { "filterChange": "filterChange"; }, never, never, false, never>;
}
export {};
