import { PipeTransform } from '@angular/core';
import { KendoGridColumn } from '../models/grid.model';
import * as i0 from "@angular/core";
export declare class GroupHeaderNamePipe implements PipeTransform {
    transform(group: any, column: KendoGridColumn, field: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupHeaderNamePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GroupHeaderNamePipe, "groupHeaderName", false>;
}
