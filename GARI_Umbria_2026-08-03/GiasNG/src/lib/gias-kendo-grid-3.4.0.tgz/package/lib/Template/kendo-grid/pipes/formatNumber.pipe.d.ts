import { PipeTransform } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { KendoGridColumn, KendoServerResult } from '../models/grid.model';
import { AbstractGridConfigService } from '../services/grid-config.service';
import * as i0 from "@angular/core";
export declare class FormatNumberPipe implements PipeTransform {
    conf: AbstractGridConfigService<KendoServerResult>;
    intl: IntlService;
    constructor(conf: AbstractGridConfigService<KendoServerResult>, intl: IntlService);
    transform(val: any, col: KendoGridColumn, aggrFormat: string): string;
    private pulisciFormato;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatNumberPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatNumberPipe, "formatNumber", false>;
}
