import { GridDataResult } from '@progress/kendo-angular-grid';
import { IScrollingMode } from '../interfaces/scrollingMode.interface';
import { KendoServerResult } from '../models/grid.model';
import { PaginationSettings, ScrollingMode } from '../models/configuration.model';
import { VirtualScrollingService } from './virtualScrolling.service';
export declare class ScrollableScrollingOpts {
    pagination: PaginationSettings;
}
export declare class ScrollableScrollingService implements IScrollingMode {
    rowHeight: number;
    mode: ScrollingMode;
    private pagination;
    private _totalCount;
    constructor(opts: ScrollableScrollingOpts);
    get pageSize(): number;
    get totalCount(): number;
    private get gridState();
    getRowHeight(): number;
    isVirtual(): this is VirtualScrollingService;
    loadData(data: KendoServerResult): GridDataResult;
    private computeGridStateBasedOn;
}
