import { State } from '@progress/kendo-data-query';
import { DropdownList, DropdownListItem, KendoGridColumn } from '../../models/grid.model';
export declare class ViewBase {
    IdVista: string;
    GridId: string;
    NomeUtente: string;
    Predefinita: boolean;
    NomeVista: string;
    FiltroJSON: string | null;
    FlagPubblica: boolean;
    constructor(options?: Partial<ViewBase>);
}
export declare class DropdownChanged {
    dropdown: DropdownList;
    selected: DropdownListItem;
    constructor(dropdown: DropdownList, selected: DropdownListItem);
}
export declare class ServerView extends ViewBase {
    Colonne: string;
    Stato: string;
    constructor(options?: Partial<ServerView>);
}
export declare class SelectionChangeEvent {
    item: DropdownListItem;
    isNew: boolean;
    constructor(options: Required<SelectionChangeEvent>);
}
export declare class InMemoryView extends ViewBase {
    Colonne: KendoGridColumn[];
    Stato: State;
    IsModified: boolean;
    IsNew: boolean;
    constructor(options?: InMemoryView);
}
export declare class ChiaveVista {
    GridId: string;
    IdVista: string;
    NomeUtente: string;
    constructor(GridId: string, IdVista: string, NomeUtente: string);
}
export interface ColumnSettings {
    field: string;
    title?: string;
    filter?: 'text' | 'numeric' | 'date' | 'boolean' | 'datetime';
    format?: string;
    width?: number;
    filterable?: boolean;
    orderIndex?: number;
    hidden?: boolean;
}
export declare class SalvaVisteWrapper {
    VisteNuove: ServerView[];
    VisteModificate: ServerView[];
    constructor(options: Required<SalvaVisteWrapper>);
}
export declare class CustomizationRequest {
    dropdownItem: DropdownListItem;
    isNewView: boolean;
}
