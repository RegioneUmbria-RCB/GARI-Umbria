import { PipeTransform } from '@angular/core';
import { GridErrorService } from '../services/grid-log.service';
import { KendoGridColumn, KendoGridRow } from '../models/grid.model';
import * as i0 from "@angular/core";
export declare class CellMultiDropdownNamePipe implements PipeTransform {
    logService: GridErrorService;
    constructor(logService: GridErrorService);
    transform(row: KendoGridRow, column: KendoGridColumn): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CellMultiDropdownNamePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CellMultiDropdownNamePipe, "cellMultiDropdownName", false>;
}
