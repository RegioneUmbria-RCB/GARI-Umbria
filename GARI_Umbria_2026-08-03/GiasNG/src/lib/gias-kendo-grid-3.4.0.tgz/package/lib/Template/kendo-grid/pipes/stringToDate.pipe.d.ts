import { PipeTransform } from '@angular/core';
import { KendoGridColumn, KendoServerResult } from '../models/grid.model';
import { AbstractGridConfigService } from '../services/grid-config.service';
import { ConversionService } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class StringToDatePipe implements PipeTransform {
    conf: AbstractGridConfigService<KendoServerResult>;
    private conversionService;
    constructor(conf: AbstractGridConfigService<KendoServerResult>, conversionService: ConversionService);
    transform(strVal: any, col: KendoGridColumn): Date;
    static ɵfac: i0.ɵɵFactoryDeclaration<StringToDatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<StringToDatePipe, "stringToDate", false>;
}
