import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { DropdownListItem, DropdownListWithForm } from '../../models/grid.model';
import { DropdownListEvent } from 'gias-ui-kit';
import * as i0 from "@angular/core";
/**
 * Questa componente è stata creata per la kendo grid.
 * Non dovrebbe essere usata fuori da questo modulo.
 * Usare DropDownTemplateComponent invece.
 * */
export declare class GridMultiDropdownComponent implements OnInit, OnDestroy {
    useForm: boolean;
    id: string;
    filterable: boolean;
    defaultItem: DropdownListItem;
    textField: string;
    valueField: string;
    valuePrimitive: boolean;
    controlName: string;
    formGroup: FormGroup;
    selected: DropdownListItem;
    ddl: DropdownListWithForm;
    valueChange: EventEmitter<DropdownListEvent>;
    open: EventEmitter<DropdownListEvent>;
    reload: EventEmitter<DropdownListEvent>;
    signal: Subject<void>;
    data: DropdownListItem[];
    multi: any;
    defaultOpen: boolean;
    sourceChange: EventEmitter<DropdownListItem[]>;
    source: DropdownListItem[];
    ngOnInit(): void;
    changeValue(newValue: DropdownListItem): void;
    filter: string;
    handleFilter(value: any): void;
    onOpen(): void;
    ngOnDestroy(): void;
    private fixValidationForThisControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridMultiDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridMultiDropdownComponent, "gias-grid-multi-ddl", never, { "useForm": { "alias": "useForm"; "required": false; }; "id": { "alias": "id"; "required": false; }; "filterable": { "alias": "filterable"; "required": false; }; "defaultItem": { "alias": "defaultItem"; "required": false; }; "textField": { "alias": "textField"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "valuePrimitive": { "alias": "valuePrimitive"; "required": false; }; "controlName": { "alias": "controlName"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "ddl": { "alias": "ddl"; "required": false; }; "defaultOpen": { "alias": "defaultOpen"; "required": false; }; "source": { "alias": "source"; "required": false; }; }, { "valueChange": "valueChange"; "open": "open"; "reload": "reload"; "sourceChange": "sourceChange"; }, never, never, false, never>;
}
