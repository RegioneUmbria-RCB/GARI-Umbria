import { DropdownListItem } from '../../models/grid.model';
export declare function parseJson(str: string): DropdownListItem;
