import { AfterViewChecked, AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, NgZone, OnDestroy, OnInit, QueryList, Renderer2, TemplateRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { TranslocoService } from '@jsverse/transloco';
import { DialogService } from '@progress/kendo-angular-dialog';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { AddEvent, CancelEvent, CellClickEvent, CellCloseEvent, CheckboxColumnComponent, ColumnBase, ColumnComponent, ColumnReorderEvent, ColumnVisibilityChangeEvent, CommandColumnComponent, DetailCollapseEvent, DetailExpandEvent, EditEvent, GridComponent, GridDataResult, PageChangeEvent, RemoveEvent, RowArgs, RowClassArgs, SaveEvent, SelectAllCheckboxState, SelectionEvent } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { AggregateResult, SortDescriptor, State } from '@progress/kendo-data-query';
import { GridCommandItem } from '../../shared/utils';
import { GridWorkerService } from '../../grid-worker.service';
import { Observable, Subject, Subscription } from 'rxjs';
import { GridCustomizationsService } from './components/grid-customizations/grid-customizations.service';
import { InMemoryView } from './components/grid-customizations/model';
import { IScrollingMode } from './interfaces/scrollingMode.interface';
import { AggregateSettings, AgrSelectableSettings, BehaviorSettings, ColumnMenuSettings, CommandsColumnSettings, CommandsDropDownSettings, CustomColumnSettings, DettagliColumnSettings, GeneralSettings, GroupSettings, MasterDetailSettings, PaginationSettings, ResizableSettings, ScrollingMode, SortSettings, ToolbarSettings } from './models/configuration.model';
import { EditingMode, GridCustomizations, KendoGridColumn, KendoGridModel, KendoGridRow, KendoServerResult, LoaderType, SelectedOpts } from './models/grid.model';
import { IOptionalConfigParameters } from './models/template.model';
import { AbstractGridConfigService } from './services/grid-config.service';
import { GridDialogService } from './services/grid-dialog.service';
import { GridErrorService } from './services/grid-log.service';
import { GridPublicService } from './services/grid-public.service';
import { KendoGridService } from './services/kendo-grid.service';
import { KendoGridMasterDetailService } from "./services/grid-master-detail.service";
import { GridBatchHandlerService } from './services/grid-batch-handler.service';
import { DropdownListEvent, CELL_TYPES } from 'gias-ui-kit';
import * as i0 from "@angular/core";
export declare class GiasKendoGridComponent implements OnInit, AfterViewInit, AfterViewChecked, OnDestroy, IOptionalConfigParameters {
    customizationService: GridCustomizationsService;
    gridServices: KendoGridService;
    private logService;
    private intlService;
    changeDetector: ChangeDetectorRef;
    ngZone: NgZone;
    private worker;
    private translocoService;
    renderer: Renderer2;
    private gridBatchHandlerService;
    private kendoGridMasterService;
    /**
     * TODO_RV
     * Adjust column width based on contents (visible buttons): dettagliColumn and commandiColumn.
     * Features to add.
     * 1. Allow user to select between the loading animation of the grid and global loading animation mode.
     * 2. Nel metodo initView, dovrei togliergli la verifica if(!kData). Si spreca un evento al
     * caricamento della pagina prima che i dati siano caricati. Esempio sulla pagina dei campi (durante la
     * chiamata al server).
     * 3. Da inserire una funzione configurabile per la ricerca dentro una dropdown list.
     */
    unsubSignal: Subject<void>;
    noRecordsTemplateRef: TemplateRef<any>;
    gridContext: GiasKendoGridComponent;
    readonly IN_CELL = EditingMode.IN_CELL;
    readonly IN_LINE = EditingMode.IN_LINE;
    readonly IN_LINE_BATCH = EditingMode.IN_LINE_BATCH;
    readonly IN_CELL_BATCH = EditingMode.IN_CELL_BATCH;
    /**
     *  Constants
     * */
    readonly STRING: string;
    readonly DATE: string;
    readonly DATETIME: string;
    readonly DROPDOWNLIST: string;
    readonly MULTI_DROPDOWNLIST: string;
    readonly NUMERIC: string;
    readonly BOOLEAN: string;
    readonly CUSTOM: string;
    /**
     * Font awesome.
     */
    faInfo: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faEdit: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faDelete: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faCancel: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faNew: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faCopy: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faSave: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faCircleSave: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faArrow: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faDots: import("@fortawesome/fontawesome-common-types").IconDefinition;
    /**
     * Required parameters
     */
    editingMode: EditingMode;
    loader: LoaderType;
    key: string;
    /**
     * General settings.
     * See the sortChange function.
     */
    generalSettings: GeneralSettings;
    /**
     * Pagination and sorting.
     */
    sort: SortSettings;
    pagination: PaginationSettings;
    masterdetailSettings: MasterDetailSettings;
    /**
     * In cell editing.
     * */
    view: Observable<GridDataResult>;
    formGroup: FormGroup;
    /**
     * In line editing
     */
    private editedRowIndex;
    isInEditMode: boolean;
    inLineModificaIsDisabled: boolean;
    /**
     * Grid (optional) parameters
     * */
    selectable: AgrSelectableSettings;
    toolbar: ToolbarSettings;
    cmdColumn: CommandsColumnSettings;
    cmdDropDown: CommandsDropDownSettings;
    dettagliColumn: DettagliColumnSettings;
    customColumn: CustomColumnSettings;
    columnMenu: ColumnMenuSettings;
    groups: GroupSettings;
    columnGroups: Map<string, KendoGridColumn[]>;
    /**
     * Setting behavior and not UI related functionality.
     */
    behavior: BehaviorSettings;
    privateService: KendoGridService;
    publicService: GridPublicService;
    AGRODATA_INIZIO: Date;
    AGRODATA_FINE: Date;
    insideWindow: Window & typeof globalThis;
    SMARTPHONE_WIDTH: number;
    config: AbstractGridConfigService<KendoServerResult>;
    gridDialogService: GridDialogService;
    /** Use cases */
    Scrollable: ScrollingMode;
    currentScrollingMode: IScrollingMode;
    customCommandColumnCellTemplate: TemplateRef<ElementRef>;
    customCommandColumnHeaderTemplate: TemplateRef<any>;
    showSwitchViewsPrivatePublic: boolean;
    rowsLoaded: EventEmitter<void>;
    constructor(customizationService: GridCustomizationsService, gridServices: KendoGridService, /* Could be of type array or object */ logService: GridErrorService, intlService: IntlService, changeDetector: ChangeDetectorRef, ngZone: NgZone, worker: GridWorkerService, translocoService: TranslocoService, renderer: Renderer2, gridBatchHandlerService: GridBatchHandlerService, kendoDialogService: DialogService, kendoGridMasterService: KendoGridMasterDetailService);
    getColumnsGroupValue(): string;
    getComandValue(): string;
    get gridState(): State;
    get pageSize(): number;
    rowClassCallback(e: RowClassArgs): {
        'pending-deletion-row': any;
    };
    ShowHTMLAsString(cellType: CELL_TYPES, col: KendoGridColumn | ColumnComponent): boolean;
    /**
     * Utilizzato per determinare il corrispondente token quando multi: true.
     */
    gridId: string;
    ngOnDestroy(): void;
    ngOnInit(): void;
    resizeObservable: any;
    manageWindowResizeEvents(): void;
    private resizeFnWidth;
    /**
     * [Section] Grid state.
     * [Item] Store current grid page in cache, to be restored when creating the
     * grid.
     */
    private _storeCurrentGridPage;
    private _restorePreviousGridPage;
    /**
     * [Item] adjust grid height based on content.
     */
    private adjustGridHeightBasedOnContent;
    /** Adatta l'altezza della griglia a quella del primo div padre con altezza fissa. */
    private _adaptHeightOnContainer;
    private _allRowsFit;
    private _findFirstParentWithFixedHeight;
    private _hasRowsScrollBar;
    private _scrollbarIsVisibleOn;
    /** END [Section] Grid state */
    registerSubscriptions(): void;
    /**
     * Used for resizing the grid.
     */
    resizable: ResizableSettings;
    grid: GridComponent;
    checkboxColumn: CheckboxColumnComponent;
    commandColumn: CommandColumnComponent;
    gridElRef: ElementRef;
    input: ElementRef;
    /**
     * In-cell and in-line modification settings
     * */
    cellClick: EventEmitter<CellClickEvent>;
    private resetGroupColumns;
    private haveColumnsChanged;
    cellClickHandler(event: CellClickEvent): void;
    cellCloseHandler(event: CellCloseEvent): void;
    disableButtonsDuringEditMode(disabled: boolean): void;
    addHandler(event: AddEvent): void;
    cancelHandler(event: CancelEvent): void;
    saveHandler(event: SaveEvent): void;
    removeHandler(event: RemoveEvent): Promise<void>;
    private batchRemove;
    saveChanges(grid: any): void;
    batchSave(): void;
    cancelChanges(grid: any): void;
    /**
     * In line edit handler
     */
    editHandler(event: EditEvent): void;
    private handleDdlValue;
    resetHandler(): void;
    resetFilter(): void;
    onStateChange(state: State): void;
    showToolbar: boolean;
    showCmdColumn: boolean;
    showCmdDDL: boolean;
    showDettagliColumn: boolean;
    showCustomColumn: boolean;
    showCustomColumnSubscription: Subscription;
    initParams(): void;
    pageChangeEvent: EventEmitter<{
        grid: GridComponent;
        event: PageChangeEvent;
    }>;
    pageChange(event: PageChangeEvent): void;
    selectionChange: EventEmitter<SelectionEvent>;
    onSelectionChange(event: SelectionEvent): void;
    isRowSelected: (e: RowArgs) => any;
    /**
     * Signal column visibility change.
     */
    columnVisibilityChange: EventEmitter<ColumnVisibilityChangeEvent>;
    columnVisibilityChangeHandler(event: ColumnVisibilityChangeEvent): void;
    numericTextBox: EventEmitter<number>;
    onChange(event: any): void;
    /**
     *  Auxiliary functions
     **/
    closeEditor(grid: any, rowIndex?: number): void;
    tooltipDir: TooltipDirective;
    showTooltip(event: MouseEvent): void;
    /**
     * Aggregates.
     */
    aggregates: AggregateSettings;
    total: Map<string, AggregateResult>;
    private defaultInitializationMethod;
    ShowkendoGridDetailTemplate(): boolean;
    private initializeUsingResolver;
    private initializeUsingHTML;
    colsLoaded: Subject<void>;
    private initView;
    refreshAggregateTotal(): void;
    _calculateAggregatesTotal(rows: KendoGridRow[], footer: boolean, field: string, value: any): AggregateResult;
    private _initializeGridData;
    private _feedEmptyGrid;
    private _updateSelectAllColumnBasedOnSelectedRows;
    manageSelectedRows(): void;
    contentCmdColumns: QueryList<CommandColumnComponent>;
    initialized: boolean;
    createColumnsDynamically(kdata: KendoServerResult): void;
    reorderMissplacedColumnsAfterUpdate(): void;
    addShadowDomColumnsToTheGrid(alreadyAppliedColumns: QueryList<ColumnBase>): void;
    viewInit: Subject<void>;
    /**
     * Called one time once the data is set inside the grid.
     */
    ngAfterViewInit(): Promise<void>;
    private _loadedViewApplied;
    ngAfterViewChecked(): void;
    private createUsecaseServices;
    autofitInitialized: boolean;
    private autofitColumns;
    private dataWasReadApplyRenderer;
    private applyRendererGiven;
    /**
     * Editing
     */
    private createFormGroup;
    getDate(row: any, column: KendoGridColumn): any;
    onOpenReloadDDL(event: DropdownListEvent, formgroup: FormGroup, forceReload: boolean): void;
    /**
     * Used for displaying validation messages.
     */
    get formControls(): {
        [key: string]: import("@angular/forms").AbstractControl<any, any>;
    };
    /**
     * Used for dinamically updating different dropdown lists.
     */
    ddlStateChanged(event: DropdownListEvent, formgroup: FormGroup, col: KendoGridColumn): void;
    ddlOpenEvent(event: DropdownListEvent, formGroup: FormGroup): void;
    ddlReload(event: DropdownListEvent, formGroup: FormGroup, col: KendoGridColumn): void;
    onOpenCommands(data: any): void;
    onCommand(cmd: GridCommandItem, dataItem: any, isNew: boolean, rowIndex: number): void;
    ButtonGridCommandName(cmd: GridCommandItem): string;
    editBtnHandler(data: any, isNew: boolean, rowIndex: number): void;
    actionBtnHandler(data: any, isNew: boolean, rowIndex: number): void;
    infoCmdHandler(data: any, isNew: boolean, rowIndex: number): void;
    userBindCmdHandler(data: any, isNew: boolean, rowIndex: number): void;
    columns: Array<KendoGridColumn>;
    rows: KendoGridRow[];
    model: KendoGridModel;
    applyColumnReorderPolicy(event: ColumnReorderEvent): void;
    applyColumnVisibilityChangePolicy(event: ColumnVisibilityChangeEvent): void;
    /**
     * Grid customizations.
     */
    rereadRowsOnViewUpdate: boolean;
    updateViewCustomization(leaveRereadRowsUntouched: boolean): void;
    private mapKendoGridColumnfromColumnComponent;
    views: GridCustomizations;
    customizationViewChanged: boolean;
    /** Vista caricata tra quelle salvate dall'utente. */
    private loadedView;
    private lastView;
    applyView(view: InMemoryView): void;
    private mostraCheckECmdColumn;
    private mapGridSettings;
    /**
     *
     * @param viewColumns - le colonne della vista
     * @param columns - le colonne presenti in griglia (attuali)
     * @returns le colonne una volta applicata la vista
     */
    onColumnResize(): void;
    /**
     * Export data via excel.
     * Generates the data required for exporting to Excel.
     *
     * This method processes the current grid data, applying grouping, sorting,
     * and filtering based on the grid's state. It then maps the processed data
     * into a format suitable for Excel export using a helper function. The
     * mapping concerns the colums labeled as dropdown or multiselect.
     *
     * @returns {ExcelExportData} The formatted data ready for Excel export.
     *
     * If there's the need to handle the serialization of custom columns, modify
     * the mapping function in the helper {@link GridHelper.mapForExcelExport}.
     */
    excelData(): ExcelExportData;
    selectAllState: SelectAllCheckboxState;
    rowId: any;
    private selectAllChecked;
    onSelectAllChange(checkedState: SelectAllCheckboxState): void;
    onSelectedKeysChange(ev: string[]): void;
    GetDatiAttuali(): {
        rows: KendoGridRow[];
        columns: KendoGridColumn[];
        model: KendoGridModel;
    };
    filterableGrid(): boolean;
    showEditButton(dataItem: any): boolean;
    getColumnStyle(col: KendoGridColumn): {
        [p: string]: string;
    };
    getColumnFooterStyle(col: KendoGridColumn): {
        [p: string]: string;
    };
    setSelectedRows(opts: SelectedOpts): void;
    deselectRows(rows: RowArgs[]): void;
    deselectAllRows(): void;
    resetMulticheckStore(): void;
    refresh(): void;
    forceReload(): void;
    detailCollapse: EventEmitter<DetailCollapseEvent>;
    detailMasterRowCollapse(event: DetailCollapseEvent): void;
    detailExpand: EventEmitter<DetailExpandEvent>;
    detailMasterRowExpand(event: DetailExpandEvent): void;
    showCmdDdlButton(dataItem: any): boolean;
    IsVisibleCmdClumn(): boolean;
    defaultOrder(a: any, b: any): number;
    get hasBatchChanges(): boolean;
    useCustomColumnCellTemplate(): boolean;
    mapColumns(viewColumns: KendoGridColumn[], columns: KendoGridColumn[]): KendoGridColumn[];
    useCustomColumnHeaderTemplate(): boolean;
    showBtncustomColumn(isNew: boolean): boolean;
    useColumnGroup(group: any): boolean;
    showAgronicakendoGridCellTemplate(cellType: CELL_TYPES, col: KendoGridColumn): boolean;
    showAgronicakendoGridGroupHeaderTemplate(cellType: CELL_TYPES): boolean;
    showAgronicakendoGridFooterTemplate(cellType: CELL_TYPES): boolean;
    getAggregateResult(aggregateSetting: AggregateResult, col: KendoGridColumn, aggregate: string): number;
    showkendoGridFilterMenuTemplate(cellType: CELL_TYPES, column: any): boolean;
    showAgronicakendoGridFilterMenuTemplate(cellType: CELL_TYPES): boolean;
    showMultiCheckFilter(cellType: CELL_TYPES, column: KendoGridColumn): boolean;
    showAgronicakendoGridEditTemplate(cellType: CELL_TYPES): cellType is CELL_TYPES.DATE | CELL_TYPES.DATETIME | CELL_TYPES.DROPDOWNLIST | CELL_TYPES.MULTI_DROPDOWNLIST | CELL_TYPES.NUMBER | CELL_TYPES.BOOLEAN | CELL_TYPES.CUSTOM;
    sortChange(sort: SortDescriptor[]): void;
    getAllDescriptionField(): string[];
    /**
     * This will just run changeDetector.detectChanges()
     */
    repaint(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GiasKendoGridComponent, [null, null, null, null, null, null, null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GiasKendoGridComponent, "gias-kendo-grid", never, { "customCommandColumnCellTemplate": { "alias": "customCommandColumnCellTemplate"; "required": false; }; "customCommandColumnHeaderTemplate": { "alias": "customCommandColumnHeaderTemplate"; "required": false; }; "showSwitchViewsPrivatePublic": { "alias": "showSwitchViewsPrivatePublic"; "required": false; }; "gridId": { "alias": "gridId"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "model": { "alias": "model"; "required": false; }; }, { "rowsLoaded": "rowsLoaded"; "cellClick": "cellClick"; "pageChangeEvent": "pageChangeEvent"; "selectionChange": "selectionChange"; "columnVisibilityChange": "columnVisibilityChange"; "numericTextBox": "numericTextBox"; "detailCollapse": "detailCollapse"; "detailExpand": "detailExpand"; }, ["noRecordsTemplateRef", "contentCmdColumns"], ["[toolbarStart]", "[headerContent]", "[headerContentButtons]", "[headerContentEnd]", "[headerSecondLine]"], false, never>;
}
