import { DropdownListItem, KendoGridColumn, KendoGridRow } from '../../models/grid.model';
import { GridPublicService } from '../../services/grid-public.service';
import { InMemoryView } from '../grid-customizations/model';
import { NextDropdownValue } from '../grid-dropdownlists/grid-dropdown.service';
import * as i0 from "@angular/core";
export declare class DropdownHelper {
    gridCellClosedOuput(col: KendoGridColumn, row: KendoGridRow): {
        items: DropdownListItem[];
        columnDataNeedsUpdate: boolean;
    };
    private containsDropdownListItems;
    private datiSonoStatiCaricatiInAnticipo;
    private getCellClosedOutputFromDataItem;
    getMultiDropdownCtrlInput(c: KendoGridColumn, row: KendoGridRow): any;
}
export declare class GridDropdownBase {
    private gridPublicService;
    data: any[];
    source: any[];
    constructor(gridPublicService: GridPublicService);
    readonly defaultItem: DropdownListItem;
    extractDropdownItems(data: InMemoryView[]): DropdownListItem[];
    getDefaultItem(): DropdownListItem;
    getDefaultItemId(): string;
    generateUID(): string;
    getData(): any[];
    getSource(): any[];
    patchValue(data: NextDropdownValue): void;
    private _patchValue;
    checkIfValueExists(itemId: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridDropdownBase, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridDropdownBase>;
}
export declare class GridMultiDropdownService {
    readonly defaultItem: DropdownListItem;
    extractDropdownItems(data: InMemoryView[]): DropdownListItem[];
    getDefaultItem(): DropdownListItem;
    getDefaultItemId(): string;
    generateUID(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridMultiDropdownService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GridMultiDropdownService>;
}
