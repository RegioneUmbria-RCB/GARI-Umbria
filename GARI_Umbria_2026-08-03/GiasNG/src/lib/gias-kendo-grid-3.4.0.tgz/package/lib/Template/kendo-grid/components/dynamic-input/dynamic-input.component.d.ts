import { AfterContentChecked, OnInit } from '@angular/core';
import { enum_TipoControllo } from '../../../../shared/TipiEnumerativi';
import { FormControl, FormGroup } from '@angular/forms';
import { BooleanSettings, DateSettings, DropdownListWithForm, NumericSettings, StringSettings } from '../../models/grid.model';
import { CustomComponent } from '../../models/custom-component';
import * as i0 from "@angular/core";
export declare class DynamicInputSettigs {
    /** Il tipo di controllo da usare. */
    controlType: enum_TipoControllo;
    /** Il vero campo contenente il valore. */
    realField: string;
    /** Funzione da eseguire al cambiamento del valore. */
    onEdit?: (newValue: any) => void;
    ddl?: DropdownListWithForm;
    numeric?: NumericSettings;
    boolean?: BooleanSettings;
    date?: DateSettings;
    string?: StringSettings;
    constructor(settings?: DynamicInputSettigs);
}
/** Per ora utilizzato solo in <code>grid-rilievi.service.ts</code>.
 *  @Warning va in conflitto con le griglie con EditingMode di tipo <code>EditingMode.IN_CELL</code>
 */
export declare class DynamicInputComponent implements OnInit, AfterContentChecked, CustomComponent {
    /** Il dataItem rappresentante la riga corrente. */
    input: any;
    /** Indica il campo in dataItem di tipo {@link DynamicInputSettigs} a cui fare
     *  riferimento per usare il componente.
     *  Necessario specificarlo per ogni riga in modo da rendere la cosa
     *  dinamica.
     */
    field: any;
    edit: boolean;
    settings: DynamicInputSettigs;
    form: FormGroup;
    enum_TipoControllo: {
        UNDEFINED: number;
        CASELLA_TESTO: number;
        AREA_TESTO: number;
        MENU_DISCESA: number;
        CASELLA_SPUNTA: number;
        CALENDARIO: number;
        ALLEGATO: number;
        LINK: number;
        PASSWORD: number;
        MULTISELECT_ESTESA_SERVER: number;
        PULSANTE_SCELTA: number;
        IMMAGINE: number;
        DDL_ESTESA_CLIENT: number;
        GIS_VIEWER: number;
        DDL_ESTESA_SERVER_LIGHT: number;
        NUMERO_INTERO: number;
        NUMERO_DECIMALE: number;
        MULTISELECT: number;
    };
    AGRODATA_INIZIO: Date;
    fieldControl: FormControl;
    private _internalChange;
    ngOnInit(): void;
    update(ev: any): void;
    private createForm;
    ngAfterContentChecked(): void;
    /**
     * Patches the value of the field in the control, eventually adapting
     * different values to the expected ones. i.e. boolean values.
     * @private
     */
    private updateFieldControl;
    private parseBoolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynamicInputComponent, "gias-dynamic-input", never, { "input": { "alias": "input"; "required": false; }; "field": { "alias": "field"; "required": false; }; "edit": { "alias": "edit"; "required": false; }; }, {}, never, never, false, never>;
}
