import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ShortenPipe implements PipeTransform {
    transform(value: any, limit: number): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShortenPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ShortenPipe, "shorten", false>;
}
