﻿var response_ok;
var geocoder;
var Livelli;
var MarkGps;
var Testi = new Array();
var infowindow;
var markerIndirizzo;
var map;
var w;
var h;
var drawingManager;
var selectedShape;
var selectedShapeArray = new Array();
var selectedShape_Copia;
var selectedColor;
var colorButtons = {};


var cosaStoDisegnando = google.maps.drawing.OverlayType.POLYGON;
var cosaPossoDisegnare = new Array();
var gisTipoOggettoXLavCod = new Array();
var gisTipoOggettoXLayer = new Array();
var placeLivelli = new Array();

var layerNonAlbero = new Array(
    2,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    14,
    15,
    16,
    17,
    18,
    33,
    51
);

//costanti
var inv16x16 = "inv16x16.png";
var trattore = "../AB_Immagini/Icone/trattore.png";
var flgSelezionato = "../AB_Immagini/Icone/FrecciaDN_32x16.png";
var CoordFromPoints = "";
var CoordFromPointsMVCArray = new google.maps.MVCArray();
var scala_colori_Array = new Array();
var centoH = $(window).height() - 15;
var centoW = $(window).width() - 15;
var centoH_xs = 300;
var centoW_xs = 550;
//var tool_bar_left = 765; // +img quando si aumentano le immagini va aumentato il left..

var separatoreChiaveAlbero = '§';
var zoomRicercaIndirizzo = 16;
var zoomRicercaIndirizzoxRitaglio = 17; //Zoom + ===>> indicare un numero maggiore
var offSetScrollTop = -150; //Offset per scroll dell'albero quando si clicka un poligono
var chiaveAlberoPlanning = "51";

var xCreazioneCombo = 'Version§ 5.10.038|GPS_Status§ 2|Status_Txt§ DGPS|Swath§ 22|Height§ -5,476|DateClosed§ 19/03/2012 00:00:00|TimeClosed§ 09:43:49am|AppldRate§ 13298,249|Moisture§ |Material§ Default_AppMaterial|MaterialID§ -1|Speed§ 0,013';
var xComboCorrenti = 'GPS_Status§Swath§Height§AppldRate§Status_Txt§Speed§';
//fine costanti

var AttivaSelezioneMultipla = true;

var place;

var Sementieri_Sportello_Configurazione_cod = -1;
var isSementi = false;
var AggiornaDatiGiasAlarm = false;
var CiSonoVecchiDatiNonImportati = false;
var glayerDoveDisegno = "-1";
var gOperazioneDiAgendaDoveDisegno = "-1";
var gNuovo = false;
var isDebug = false;
var AbilitaPF = false;

var overlay;


var indirizzohttp = location.pathname;
indirizzohttp = indirizzohttp.split("/")[indirizzohttp.split("/").length - 1];

var maxH;

var ctrlPressed = false;


var enum_TipoNodo = {
    Utente: 1,
    Impresa: 2,
    Centro: 3,
    Campo: 4,
    Serra: 41,
    Appezzamento: 5,
    ImpiantoNudo: 6,
    ImpiantoArborea: 7,
    ImpiantoErbacea: 8,
    ImpiantoOrticola: 9,
    Particella: 10,
    Persona: 11,
    CatastoAziendale: 18,
    Impianto_Generico: 19,
    Fabbricato_Generico: 20,
    f_Abitazione: 21,
    f_Magazzino: 22,
    f_Silos: 23,
    f_CellaFrigorifera: 24,
    f_ImpiantoLavorazione: 25,
    f_Stalla: 26,
    f_Fienile: 33,
    p_PortafoglioProdotti: 27,
    p_Prodotto: 28,
    p_Preparazione: 29,
    x_ConsistenzeAnimali: 30,
    x_MovimentiMagazzino: 31,
    x_PreparazioniAlimentari: 32,
    x_GiacenzeMagazzino: 34,
    x_ParcoMacchine: 35,
    x_Contatti: 36,
    x_ListaFabbricatiAziendali: 37,
    x_Cooperativa: 38,
    x_Consorzio: 39,
    x_OP: 40,
    Analisi_Certificato: 42,
    Analisi_Testata: 43,
    Analisi_Dettaglio: 44,
    Analisi_Campione: 45,
    PianoConcimazione_Testata: 46,
    DistintaDiProduzione: 47,
    x_VariazioniConsistenzeAnimali: 48,
    Cantine_Piani: 49,
    Cantine_Vasche: 50,
    PlanningTestata: 51,
    PlanningEntita: 52,
    PlanningEntitaImpianto: 53,
    Agenda: 54,
    ricette_Testata: 60,
    ricette_dettaglio: 61,
    Anagrafica_Generica: 62,
    AgendaDestinazioni: 63,
    precision: 64
};





function chiaveAlbero_ridotta_to_big(chiave) {
    var chiave_split = chiave.split("§");
    var tipo = chiave_split[0];

    var nuova_chiave = ['0'];
    for (var i = 0; i < 29 - 1; i++) {
        nuova_chiave.push('§0');
    }
    //modifico i stringavuota
    nuova_chiave[26] = '§';


    for (var i = 0; i < chiave_split.length; i++) {
        chiave_split[i] = '§' + chiave_split[i];
    }




    nuova_chiave[0] = tipo;

    $.logThis(chiave);

    switch (parseInt(tipo)) {
        case enum_TipoNodo.Agenda:
            //agenda
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[4] = chiave_split[3];
            nuova_chiave[5] = chiave_split[4];
            nuova_chiave[25] = chiave_split[5];
            break;

        case enum_TipoNodo.Appezzamento:
            //Appezzamento
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[3] = chiave_split[3];
            nuova_chiave[4] = chiave_split[4];
            break;
        case enum_TipoNodo.ImpiantoNudo:
            //terreno nudo
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[3] = chiave_split[3];
            nuova_chiave[4] = chiave_split[4];
            nuova_chiave[5] = chiave_split[5];
            break;

        case enum_TipoNodo.ricette_Testata:
            //ricetta 
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[4] = chiave_split[3];
            nuova_chiave[5] = chiave_split[4];
            nuova_chiave[28] = chiave_split[5];
            break;

        case enum_TipoNodo.Analisi_Testata:
            //analisi
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[17] = chiave_split[3];
            nuova_chiave[18] = chiave_split[4];
            nuova_chiave[19] = chiave_split[5];
            nuova_chiave[20] = chiave_split[6];
            break;
        //case (enum_TipoNodo.ImpiantoOrticola || enum_TipoNodo.ImpiantoArborea || enum_TipoNodo.ImpiantoErbacea): 
        case enum_TipoNodo.ImpiantoOrticola:
        case enum_TipoNodo.ImpiantoArborea:
        case enum_TipoNodo.ImpiantoErbacea:
            //orticole
            if (chiave_split.length == 6) {
                nuova_chiave[1] = chiave_split[1];
                nuova_chiave[2] = chiave_split[2];
                nuova_chiave[4] = chiave_split[3];
                nuova_chiave[5] = chiave_split[4];
            }
            else {
                if (chiave_split.length == 7) {
                    nuova_chiave[1] = chiave_split[1];
                    nuova_chiave[2] = chiave_split[2];
                    nuova_chiave[3] = chiave_split[3];
                    nuova_chiave[4] = chiave_split[4];
                    nuova_chiave[5] = chiave_split[5];
                }
                else {
                    alert("orticola/Arborea non gestita: tipo = " + tipo + " - dimensione = " + chiave_split.length + " - chiave: " + chiave_split.join());
                }
            }
            break;


        //        case enum_TipoNodo.ImpiantoErbacea: 
        //            //erbacee 
        //            nuova_chiave[1] = chiave_split[1]; 
        //            nuova_chiave[2] = chiave_split[2]; 
        //            nuova_chiave[3] = chiave_split[3]; 
        //            nuova_chiave[4] = chiave_split[4]; 
        //            nuova_chiave[5] = chiave_split[5]; 
        //            nuova_chiave[13] = chiave_split[6]; 
        //            nuova_chiave[14] = chiave_split[7]; 
        //            break; 


        case enum_TipoNodo.ricette_dettaglio:
            //orticole
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[3] = chiave_split[3];
            nuova_chiave[4] = chiave_split[4];
            nuova_chiave[5] = chiave_split[5];
            nuova_chiave[13] = chiave_split[6];
            nuova_chiave[14] = chiave_split[7];
            break;

        case enum_TipoNodo.precision:
            //orticole
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[3] = chiave_split[3];
            nuova_chiave[4] = chiave_split[4];
            nuova_chiave[5] = chiave_split[5];
            nuova_chiave[13] = chiave_split[6];
            nuova_chiave[14] = chiave_split[7];
            break;


        case enum_TipoNodo.PlanningEntitaImpianto:
            //orticole
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[23] = chiave_split[3];
            nuova_chiave[24] = chiave_split[4];
            break;

        case enum_TipoNodo.CatastoAziendale:
            $.logThis("chiave = " + chiave);
            $.logThis("chiave_split.length = " + chiave_split.length);

            if (chiave_split.length == 7) {

                $.logThis('//chiave senza "sezione catastale", "subalterno"');
                nuova_chiave[7] = chiave_split[2];
                nuova_chiave[8] = chiave_split[3];
                nuova_chiave[10] = chiave_split[4];
                nuova_chiave[11] = chiave_split[5];
            }

            if (chiave_split.length == 8) {

                if (isNaN(chiave_split[6])) {
                    $.logThis('//chiave con il "subalterno" impostato"');
                    nuova_chiave[7] = chiave_split[2];
                    nuova_chiave[8] = chiave_split[3];
                    nuova_chiave[10] = chiave_split[4];
                    nuova_chiave[11] = chiave_split[5];
                    nuova_chiave[12] = chiave_split[6]; //subalterno
                }
                else {
                    $.logThis('//chiave con la "sezione catastale" impostata"');
                    nuova_chiave[7] = chiave_split[2];
                    nuova_chiave[8] = chiave_split[3];
                    nuova_chiave[9] = chiave_split[4]; //sezione catastale
                    nuova_chiave[10] = chiave_split[5];
                    nuova_chiave[11] = chiave_split[6];
                }


            }

            $.logThis('//chiave completa"');
            if (chiave_split.length == 9) {

                nuova_chiave[7] = chiave_split[2];
                nuova_chiave[8] = chiave_split[3];
                nuova_chiave[9] = chiave_split[4]; //sezione catastale
                nuova_chiave[10] = chiave_split[5];
                nuova_chiave[11] = chiave_split[6];
                nuova_chiave[12] = chiave_split[7]; //subalterno
            }
            break;

        case enum_TipoNodo.AgendaDestinazioni:
            $.logThis("chiave AgendaDestinazioni= " + chiave);
            $.logThis("chiave_split.length = " + chiave_split.length);
            nuova_chiave[1] = chiave_split[1];
            nuova_chiave[2] = chiave_split[2];
            nuova_chiave[4] = chiave_split[3];
            nuova_chiave[5] = chiave_split[4];
            nuova_chiave[25] = chiave_split[5];
            break;


        default:
            if (tipo != 0)
                $.logThis("errore " + tipo + " : " + chiave);
            break;
    }

    $.logThis('join ' + nuova_chiave.join(''));

    var r = nuova_chiave.join('');
    return r.replace(",", "");
}




function cacheIt(event) {
    ctrlPressed = event.ctrlKey && AttivaSelezioneMultipla;
}
document.onkeydown = cacheIt;
document.onkeyup = cacheIt;

jQuery.logThis = function (text) {
    if ((window['console'] != undefined)) {
        console.log(text);
    }
}

/**
* Return a timestamp with the format "m/d/yy h:MM:ss TT"
* @type {Date}
*/

function logThisTime(descrizione) {
    $.logThis(descrizione + ": " + timeStamp());
}

function timeStamp() {
    // Create a date object with the current time
    var now = new Date();

    // Create an array with the current month, day and time
    var date = [now.getMonth() + 1, now.getDate(), now.getFullYear()];

    // Create an array with the current hour, minute and second
    var time = [now.getHours(), now.getMinutes(), now.getSeconds()];

    // Determine AM or PM suffix based on the hour
    var suffix = (time[0] < 12) ? "AM" : "PM";

    // Convert hour from military time
    time[0] = (time[0] < 12) ? time[0] : time[0] - 12;

    // If hour is 0, set it to 12
    time[0] = time[0] || 12;

    // If seconds and minutes are less than 10, add a zero
    for (var i = 1; i < 3; i++) {
        if (time[i] < 10) {
            time[i] = "0" + time[i];
        }
    }

    // Return the formatted string
    return date.join("/") + " " + time.join(":") + " " + suffix;
}


function initDatePiker() {
    //date
    $('.datepiker').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });
    $.datepicker.regional['it'];
}

function startsWith(str, find) {
    return str.indexOf(find) == 0;
}
function contains(str, find) {
    return str.indexOf(find) >= 0;
}

function sleep(milliseconds) {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds) {
            break;
        }
    }
}
/********************************* Arrotondare numero ***************/
function roundNumber(num, dec) {
    var result = Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
    return result;
}

/***********PER IL CALCOLO DEllA SCALA DEI COLORI ****************/
function hexToRgb(h) {
    var cutH = cutHex(h);
    var r = parseInt(cutH.substring(0, 2), 16),
            g = parseInt(cutH.substring(2, 4), 16),
            b = parseInt(cutH.substring(4, 6), 16);
    return r + '|' + g + '|' + b;
}

function cutHex(h) {
    return (h.charAt(0) == "#") ? h.substring(1, 7) : h
}


function RGB2Color(r, g, b) {
    return '#' + this.byte2Hex(r) + this.byte2Hex(g) + this.byte2Hex(b);
}

function byte2Hex(n) {
    var nybHexString = "0123456789ABCDEF";
    return String(nybHexString.substr((n >> 4) & 0x0F, 1)) + nybHexString.substr(n & 0x0F, 1);
}

jQuery.removeFromArray = function (value, arr) {
    return jQuery.grep(arr, function (elem, index) {
        return elem !== value;
    });
};

function collassaDatiTabella(tabella, hidden) {

    var rval = "";
    if ($(tabella).html() != null) {
        var rows = $(tabella + " tr"); // skip the header row        
        rows.each(function (index) {
            var combo = $(this).find('td:eq(0) input');
            $.logThis("cmb = " + $(this).html());
            $.logThis("cmb1 = " + $(combo).attr('id'));
            $.logThis("cked = " + $(combo).is(':checked'));
            if (combo.is(':checked')) {
                var toAdd = $(hidden).val() + combo.attr('id').replace('ckSp_', '') + ",";
                $.logThis(toAdd);
                $(hidden).val(toAdd);
            }
        });

        rval = $(hidden).val() + "-1";
        $(hidden).val("");
    }
    return rval;

}
function selezionaIndiceLayerDoveScrivoDaOggettoGrafico() {
    if (!!selectedShape) {
        settaLayerDoveDisegnare(selectedShape.layerDiAppartenenza, selectedShape.icona32, selectedShape.layerDiAppartenenza_nome);
    }
}

function selezionaIndiceLayerDoveScrivoDaAlbero(livello, chiaveAlbero) {


    $.logThis('selezionaIndiceLayerDoveScrivoDaAlbero(livello:=$(' + livello + "), chiaveAlbero:=" + chiaveAlbero);


    var chiaviAlberoLayer = livello.TipoNodoAlberoAnagrafe.split(",");
    //    var chiaveID = chiaveAlbero.split("\\")[0];
    var chiaveID = chiaveAlbero.split(separatoreChiaveAlbero)[0]; //todo, verifica separatoratore
    for (var i = 0; i < chiaviAlberoLayer.length; i++) {
        if (chiaviAlberoLayer[i] == chiaveID) {
            settaLayerDoveDisegnare(livello.id, livello.icona32, livello.nome);
            return true;
        }

    }

    return false
}

function getArea() {

    var area = 0;
    $.logThis('calcolo dellArea:' + area);

    if (CoordFromPoints == '') {
        var MVCArray = selectedShape.getPath();
        area = google.maps.geometry.spherical.computeArea(MVCArray);

    }
    else {
        area = google.maps.geometry.spherical.computeArea(CoordFromPointsMVCArray);
    }

    area = roundNumber(area / 10000, 4);

    $.logThis('mvcarray:' + CoordFromPointsMVCArray);
    $.logThis('Area calcolat:' + area);
    return area;
}

function leggiColoreDaDiv(chiaveDiv, valore) {

    var f = 0.0;
    var fValore = roundNumber(parseFloat(valore), 2);


    var max = 0;
    for (var i = 0; i < scala_colori_Array.length; i++) {

        if (scala_colori_Array[i].id == chiaveDiv) {
            max = i;

            f = parseFloat(scala_colori_Array[i].valore_min);

            var a = scala_colori_Array[i].colore.toString().replace(')', '').replace('rgba(', '').split(',');
            var rval = RGB2Color(parseInt(a[0].replace(' ', '')), parseInt(a[1].replace(' ', '')), parseInt(a[2].replace(' ', '')));

            if (f != 999999990 && f >= fValore) {
                return rval;
            }
        }

    }


    var b = scala_colori_Array[max].colore.toString().replace(')', '').replace('rgba(', '').split(',');

    //    $.logThis('COLORO :' + parseInt(b[0].replace(' ', '')) + " -- " + parseInt(b[1].replace(' ', '')) + " -- " + parseInt(b[2].replace(' ', '')));
    //    $.logThis('scala_colori_Array :' + scala_colori_Array[max].valore_min);


    return RGB2Color(parseInt(b[0].replace(' ', '')), parseInt(b[1].replace(' ', '')), parseInt(b[2].replace(' ', '')));

}


function calcolaColore(v_min, v_max, valore, colore1, colore2, varianza) {
    if (colore2 == "") {
        return colore1;
    } else {


        var range = [{
            0: parseInt(hexToRgb(colore1).split("|")[0]),
            1: parseInt(hexToRgb(colore2).split("|")[0])
        }, {
            0: parseInt(hexToRgb(colore1).split("|")[1]),
            1: parseInt(hexToRgb(colore2).split("|")[1])
        }, {
            0: parseInt(hexToRgb(colore1).split("|")[2]),
            1: parseInt(hexToRgb(colore2).split("|")[2])
        }];

        var n_step = (v_max - v_min) / varianza;


        var moltiplicatore = 0.0;
        moltiplicatore = parseFloat(((valore - v_min) / n_step) - 0.5);

        if (moltiplicatore < 0) moltiplicatore = -moltiplicatore;
        var app;
        var indice;

        var r, g, b;

        app = (range[0]['1'] - range[0]['0']) / (varianza - 1);
        r = parseInt(parseInt(range[0]['0']) + parseInt(app * moltiplicatore));

        app = (range[1]['1'] - range[1]['0']) / (varianza - 1);
        g = parseInt(parseInt(range[1]['0']) + parseInt(app * moltiplicatore));

        app = (range[2]['1'] - range[2]['0']) / (varianza - 1);
        b = parseInt(parseInt(range[2]['0']) + parseInt(app * moltiplicatore));

        return RGB2Color(r, g, b);
    }
}

function cmbViste_change() {
    $('#WaitFrame').show();
    selezionaDivVista();
    clearOverlaysByID(50);
    ImpostaShape(false);
    $('#WaitFrame').hide();
}

function colorOverlaysByID(id) {

    for (var i = 0; i < Livelli.length; i++) {
        if (Livelli[i].id == id) {

            clearSingleOverlay(null, Livelli[i].poligoni, true);
            clearSingleOverlay(null, Livelli[i].punti, true);
            clearSingleOverlay(null, Livelli[i].polyline, true);
            clearSingleOverlay(null, Livelli[i].ABLabel, true);

        }
    }

}

function selezionaDivVista() {
    $('#scala_colori_descrizione').html($("#cmbViste option:selected").text());
    $('.pannello_scala_colori').hide();
    $('#' + $("#cmbViste option:selected").text()).show();
}

function indiceCorrenteDivVista(datiViste) {
    for (var i = 0; i < datiViste.length; i++)
        if (datiViste[i].nome == $("#cmbViste option:selected").text())
            return i;

    return -1;
}


function PopolaComboPannelloColore(dati, datiValidi) {

    var html = "";
    var vDati = dati.split("|");
    for (var i = 0; i < vDati.length; i++) {
        var vLabels = vDati[i].split("§");
        if (contains(datiValidi, vLabels[0] + '§')) {
            html = html + "<option value='" + vLabels[0] + '§' + "'>" + vLabels[0] + "</option>";
        }
    }

    $("#cmbViste").html(html);
}
function CreaPannelloColore(descrizione, datiViste) {

    if (datiViste != undefined) {

        CreaPannelloColore_Disponi(datiViste.length);

        var html = "";

        for (var i = 0; i < datiViste.length; i++) {
            //$.logThis(datiViste[i]); todo, verifica appidrate che non va!
            html = html + CreaPannelloColore_Disegna(datiViste[i].nome, datiViste[i].colore_primario, datiViste[i].colore_secondario, datiViste[i].v_min, datiViste[i].v_max, datiViste[i].varianza);
        }

        $('#scala_colori').html(html);

        selezionaDivVista();
    }

}

function CreaPannelloColore_Disponi(conteggio) {
    var w = 0;
    w = $('#map').width() - 50 - $('#dialog_Ricerca').width();

    $('#scala_colori_contenitore').width(w);
    $('#scala_colori').width(w);


    var pp = $("#map").offset();
    $("#scala_colori_contenitore").css({
        position: 'absolute',
        bottom: 0,
        left: pp.left
    });



    $("#SetBack").css({
        position: 'absolute',
        bottom: 70,
        left: pp.left
    });
}


function CreaPannelloColore_Disegna(id, colore1, colore2, v_min, v_max, varianza) {
    //calcolo l'altezza di ogni div
    var altezza = parseInt($('#scala_colori').width() / varianza);

    var range = [{
        0: parseInt(hexToRgb(colore1).split("|")[0]),
        1: parseInt(hexToRgb(colore2).split("|")[0])
    }, {
        0: parseInt(hexToRgb(colore1).split("|")[1]),
        1: parseInt(hexToRgb(colore2).split("|")[1])
    }, {
        0: parseInt(hexToRgb(colore1).split("|")[2]),
        1: parseInt(hexToRgb(colore2).split("|")[2])
    }];


    var var_valor = parseFloat((v_max - v_min) / (varianza - 1));
    var i = 0;

    var var_r = (range[0]['1'] - range[0]['0']) / (varianza - 1);
    var var_g = (range[1]['1'] - range[1]['0']) / (varianza - 1);
    var var_b = (range[2]['1'] - range[2]['0']) / (varianza - 1);


    var html = "<div id='" + id + "' class='pannello_scala_colori'>";
    for (i = 0; i < varianza; i++) {

        var colore = 'rgba(';

        colore += parseInt(range[0]['0'] + parseInt(var_r * i)) + ',';

        colore += parseInt(range[1]['0'] + parseInt(var_g * i)) + ',';

        colore += parseInt(range[2]['0'] + parseInt(var_b * i)) + " ,  0.6)";

        html = html + "<div  style='height:30px; width:" + altezza + "px; background-color:" + colore + "; float:left;'>"
        var app = roundNumber((v_min + (var_valor * i)), 2);
        html = html + app;
        html = html + "</div>";

        scala_colori_Array.push({
            id: id,
            valore_min: app,
            colore: colore
        });


    }


    html = html + "</div><div style='clear:both'></div>";
    return html;
}








/********************************************************************/
/********************** INIT ****************************************/
/********************************************************************/

function cleanMap() {
}
function initNewMap() {
    var latlngc = new google.maps.LatLng(44.168615, 12.269121);
    //Carico i layer
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 8,
        center: latlngc,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        streetViewControl: false,
        zoomControlOptions: {
            style: google.maps.ZoomControlStyle.SMALL,
            position: google.maps.ControlPosition.LEFT_TOP
        },
        zoomControl: true
    });
}




/* inizializzazione della mappa */
function initialize() {
    initDatePiker();
    //CreaPannelloColore(50,160,"#E01B6A","#1B8EE0",5);
    geocoder = new google.maps.Geocoder();

    cosaPossoDisegnare.push(google.maps.drawing.OverlayType.POLYGON)

    ImpostaLayer();

    inizializzaArrayCosaPossodisegnare();

    initNewMap();


    /*demo*/

    /* demo */



    var polyOptions = {
        strokeWeight: 0,
        fillOpacity: 0.6,
        editable: true
    };

    //per la creazione dell'interfaccia di edit dei poligoni
    drawingManager = new google.maps.drawing.DrawingManager({
        drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_RIGHT,
            drawingModes: [google.maps.drawing.OverlayType.POLYGON, google.maps.drawing.OverlayType.MARKER]
        },
        markerOptions: {
            draggable: true
        },
        polylineOptions: {
            editable: true
        },
        drawingControl: false,
        polygonOptions: polyOptions,
        map: map
    });

    $(document).on("click", "#LayerSelezionaTutto", function () {
        clickLayerSelezionaTutto(true);
    });

    $(document).on("click", "#LayerDeSelezionaTutto", function () {
        clickLayerSelezionaTutto(false);
    });

    $(document).on("click", "#selimg_multipoint", function () {
        switchDrawingMode(google.maps.drawing.OverlayType.MARKER);
    });


    $(document).on("click", "#selimg_poligono", function () {
        switchDrawingMode(google.maps.drawing.OverlayType.POLYGON);
    });

    /*al completamento del poligono */
    google.maps.event.addListener(drawingManager, 'overlaycomplete', function (e) {

        $.logThis("overlaycomplete");

        var newShape = e.overlay;
        newShape.type = e.type;

        if (e.type != google.maps.drawing.OverlayType.MARKER) {

            drawingManager.setDrawingMode(null);
            google.maps.event.addListener(newShape, 'click', function () {
                setSelection(newShape);
            });
            setSelection(newShape);
            if (glayerDoveDisegno != "-1") {
                preparaXSalvataggioPoligoni();
            } else {
                alert("non è stato selezionato alcun layer dove disegnare. Selezionare un layer facendo click sulla relativa icona nell elenco dei layer.");

                if (selectedShape != undefined) {
                    selectedShape.setMap(null);
                }
                clearSelectionBoth();

            }

        } else {

            $.logThis("addMarkerMultiPoint");
            addMarkerMultiPoint($("#chkMP"), $("#hiddenMultipoint"), null, newShape.getPosition());

        }


    });

    // Clear the current selection when the drawing mode is changed, or when the
    // map is clicked.
    google.maps.event.addListener(drawingManager, 'drawingmode_changed', clearSelectionBoth);


    google.maps.event.addListener(map, 'click', clearSelection);

    google.maps.event.addDomListener(document.getElementById('delete-button'), 'click', deleteSelectedShape);
    google.maps.event.addDomListener(document.getElementById('save-button'), 'click', preparaXSalvataggioPoligoni);


    google.maps.event.addDomListener(document.getElementById('disenga_poligono'), 'click', CreaPoligono);


    google.maps.event.addDomListener(document.getElementById('select_poligono'), 'click', SelezionaPoligono);
    google.maps.event.addDomListener(document.getElementById('info_appezzamento'), 'click', Info_Poligono);
    google.maps.event.addDomListener(document.getElementById('PianoRateoVariabile'), 'click', dialogRateo);
    google.maps.event.addDomListener(document.getElementById('GeneraPlanning'), 'click', dialogGeneraPlanning);


    makeToolBar();






}

function mostraImmagine(immagine, mostraNascondi) {
    if (mostraNascondi) {
        $(immagine).show();
    }
    else {
        $(immagine).hide();
    }
}


function InizializzaMenuCosaDisegno() {

    $.logThis("inizializza Long Press!");
    $("#disenga_poligono").mouseup(function () {
        clearTimeout(pressTimer)
        // Clear timeout
        $.logThis("mouseup Long Press!");
        return false;
    }).mousedown(function () {
        // Set timeout
        pressTimer = window.setTimeout(function () { mostraMenuCosaDisegno() }, 1000)
        return false;
    });
}

function mostraMenuCosaDisegno() {

    $.logThis("mousedown Long Press!");
    mostraMenuCosaDisegnoPreparaStrumenti();

}

function nascondoMenuCosaDisegno() {
    $("#selimg_poligono").hide();
    $("#selimg_multipoint").hide();
}

function mostraMenuCosaDisegnoPreparaStrumenti() {
    nascondoMenuCosaDisegno();
    decidiCosaPossoDisegnare();

    // questo si può sempre disegnare?
    $("#selimg_poligono").show();
    $("#divCosaDisegno").show();

    for (var i = 0; i < cosaPossoDisegnare.length; i++) {
        switch (cosaPossoDisegnare[i]) {
            case google.maps.drawing.OverlayType.POLYGON:
                $("#selimg_poligono").show();
                break;
            case google.maps.drawing.OverlayType.MARKER:
                $("#selimg_multipoint").show();
                break;
        }
    }

}


function decidiCosaPossoDisegnare() {

    cosaPossoDisegnare = new Array();

    $.logThis("decidiCosaPossoDisegnare - glayerDoveDisegno = " + glayerDoveDisegno + " - gisTipoOggettoXLayer.Length = " + gisTipoOggettoXLayer.Length);

    // per layer
    for (var i = 0; i < gisTipoOggettoXLayer.length; i++) {

        $.logThis("gisTipoOggettoXLayer[" + i + "].layer = " + gisTipoOggettoXLayer[i].layer);
        $.logThis("gisTipoOggettoXLayer[" + i + "].GIS_TipoOggetto_Cod = " + gisTipoOggettoXLayer[i].GIS_TipoOggetto_Cod);

        if (gisTipoOggettoXLayer[i].layer == glayerDoveDisegno) {

            var lChePossoDisegnare = gisTipoOggettoXLayer[i].GIS_TipoOggetto_Cod;
            if (!cosaPossoDisegnare.indexOf(lChePossoDisegnare) > -1) {

                cosaPossoDisegnare.push(lChePossoDisegnare)
                $.logThis("cosaPossoDisegnare.push(" + lChePossoDisegnare + ")");
            }

        }
    }


    //per operazione di agenda


}

function verificaSePossoDisegnareQuesto(cosaVoglioDisegnare) {
    for (var i = 0; i < cosaPossoDisegnare.length; i++) {
        if (cosaPossoDisegnare[i] == cosaVoglioDisegnare)
            return true;
    }

    return false;
}

function ripulisciImmaginiCosaDisegno() {
    mostraImmagine("#img_poligono", false);
    mostraImmagine("#img_multipoint", false);
}



function switchDrawingMode(cosaVoglioDisegnare) {

    $.logThis("switchDrawingMode(" + cosaVoglioDisegnare + ")");

    //    if (!verificaSePossoDisegnareQuesto(cosaVoglioDisegnare))
    //        return false;

    cosaStoDisegnando = cosaVoglioDisegnare;
    ripulisciImmaginiCosaDisegno();

    switch (cosaVoglioDisegnare) {
        case google.maps.drawing.OverlayType.POLYGON:

            $("#chkMP").removeAttr("checked");
            mostraImmagine("#img_poligono", true);
            break;

        case google.maps.drawing.OverlayType.MARKER:
            $("#chkMP").prop("checked", "checked");

            mostraImmagine("#img_multipoint", true);
            break;
    }

    drawingManager.setDrawingMode(cosaStoDisegnando);
    $.logThis("drawingManager.setDrawingMode(" + cosaStoDisegnando + ");")
    $("#divCosaDisegno").hide();

}

function inizializzaArrayCosaPossodisegnare() {

    $.logThis("inizializzaArrayCosaPossodisegnare");

    // i poligono al momento sono ammessi ovunque. indico solo i punti, quindi
    gisTipoOggettoXLayer.push({
        layer: 50,
        GIS_TipoOggetto_Cod: google.maps.drawing.OverlayType.MARKER
    });
    gisTipoOggettoXLayer.push({
        layer: 63,
        GIS_TipoOggetto_Cod: google.maps.drawing.OverlayType.MARKER
    });
    gisTipoOggettoXLayer.push({
        layer: 13,
        GIS_TipoOggetto_Cod: google.maps.drawing.OverlayType.MARKER
    });

    $.logThis("inizializzaArrayCosaPossodisegnare len= " + gisTipoOggettoXLayer.length);

}



function ImpostaLayer() {
    Livelli = new Array();
    MarkGps = new Array();
    for (var i = 0; i < layers.length; i++) {
        Livelli.push({
            nome: layers[i].nome,
            id: layers[i].id,
            colore_1: layers[i].colore_1,
            colore_2: layers[i].colore_2,
            varianza: layers[i].varianza,
            TipoNodoAlberoAnagrafe: layers[i].TipoNodoAlberoAnagrafe,
            icona16: layers[i].icona16,
            icona32: layers[i].icona32,
            datiViste: layers[i].tiles,
            poligoni: new Array(),
            punti: new Array(),
            polyline: new Array(),
            ABLabel: new Array()
        });
    }


}

function getByA(vettore, A) {
    //$.logThis("cerco per A = " + A);
    return $.grep(vettore, function (e) { return e.A == A; })[0];

}

function getByB(vettore, B) {
    //$.logThis("cerco per B = " + B);
    return $.grep(vettore, function (e) { return e.B == B; })[0];

}

function getPlaceByID(id) {

    return $.grep(place, function (e) { return e.id == id; })[0];

}

function objectFindByKey(array, key, value) {
    //    $.logThis("cerco: " + value + " sul campo " + key);
    //    $.logThis(array);
    //    $.logThis('len ' + array.length);

    for (var i = 0; i < array.length; i++) {
        //        $.logThis("da vett.:" + array[i][key]);
        //        $.logThis("cerco:" + value);
        if (array[i][key] === value) {
            //            $.logThis("trovato!");
            return array[i];
        }
    }
    return null;
}

function GETvAppIdRateDaStringa(AppIdRate) {
    return AppIdRate.split("|");
}

function GETvaloreAppIdRateDaStringa(AppIdRate, chiave) {
    var vAppIdRate = AppIdRate.split("|");

    for (var k = 0; k < vAppIdRate.length; k++) {

        var chiaveValore = vAppIdRate[k].split("§ ");
        if (chiaveValore[0] == chiave)
            return chiaveValore[1];

    }

    return undefined;
}

function GETvAppIdRateChiaviValori(AppIdRate) {
    return AppIdRate.split("§ ");
}


function SettaMaxMin(AppIdRate, elemento) {

    var vAppIdRate = GETvAppIdRateDaStringa(AppIdRate);

    for (var i = 0; i < elemento.length; i++) {

        for (var k = 0; k < vAppIdRate.length; k++) {

            var cvAppIdRate = GETvAppIdRateChiaviValori(vAppIdRate[k]);

            if (contains(elemento[i].nome, cvAppIdRate[0])) {

                if ($.isNumeric(cvAppIdRate[1])) {

                    if (parseInt(cvAppIdRate[1]) < elemento[i].v_min) {
                        elemento[i].v_min = parseFloat(cvAppIdRate[1]);
                        //$.logThis(elemento[i].v_min);
                    }

                    if (parseInt(cvAppIdRate[1]) > elemento[i].v_max) {
                        elemento[i].v_max = parseFloat(cvAppIdRate[1]);
                    }
                }


            }


        }

    }
}





function ImpostaShape(riCreaPannelloColore) {
    var l_place = place.length;
    var l_livelli = Livelli.length;

    placeLivelli = new Array();
    for (var i = 0; i < l_livelli; i++) {
        placeLivelli[Livelli[i].id] = Livelli[i];
    }




    //Identifico i Min e Max
    if (riCreaPannelloColore == true) {
        for (var i = 0; i < l_place; i++) {
            if (placeLivelli[place[i].layer].datiViste != undefined) {
                SettaMaxMin(place[i].AppIdRate, placeLivelli[place[i].layer].datiViste);
            }

            //            for (var kk = 0; kk < l_livelli; kk++) {
            //                if (Livelli[kk].id == place[i].layer) {
            //                    if (Livelli[kk].datiViste != undefined) {
            //                        SettaMaxMin(place[i].AppIdRate, Livelli[kk].datiViste);
            //                    }
            //                }
            //            }
        } //next i
    }
    else {
        alert('ooo');
        //        for (var i = 0; i < l_place; i++) {
        //                 if (Livelli[kk].id == place[i].layer) {
        //                    if (Livelli[kk].datiViste != undefined) {
        //                        var l_livelli_poligoni = Livelli[kk].poligoni.length;
        //                        for (var z = 0; z < l_livelli_poligoni; z++) {
        //                            Livelli[kk].poligoni[z].setMap(null);
        //                        }
        //                        Livelli[kk].poligoni = new Array();
        //                        placeLivelli[place[i].layer].
        //                    }
        //                }
        //            }
        //        }
    } //next i

    kk = 0;

    if (riCreaPannelloColore == true) {
        PopolaComboPannelloColore(xCreazioneCombo, xComboCorrenti);

        for (var j = 0; j < l_livelli; j++) {
            CreaPannelloColore('abc', Livelli[j].datiViste);
        }
    }
    //trovo i limiti estremi della mappa
    var latlngAutoFit = new google.maps.LatLngBounds();

    //    $.logThis("l_place" + l_place);
    //    $.logThis("l_livelli" + l_livelli);


    for (var i = 0; i < l_place; i++) {
        var polygonPaths = [];

        var lat_centro = 0;
        var lng_centro = 0;

        var p_place = place[i];

        var l_place_vertici = p_place.vertici.length;
        for (var j = 0; j < l_place_vertici; j++) {
            var l_at = p_place.vertici[j].lat;
            var l_ong = p_place.vertici[j].long;
            polygonPaths.push(new google.maps.LatLng(l_at, l_ong));
            lat_centro += parseFloat(l_at);
            lng_centro += parseFloat(l_ong);
            latlngAutoFit.extend(new google.maps.LatLng(l_at, l_ong));
        }

        lat_centro = lat_centro / j;
        lng_centro = lng_centro / j;


        //        $.logThis($.Enumerable.From(Livelli).Where("$.id ==" + place[i].layer).ToArray().length);

        //for (var kk = 0; kk < l_livelli; kk++) {

        var k_livelli = placeLivelli[place[i].layer];
        //if (k_livelli.id == place[i].layer) {

        var colore_poligon;
        var selectedColor = '#222222';

        var v_min = 0.0;
        var v_max = 0.0;
        var colore_1 = "";
        var colore_2 = "";
        var varianza = "";

        if (k_livelli.datiViste != undefined) {
            var curAppIdRate = GETvaloreAppIdRateDaStringa(place[i].AppIdRate, $("#cmbViste option:selected").text());
            colore_poligon = leggiColoreDaDiv($("#cmbViste option:selected").text(), curAppIdRate);
        }
        else {
            if (k_livelli.v_min === "undefined") {
                $("#scala_colori_contenitore").hide();
            }
            v_min = k_livelli.v_min;
            v_max = k_livelli.v_max;
            colore_1 = k_livelli.colore_1;
            colore_2 = k_livelli.colore_2;
            variaza = k_livelli.varianza;
            colore_poligon = calcolaColore(v_min, v_max, curAppIdRate, colore_1, colore_2, varianza);
        }


        ShapeAggiungiOggetti(p_place, k_livelli, colore_poligon, polygonPaths, lat_centro, lng_centro);

        kk = l_livelli;
        // } //for kk
        //} //for i


        polygonPaths = null;
        lat_centro = null;
        lng_centro = null;
        p_place = null;

    }


    for (var i = 0; i < l_livelli; i++) {
        if (riCreaPannelloColore == false) {
            if (Livelli[i].id == '50')
                ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
        }
        else {
            ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
            ImpostaMappa(Livelli[i].punti, true, true, 'point'); //vanni, 17/04/2013 per selezione markers
            ImpostaMappa(Livelli[i].polyline, false, false, 'poly');
            ImpostaMappa(Livelli[i].ABLabel, false, false, 'poly');
        }
    }

    if (riCreaPannelloColore)
        map.setCenter(latlngAutoFit.getCenter(), map.fitBounds(latlngAutoFit));

    $('#WaitFrame').hide();

}


function ShapeAggiungiOggetti(p_place, k_livelli, colore_poligon, polygonPaths, lat_centro, lng_centro) {
    switch (p_place.TipologiaGML) {
        case 'Point':
            var punto;

            if (p_place.tipoicona == "Trattore") {

                punto = new google.maps.Marker({
                    html: p_place.id,
                    position: polygonPaths[0],
                    draggable: false,
                    icon: trattore
                });
            }
            else {

                var isDraggable;
                isDraggable = !(p_place.layer == 55)

                punto = new google.maps.Marker({
                    html: p_place.id,
                    position: polygonPaths[0],
                    draggable: isDraggable,
                    icon: k_livelli.icona16,
                    layerDiAppartenenza: p_place.layer,
                    chiavealbero: chiaveAlbero_ridotta_to_big(p_place.chiavealbero)
                });
            }



            var lbl;
            lbl = new Label({ text: p_place.Testo, html: p_place.id });
            lbl.bindTo('position', punto, 'position');

            k_livelli.punti.push(punto);
            k_livelli.ABLabel.push(lbl);
            break;
        case 'LineString':
            if (p_place.vertici.length == 2) {
                k_livelli.polyline.push(new google.maps.Polyline({
                    html: p_place.id,
                    path: polygonPaths,
                    zIndex: 100000,
                    layerDiAppartenenza: p_place.layer,
                    icona32: k_livelli.icona32,
                    layerDiAppartenenza_nome: k_livelli.nome,
                    flag_gps: p_place.flag_gps
                }));
            }
            else {
                //Linestring
                k_livelli.polyline.push(new google.maps.Polyline({
                    html: p_place.id,
                    path: polygonPaths,
                    strokeColor: '#' + colore_poligon,
                    fillOpacity: 1.0,
                    strokeWeight: 1,
                    zIndex: 100000,
                    layerDiAppartenenza: p_place.layer,
                    icona32: k_livelli.icona32,
                    layerDiAppartenenza_nome: k_livelli.nome,
                    flag_gps: p_place.flag_gps
                }));
            }
            break;
        case 'Polygon':
            //Poligoni
            colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

            k_livelli.poligoni.push(new google.maps.Polygon({
                html: p_place.id,
                vegcod: p_place.veg_cod,
                inserimento: p_place.inserimento,
                Entita_Cod: p_place.Entita_Cod,
                modifica: p_place.modifica,
                cancellazione: p_place.cancellazione,
                informazioni: p_place.informazioni,
                chiavealbero: chiaveAlbero_ridotta_to_big(p_place.chiavealbero),
                AppIdRate: p_place.AppIdRate,
                testo: p_place.Testo,
                paths: polygonPaths,
                strokeColor: colore_poligon,
                fillOpacity: 0.6,
                strokeWeight: 1,
                fillColor: colore_poligon,
                selectedColor: '#7d7d7d',
                colore_precedente: colore_poligon,
                zIndex: p_place.zindex,
                layerDiAppartenenza: p_place.layer,
                icona32: k_livelli.icona32,
                layerDiAppartenenza_nome: k_livelli.nome,
                flag_gps: p_place.flag_gps
            }));
            break;
        case 'MultiSurface':
            //Poligoni
            colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

            k_livelli.poligoni.push(new google.maps.Polygon({
                html: p_place.id,
                vegcod: p_place.veg_cod,
                inserimento: p_place.inserimento,
                Entita_Cod: p_place.Entita_Cod,
                modifica: p_place.modifica,
                cancellazione: p_place.cancellazione,
                informazioni: p_place.informazioni,
                chiavealbero: chiaveAlbero_ridotta_to_big(p_place.chiavealbero),
                AppIdRate: p_place.AppIdRate,
                testo: p_place.Testo,
                paths: polygonPaths,
                strokeColor: colore_poligon,
                fillOpacity: 0.6,
                strokeWeight: 1,
                fillColor: colore_poligon,
                selectedColor: '#7d7d7d',
                colore_precedente: colore_poligon,
                zIndex: p_place.zindex,
                layerDiAppartenenza: p_place.layer,
                icona32: k_livelli.icona32,
                layerDiAppartenenza_nome: k_livelli.nome,
                flag_gps: p_place.flag_gps
            }));
            break;
        default:
            alert(p_place.TipologiaGML);
    }

    if (p_place.flag_gps == '1') {
        //calcolo il baricentro del poligono
        //aggiungo l'icona
        var myLatlng = new google.maps.LatLng(lat_centro, lng_centro);

        if ($('#chk_mostra_GPS').is(':checked') == true) {
            MarkGps.push(new google.maps.Marker({
                position: myLatlng,
                map: map,
                icon: variabile_gps
            }));
        }
    }
}

//function ImpostaShape(riCreaPannelloColore) {

//    var l_place = place.length;
//    var l_livelli = Livelli.length;

//    //Identifico i Min e Max
//    if (riCreaPannelloColore == true) {
//        for (var i = 0; i < l_place; i++) {
//            for (var kk = 0; kk < l_livelli; kk++) {
//                if (Livelli[kk].id == place[i].layer) {
//                    if (Livelli[kk].datiViste != undefined) {
//                        SettaMaxMin(place[i].AppIdRate, Livelli[kk].datiViste);
//                    }
//                }
//            }
//        } //next i
//    }
//    else {
//        for (var i = 0; i < l_place; i++) {
//            for (var kk = 0; kk < l_livelli; kk++) {
//                if (Livelli[kk].id == place[i].layer) {
//                    if (Livelli[kk].datiViste != undefined) {
//                        var l_livelli_poligoni = Livelli[kk].poligoni.length;
//                        for (var z = 0; z < l_livelli_poligoni; z++) {
//                            Livelli[kk].poligoni[z].setMap(null);
//                        }
//                        Livelli[kk].poligoni = new Array();
//                    }
//                }
//            }
//        }
//    } //next i

//    kk = 0;

//    if (riCreaPannelloColore == true) {
//        PopolaComboPannelloColore(xCreazioneCombo, xComboCorrenti);

//        for (var j = 0; j < l_livelli; j++) {
//            CreaPannelloColore('abc', Livelli[j].datiViste);
//        }
//    }
//    //trovo i limiti estremi della mappa
//    var latlngAutoFit = new google.maps.LatLngBounds();

////    $.logThis("l_place" + l_place);
////    $.logThis("l_livelli" + l_livelli);


//    for (var i = 0; i < l_place; i++) {
//        var polygonPaths = [];

//        var lat_centro = 0;
//        var lng_centro = 0;

//        var p_place = place[i];

//        var l_place_vertici = p_place.vertici.length;
//        for (var j = 0; j < l_place_vertici; j++) {
//            var l_at = p_place.vertici[j].lat;
//            var l_ong = p_place.vertici[j].long;
//            polygonPaths.push(new google.maps.LatLng(l_at, l_ong));
//            lat_centro += parseFloat(l_at);
//            lng_centro += parseFloat(l_ong);
//            latlngAutoFit.extend(new google.maps.LatLng(l_at, l_ong));
//        }

//        lat_centro = lat_centro / j;
//        lng_centro = lng_centro / j;


////        $.logThis($.Enumerable.From(Livelli).Where("$.id ==" + place[i].layer).ToArray().length);

//        for (var kk = 0; kk < l_livelli; kk++) {
//            var k_livelli = Livelli[kk];
//            if (k_livelli.id == place[i].layer) {

//                var colore_poligon;
//                var selectedColor = '#222222';

//                var v_min = 0.0;
//                var v_max = 0.0;
//                var colore_1 = "";
//                var colore_2 = "";
//                var varianza = "";

//                if (k_livelli.datiViste != undefined) {
//                    var curAppIdRate = GETvaloreAppIdRateDaStringa(place[i].AppIdRate, $("#cmbViste option:selected").text());
//                    colore_poligon = leggiColoreDaDiv($("#cmbViste option:selected").text(), curAppIdRate);
//                }
//                else {
//                    if (k_livelli.v_min === "undefined") {
//                        $("#scala_colori_contenitore").hide();
//                    }
//                    v_min = k_livelli.v_min;
//                    v_max = k_livelli.v_max;
//                    colore_1 = k_livelli.colore_1;
//                    colore_2 = k_livelli.colore_2;
//                    variaza = k_livelli.varianza;
//                    colore_poligon = calcolaColore(v_min, v_max, curAppIdRate, colore_1, colore_2, varianza);
//                }


//                switch (p_place.TipologiaGML) {
//                    case 'Point':
//                        var punto;

//                        if (p_place.tipoicona == "Trattore") {

//                            punto = new google.maps.Marker({
//                                html: p_place.id,
//                                position: polygonPaths[0],
//                                draggable: false,
//                                icon: trattore
//                            });
//                        }
//                        else {

//                            var isDraggable;
//                            isDraggable = !(p_place.layer == 55)

//                            punto = new google.maps.Marker({
//                                html: p_place.id,
//                                position: polygonPaths[0],
//                                draggable: isDraggable,
//                                icon: k_livelli.icona16,
//                                chiavealbero: p_place.chiavealbero
//                            });
//                        }



//                        var lbl;
//                        lbl = new Label({ text: p_place.Testo, html: p_place.id });
//                        lbl.bindTo('position', punto, 'position');

//                        k_livelli.punti.push(punto);
//                        k_livelli.ABLabel.push(lbl);
//                        break;
//                    case 'LineString':
//                        if (p_place.vertici.length == 2) {
//                            k_livelli.polyline.push(new google.maps.Polyline({
//                                html: p_place.id,
//                                path: polygonPaths,
//                                zIndex: 100000,
//                                flag_gps: p_place.flag_gps
//                            }));
//                        }
//                        else {
//                            //Linestring
//                            k_livelli.polyline.push(new google.maps.Polyline({
//                                html: p_place.id,
//                                path: polygonPaths,
//                                strokeColor: '#' + colore_poligon,
//                                fillOpacity: 1.0,
//                                strokeWeight: 1,
//                                zIndex: 100000,
//                                flag_gps: p_place.flag_gps
//                            }));
//                        }
//                        break;
//                    case 'Polygon':
//                        //Poligoni
//                        colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

//                        k_livelli.poligoni.push(new google.maps.Polygon({
//                            html: p_place.id,
//                            vegcod: p_place.veg_cod,
//                            inserimento: p_place.inserimento,
//                            Entita_Cod: p_place.Entita_Cod,
//                            modifica: p_place.modifica,
//                            cancellazione: p_place.cancellazione,
//                            informazioni: p_place.informazioni,
//                            chiavealbero: p_place.chiavealbero,
//                            AppIdRate: p_place.AppIdRate,
//                            testo: p_place.Testo,
//                            paths: polygonPaths,
//                            strokeColor: colore_poligon,
//                            fillOpacity: 0.6,
//                            strokeWeight: 1,
//                            fillColor: colore_poligon,
//                            selectedColor: '#7d7d7d',
//                            colore_precedente: colore_poligon,
//                            zIndex: p_place.zindex,
//                            flag_gps: p_place.flag_gps
//                        }));
//                        break;
//                    case 'MultiSurface':
//                        //Poligoni
//                        colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

//                        k_livelli.poligoni.push(new google.maps.Polygon({
//                            html: p_place.id,
//                            vegcod: p_place.veg_cod,
//                            inserimento: p_place.inserimento,
//                            Entita_Cod: p_place.Entita_Cod,
//                            modifica: p_place.modifica,
//                            cancellazione: p_place.cancellazione,
//                            informazioni: p_place.informazioni,
//                            chiavealbero: p_place.chiavealbero,
//                            AppIdRate: p_place.AppIdRate,
//                            testo: p_place.Testo,
//                            paths: polygonPaths,
//                            strokeColor: colore_poligon,
//                            fillOpacity: 0.6,
//                            strokeWeight: 1,
//                            fillColor: colore_poligon,
//                            selectedColor: '#7d7d7d',
//                            colore_precedente: colore_poligon,
//                            zIndex: p_place.zindex,
//                            flag_gps: p_place.flag_gps
//                        }));
//                        break;
//                    default:
//                        alert(p_place.TipologiaGML);
//                }

//                if (p_place.flag_gps == '1') {
//                    //calcolo il baricentro del poligono
//                    //aggiungo l'icona
//                    var myLatlng = new google.maps.LatLng(lat_centro, lng_centro);

//                    if ($('#chk_mostra_GPS').is(':checked') == true) {
//                        MarkGps.push(new google.maps.Marker({
//                            position: myLatlng,
//                            map: map,
//                            icon: variabile_gps
//                        }));
//                    }
//                }
//                kk = l_livelli;
//            } //for kk
//        } //for i
//    }


//    for (var i = 0; i < l_livelli; i++) {
//        if (riCreaPannelloColore == false) {
//            if (Livelli[i].id == '50')
//                ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
//        }
//        else {
//            ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
//            ImpostaMappa(Livelli[i].punti, true, true, 'point'); //vanni, 17/04/2013 per selezione markers
//            ImpostaMappa(Livelli[i].polyline, false, false, 'poly');
//            ImpostaMappa(Livelli[i].ABLabel, false, false, 'poly');
//        }
//    }

//    if (riCreaPannelloColore)
//        map.setCenter(latlngAutoFit.getCenter(), map.fitBounds(latlngAutoFit));

//    $('#WaitFrame').hide();

//}




//function ImpostaShape(riCreaPannelloColore) {

//    var l_place = place.length;
//    var l_livelli = Livelli.length;

//    //Identifico i Min e Max
//    if (riCreaPannelloColore == true) {
//        for (var i = 0; i < l_place; i++) {
//            for (var kk = 0; kk < l_livelli; kk++) {
//                if (Livelli[kk].id == place[i].layer) {
//                    if (Livelli[kk].datiViste != undefined) {
//                        SettaMaxMin(place[i].AppIdRate, Livelli[kk].datiViste);
//                    }
//                }
//            }
//        } //next i
//    }
//    else {
//        for (var i = 0; i < l_place; i++) {
//            for (var kk = 0; kk < l_livelli; kk++) {
//                if (Livelli[kk].id == place[i].layer) {
//                    if (Livelli[kk].datiViste != undefined) {
//                        var l_livelli_poligoni = Livelli[kk].poligoni.length;
//                        for (var z = 0; z < l_livelli_poligoni; z++) {
//                            Livelli[kk].poligoni[z].setMap(null);
//                        }
//                        Livelli[kk].poligoni = new Array();
//                    }
//                }
//            }
//        }
//    } //next i

//    kk = 0;

//    if (riCreaPannelloColore == true) {
//        PopolaComboPannelloColore(xCreazioneCombo, xComboCorrenti);

//        for (var j = 0; j < l_livelli; j++) {
//            CreaPannelloColore('abc', Livelli[j].datiViste);
//        }
//    }
//    //trovo i limiti estremi della mappa
//    var latlngAutoFit = new google.maps.LatLngBounds();

// 
//    for (var i = 0; i < l_place; i++) {
//        var polygonPaths = [];

//        var lat_centro = 0;
//        var lng_centro = 0;

//        var p_place = place[i];

//        var l_place_vertici = p_place.vertici.length;
//        for (var j = 0; j < l_place_vertici; j++) {
//            polygonPaths.push(new google.maps.LatLng(p_place.vertici[j].lat, p_place.vertici[j].long));
//            lat_centro += parseFloat(p_place.vertici[j].lat);
//            lng_centro += parseFloat(p_place.vertici[j].long);
//            latlngAutoFit.extend(new google.maps.LatLng(p_place.vertici[j].lat, p_place.vertici[j].long));
//        }

//        lat_centro = lat_centro / j;
//        lng_centro = lng_centro / j;


//        for (var kk = 0; kk < l_livelli; kk++) {
//            var k_livelli = Livelli[kk];
//            if (k_livelli.id == place[i].layer) {

//                var colore_poligon;
//                var selectedColor = '#222222';

//                var v_min = 0.0;
//                var v_max = 0.0;
//                var colore_1 = "";
//                var colore_2 = "";
//                var varianza = "";

//                if (k_livelli.datiViste != undefined) {
//                    var curAppIdRate = GETvaloreAppIdRateDaStringa(place[i].AppIdRate, $("#cmbViste option:selected").text());
//                    colore_poligon = leggiColoreDaDiv($("#cmbViste option:selected").text(), curAppIdRate);
//                }
//                else {
//                    if (k_livelli.v_min === "undefined") {
//                        $("#scala_colori_contenitore").hide();
//                    }
//                    v_min = k_livelli.v_min;
//                    v_max = k_livelli.v_max;
//                    colore_1 = k_livelli.colore_1;
//                    colore_2 = k_livelli.colore_2;
//                    variaza = k_livelli.varianza;
//                    colore_poligon = calcolaColore(v_min, v_max, curAppIdRate, colore_1, colore_2, varianza);
//                }


//                switch (p_place.TipologiaGML) {
//                    case 'Point':
//                        var punto;

//                        if (p_place.tipoicona == "Trattore") {

//                            punto = new google.maps.Marker({
//                                html: p_place.id,
//                                position: polygonPaths[0],
//                                draggable: false,
//                                icon: trattore
//                            });
//                        }
//                        else {

//                            var isDraggable;
//                            isDraggable = !(p_place.layer == 55)

//                            punto = new google.maps.Marker({
//                                html: p_place.id,
//                                position: polygonPaths[0],
//                                draggable: isDraggable,
//                                icon: k_livelli.icona16,
//                                chiavealbero: p_place.chiavealbero
//                            });
//                        }



//                        var lbl;
//                        lbl = new Label({ text: p_place.Testo, html: p_place.id });
//                        lbl.bindTo('position', punto, 'position');

//                        k_livelli.punti.push(punto);
//                        k_livelli.ABLabel.push(lbl);
//                        break;
//                    case 'LineString':
//                        if (p_place.vertici.length == 2) {
//                            k_livelli.polyline.push(new google.maps.Polyline({
//                                html: p_place.id,
//                                path: polygonPaths,
//                                zIndex: 100000,
//                                flag_gps: p_place.flag_gps
//                            }));
//                        }
//                        else {
//                            //Linestring
//                            k_livelli.polyline.push(new google.maps.Polyline({
//                                html: p_place.id,
//                                path: polygonPaths,
//                                strokeColor: '#' + colore_poligon,
//                                fillOpacity: 1.0,
//                                strokeWeight: 1,
//                                zIndex: 100000,
//                                flag_gps: p_place.flag_gps
//                            }));
//                        }
//                        break;
//                    case 'Polygon':
//                        //Poligoni
//                        colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

//                        k_livelli.poligoni.push(new google.maps.Polygon({
//                            html: p_place.id,
//                            vegcod: p_place.veg_cod,
//                            inserimento: p_place.inserimento,
//                            Entita_Cod: p_place.Entita_Cod,
//                            modifica: p_place.modifica,
//                            cancellazione: p_place.cancellazione,
//                            informazioni: p_place.informazioni,
//                            chiavealbero: p_place.chiavealbero,
//                            AppIdRate: p_place.AppIdRate,
//                            testo: p_place.Testo,
//                            paths: polygonPaths,
//                            strokeColor: colore_poligon,
//                            fillOpacity: 0.6,
//                            strokeWeight: 1,
//                            fillColor: colore_poligon,
//                            selectedColor: '#7d7d7d',
//                            colore_precedente: colore_poligon,
//                            zIndex: p_place.zindex,
//                            flag_gps: p_place.flag_gps
//                        }));
//                        break;
//                    case 'MultiSurface':
//                        //Poligoni
//                        colore_poligon = aggiungiCancellettoSeNonEsiste(colore_poligon);

//                        k_livelli.poligoni.push(new google.maps.Polygon({
//                            html: p_place.id,
//                            vegcod: p_place.veg_cod,
//                            inserimento: p_place.inserimento,
//                            Entita_Cod: p_place.Entita_Cod,
//                            modifica: p_place.modifica,
//                            cancellazione: p_place.cancellazione,
//                            informazioni: p_place.informazioni,
//                            chiavealbero: p_place.chiavealbero,
//                            AppIdRate: p_place.AppIdRate,
//                            testo: p_place.Testo,
//                            paths: polygonPaths,
//                            strokeColor: colore_poligon,
//                            fillOpacity: 0.6,
//                            strokeWeight: 1,
//                            fillColor: colore_poligon,
//                            selectedColor: '#7d7d7d',
//                            colore_precedente: colore_poligon,
//                            zIndex: p_place.zindex,
//                            flag_gps: p_place.flag_gps
//                        }));
//                        break;
//                    default:
//                        alert(p_place.TipologiaGML);
//                }

//                if (p_place.flag_gps == '1') {
//                    //calcolo il baricentro del poligono
//                    //aggiungo l'icona
//                    var myLatlng = new google.maps.LatLng(lat_centro, lng_centro);

//                    if ($('#chk_mostra_GPS').is(':checked') == true) {
//                        MarkGps.push(new google.maps.Marker({
//                            position: myLatlng,
//                            map: map,
//                            icon: variabile_gps
//                        }));
//                    }
//                }
//                kk = l_livelli;
//            } //for kk
//        } //for i
//    }


//    for (var i = 0; i < l_livelli; i++) {
//        if (riCreaPannelloColore == false) {
//            if (Livelli[i].id == '50')
//                ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
//        }
//        else {
//            ImpostaMappa(Livelli[i].poligoni, true, false, 'poly');
//            ImpostaMappa(Livelli[i].punti, true, true, 'point'); //vanni, 17/04/2013 per selezione markers
//            ImpostaMappa(Livelli[i].polyline, false, false, 'poly');
//            ImpostaMappa(Livelli[i].ABLabel, false, false, 'poly');
//        }
//    }

//    if (riCreaPannelloColore)
//        map.setCenter(latlngAutoFit.getCenter(), map.fitBounds(latlngAutoFit));

//    $('#WaitFrame').hide();

//}


function aggiungiCancellettoSeNonEsiste(colore) {
    if (!startsWith(colore, "#"))
        colore = "#" + colore;
    return colore
}

function ImpostaMappa(dati, setClick, setdblClick, functSelect) {

    for (var kk = 0; kk < dati.length; kk++) {

        if (setClick) {

            google.maps.event.addListener(dati[kk], 'mouseup', function () {
                if (functSelect != 'poly') {
                    setSelectionPointMouseUp(this);
                }
            });
            google.maps.event.addListener(dati[kk], 'click', function () {
                if (functSelect == 'poly') {
                    if (ctrlPressed)
                        setMultiSelection(this);
                    else
                        setSelection(this);
                }
                else
                    setSelectionPoint(this);
            });
        }

        dati[kk].setMap(map);
    }

}




/********************************************************************/
/********************** Tool Selezione e Creazione  *****************/
/*******************************************************************/
/* Attiva Disattiva label */
function CreaPoligono() {

    if ($("#hiddenMultipoint").val() != "") {
        dialogMultipoint();
    }
    else {
        if (glayerDoveDisegno == "-1" && isLayerVisualizzato("19")) {
            settaLayerDoveDisegnare("19", "../AB_Immagini/icone/Impianto32.png", "IMPIANTI");
        }
        drawingManager.setDrawingMode(cosaStoDisegnando);
    }
}


function SelezionaPoligono() {
    drawingManager.setDrawingMode(null);
}



/********************************************************************/
/********************** LABEL **************************************/
/*******************************************************************/

function catasto() {


    var ritorno;

    var indirizzohttpCatasto = '';
    indirizzohttpCatasto = 'RipartoCatasto.aspx?entita=' + selectedShape.Entita_Cod;


    //$.logThis(indirizzohttp);

    $("#frameCatasto").attr("src", indirizzohttpCatasto);
    $("#pop_up_Catasto").dialog("open");

}

function copiaIncollaLogThis(ChiaveAlbero) {
    //log    
    $.logThis("copia/incolla chiave albero = " + ChiaveAlbero);


    if (selectedShape_Copia == undefined) {
        $.logThis("copia/incolla selected shape copiato = undefined ");
    }
    else {
        $.logThis("copia/incolla selected shape copiato = " + selectedShape_Copia.getPath().getArray().toString());
    }

    if (selectedShape == undefined) {
        $.logThis("copia/incolla selected shape attuale = undefined ");
    }
    else {
        $.logThis("copia/incolla selected shape attuale = " + selectedShape.getPath().getArray().toString());
    }
    //fine log
}

function copiaIncolla() {

    //gestione dei potenziali errori

    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString(); //.replace(/\\/g, '\\\\'); ;

    if (ChiaveAlbero == '') {

        //log
        copiaIncollaLogThis(ChiaveAlbero);
        alert("Nessun elemento selezionato.");
        return 1;
    }

    if (selectedShape_Copia == undefined) {
        if (ChiaveAlbero != '' && selectedShape == undefined) {

            //log
            copiaIncollaLogThis(ChiaveAlbero);
            alert("Nessun disegno per l'elemento selezionato.");
            return 1;
        }
    }

    //fine gestione potenziali errori


    if (selectedShape_Copia == undefined) {

        //copia
        selectedShape_Copia = selectedShape;
        alert("Selezionare un elemento dall'albero di sinistra e fare di nuovo click sul pulsante per incollare.");
    }
    else {

        //incolla

        if (selectedShape == undefined) {
            selectedShape = selectedShape_Copia;

            var MVCArray = selectedShape.getPath();
            $('#hiddenPunti_Nuovo').val(MVCArray.getArray().toString());

            var area = getArea();

            $('#WaitFrame').show();
            salvataggioDirettoConAppezza(area);
            selectedShape_Copia = undefined;
            selectedShape = undefined;

            //LOG
            copiaIncollaLogThis(ChiaveAlbero);

        }
        else {
            //log
            copiaIncollaLogThis(ChiaveAlbero);
            alert("Esiste già un elemento grafico e quindi non è possibile incollare.");
        }


        //log
        copiaIncollaLogThis(ChiaveAlbero);
    }

}

function editPunti() {


    //gestione dei potenziali errori

    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString(); //.replace(/\\/g, '\\\\'); ;
    if (ChiaveAlbero == '' && CoordFromPoints != '') {
        alert("Nessun elemento selezionato.");
        return 1;
    }


    if (ChiaveAlbero != '' && CoordFromPoints == '' && selectedShape == undefined) {
        alert("Nessun disegno per l'elemento selezionato.");
        return 1;
    }

    if (CoordFromPoints != '' && selectedShape != undefined) {
        alert("Esiste già un disegno per l'elemento selezionato.");
        return 1;
    }
    //fine gestione dei potenziali errori


    if (ChiaveAlbero == '' && CoordFromPoints == '') {
        $('#dialogEliminaImpiantoPuntiScomposti').dialog("open");
        return 1;
    }

    if (CoordFromPoints != '') {
        CoordFromPoints = CoordFromPoints.substring(0, CoordFromPoints.length - 2);

        // (lat,long),(lat,long),(lat,long) --> length = 6
        var ll = CoordFromPoints.split(",").length;
        $.logThis("--> length =" + ll);

        if (ll < 5) {
            alert("Selezionare almeno 3 vertici.");
            return 1;
        }

        $('#hiddenPunti_Nuovo').val(CoordFromPoints);
        $('#dialogAllertOperazioni_hidden').val("1");
        $('#dialogConfermaAssociazione').dialog("open");
        return 1;
    }




    $('#WaitFrame').show();




    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ScomponiPoligono",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "', entita_cod: '" + selectedShape.Entita_Cod + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d == "ok") {
                    $('#WaitFrame').hide();
                    AggiornaTutto();
                    $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val("");
                }
                else
                    alert("Si è verificato un problema durante la scomposizione. - " + msg.d);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}



function Info_Poligono() {
    if (infowindow != null) infowindow.close();

    infowindow = new google.maps.InfoWindow();

    //    //selectedShape.testo
    //    infowindow.setContent(selectedShape.vegcod + " - " + selectedShape.Entita_Cod);
    //    //infowindow.setContent(selectedShape.Entita_Cod);
    //    infowindow.setContent(selectedShape.html);

    var veg_cod = "";
    var sEntita_Cod = "";

    var lat;
    var lng;

    var hMpM = $("#hiddenMultipointModifica").val();
    var selectedShape_testo = "";

    if (hMpM != '') {
        sEntita_Cod = hMpM;
        var app = hMpM.split("§")[0].split("^")[1].split(",");

        lat = app[0].replace("(", "");
        lng = app[1].replace(")", "").replace(" ", "");

    } else {
        sEntita_Cod = selectedShape.Entita_Cod

        var MVCArray = selectedShape.getPath();
        var mArray = MVCArray.getArray();

        lat = mArray[0].lat();
        lng = mArray[0].lng();
        selectedShape_testo = selectedShape.testo;
    }


    $.logThis("infowindow = " + lat + " - " + lng);

    getProprieta(veg_cod, sEntita_Cod, selectedShape_testo, 2);


    infowindow.setPosition(new google.maps.LatLng(lat, lng));
    infowindow.open(map);
}


/*******************************************************************/
/******************* PANNELLO DI SALVATAGGIO ***********************/
/*******************************************************************/

function AggiungiOptionInSelect(selectName, OptionValue, OptionText) {
    if (!EsisteOptionInSelect(selectName, OptionValue))
        $(selectName).append(new Option(OptionText, OptionValue, false, true));
}

function EsisteOptionInSelect(selectName, OptionValue) {
    return ($(selectName + "[value='" + OptionValue + "']").length > 0);
}

function DammiOptionValueInSelect(selectName) {
    return $(selectName).find(":selected").val();
}

function DammiOptionTextInSelect(selectName) {
    return $(selectName).find(":selected").text();
}

function ImpostaOptionInSelect(selectName, OptionValue) {
    $(selectName).val(OptionValue);
}

/******************* NUOVA CENTRO ************************/
/* funzione per la creazione di un nuovo centro  */
function InviaDatiNuovoCentro() {
    var MVCArray = selectedShape.getPath();
    var coord = {
        "sLat": 0,
        "sLong": 0
    };

    getGLatLong(MVCArray, coord);


    var oggetto = {
        "piva": $('#pop_up_impianto_azienda').val(),
        "ragione_sociale": $('#txt_sa_nome').val(),
        "sLat": coord.sLat,
        "sLong": coord.sLong,
        "provincia": $('#ddl_Provincia_' + centro_ID_ind).val(),
        "comune": $('#ddl_Comune_' + centro_ID_ind).val(),
        "via": $('#txt_Via_' + centro_ID_ind).val(),
        "frazione": $('#txt_Frazione_' + centro_ID_ind).val(),
        "civico": $('#pop_up_finalita').val(),
        "stato": $('#txt_Stato_' + centro_ID_ind).val(),
        "note": $('#txt_Note_' + centro_ID_ind).val()
    };


    //se sono tutte valorizzate allora posso procedere
    var blocca = false;

    if (oggetto.piva == "" || oggetto.ragione_sociale == "") {
        blocca = true;
    }


    if (blocca) {
        alert("completare i campi obbligatori");
        return false;
    }

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/btn_SalvaNuoovoCentroAziendale_Click",
        data: "{ piva: '" + oggetto.piva + "', ragione_sociale: '" + oggetto.ragione_sociale + "', sLat: '" + oggetto.sLat + "', sLong: '" + oggetto.sLong + "', provincia: '" + oggetto.provincia + "', comune: '" + oggetto.comune + "', via: '" + oggetto.via + "', frazione: '" + oggetto.frazione + "', civico: '" + oggetto.civico + "', stato: '" + oggetto.stato + "', note: '" + oggetto.note + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {


            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                var sa_cod = msg.d;
                sa_cod = sa_cod.split('=')[1];

                $('#popup_nuovo_centro').dialog("close");

                var descriz = "";
                descriz = oggetto.ragione_sociale;

                if (isSementi)
                    descriz = descriz + " (Lat.: " + oggetto.sLat + " - Long.: " + oggetto.sLong + ")";

                AggiungiOptionInSelect('#pop_up_centro', sa_cod, descriz + '|' + oggetto.via + ' ' + oggetto.civico + ' ' + oggetto.comune);
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

/******************* NUOVA AZIENDA ************************/

/* default */
function popup_nuova_azienda_open() {
    ImpostaAziendaPadreDefault();
}

function ImpostaAziendaPadreDefault() {
    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ImpostaAziendaPadreDefault",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d.toString() != '') {
                    var AziendaPadre = msg.d.split('|');
                    AggiungiOptionInSelect("#Cmb_Imprese_Padre", AziendaPadre[0], AziendaPadre[1]);
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

/* funzione per la creazione di una nuova azienda  */
function InviaDatiNuovaAzienda() {
    var MVCArray = selectedShape.getPath();
    var coord = {
        "sLat": 0,
        "sLong": 0
    };

    getGLatLong(MVCArray, coord);


    var oggetto = {
        "piva": $('#txt_Piva').val(),
        "piva_padre": $('#Cmb_Imprese_Padre').val(),
        "sLat": coord.sLat,
        "sLong": coord.sLong,
        "ragione_sociale": $('#txt_rag_Soc').val(),
        "provincia": $('#ddl_Provincia_' + imprese_ID_ind).val(),
        "comune": $('#ddl_Comune_' + imprese_ID_ind).val(),
        "via": $('#txt_Via_' + imprese_ID_ind).val(),
        "frazione": $('#txt_Frazione_' + imprese_ID_ind).val(),
        "civico": $('#pop_up_finalita').val(),
        "stato": $('#txt_Stato_' + imprese_ID_ind).val(),
        "note": $('#txt_Note_' + imprese_ID_ind).val()
    };


    //se sono tutte valorizzate allora posso procedere
    var blocca = false;

    if (oggetto.piva == "" || oggetto.ragione_sociale == "") {
        blocca = true;
    }

    if (blocca) {
        alert("completare i campi obbligatori");
        return false;
    }

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/btn_Salva_Azienda_Click",
        data: "{ piva: '" + oggetto.piva + "', piva_padre: '" + oggetto.piva_padre + "', ragione_sociale: '" + oggetto.ragione_sociale + "', sLat: '" + oggetto.sLat + "', sLong: '" + oggetto.sLong + "', provincia: '" + oggetto.provincia + "', comune: '" + oggetto.comune + "', via: '" + oggetto.via + "', frazione: '" + oggetto.frazione + "', civico: '" + oggetto.civico + "', stato: '" + oggetto.stato + "', note: '" + oggetto.note + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#WaitFrame').hide();
            $('#popup_nuova_azienda').dialog("close");

            AggiungiOptionInSelect('#pop_up_impianto_azienda', oggetto.piva, oggetto.ragione_sociale);
            CaricaCentroAziendale();

        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);

        }
    });


}


function ImpostaPulsantiNuovoImpianto() {
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ImpostaPulsantiNuovoImpianto",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d != "True")
                    $('#righelloSpecie').html("");
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function CaricaDateDefaultDaVegCod(dataInizio, dataFine) {
    var veg_cod = $('#pop_up_specie').val();
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaDateDefaultDaVegCod",
        data: "{Veg_Cod :'" + veg_cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d == '-1') { }
                else {

                    var DataInizioFine = msg.d.split('|');

                    $(dataInizio).val(DataInizioFine[0]);
                    $(dataFine).val(DataInizioFine[1]);
                    if ($(dataFine).val() == "") {
                        $(dataFine).removeAttr("disabled");
                    }
                }
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function CaricaDateDefault(dataInizio, dataFine) {
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaDateDefault",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d == '-1') { }
                else {

                    var DataInizioFine = msg.d.split('|');

                    $(dataInizio).val(DataInizioFine[0]);
                    $(dataFine).val(DataInizioFine[1]);
                    if ($(dataFine).val() == "") {
                        $(dataFine).removeAttr("disabled");
                    }
                }
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

/******************* Carica AZIENDA ********************************/
/* funzione per il caricamento tramite ajax delle aziende */
function CaricaAzienda() {
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaAzienda",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#pop_up_impianto_azienda').html(msg.d);
                CaricaCentroAziendale();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

/********************* INDIRIZZI ***********************************/
/* nascondi marlker Indirizzo */
function nascondiAddress() {
    markerIndirizzo.setMap(null);
    markerIndirizzo = null;
}


function ricercaCoordinate() {
    if (markerIndirizzo != null) {
        nascondiAddress();
    }
    var lat = $('#lat_cerca').val().replace(",", ".");
    var long = $('#long_cerca').val().replace(",", ".");

    var ok = true;
    if (parseFloat(lat) == null)
        ok = false;

    if (parseFloat(long) == null)
        ok = false;

    if (ok == true) {
        map.setZoom(15)
        markerIndirizzo = new google.maps.Marker({
            map: map,
            position: new google.maps.LatLng(lat, long)
        });
        map.setCenter(new google.maps.LatLng(lat, long));
    } else {
        alert('i campi Lat e Long non contengono valori corretti');
    }
}

/* Ricerca x Indirizzo */
function ricercaIndirizzo() {
    if (markerIndirizzo != null) {
        nascondiAddress();
    }
    var address = document.getElementById("address").value;

    map.setZoom(zoomRicercaIndirizzo);
    geocoder.geocode({
        'address': address
    }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            map.setCenter(results[0].geometry.location);
            markerIndirizzo = new google.maps.Marker({
                map: map,
                position: results[0].geometry.location
            });
        } else {
            alert("Geocode was not successful for the following reason: " + status);
        }
    });
}

function getGLatLong(MVCArray, coord) {
    var mArray = MVCArray.getArray();
    var conta = 0;
    var len = mArray.length;
    for (conta = 0; conta < len; conta++) {
        coord.sLat = coord.sLat + mArray[conta].lat();
        coord.sLong = coord.sLong + mArray[conta].lng();
    }
    coord.sLat = coord.sLat / len;
    coord.sLong = coord.sLong / len;

}



function objToString(obj) {
    var str = '';
    for (var p in obj) {
        if (obj.hasOwnProperty(p)) {
            str += p + '::' + obj[p] + '\n';
        }
    }
    return str;
}


/* trova tutti i possibili indirizzi di un poligono */
function identificaIndirizzi(MVCArray) {

    var __lat = 0;
    var __long = 0;
    var i = 0;
    var mArray = MVCArray.getArray();
    var conta = 0;
    var len = mArray.length;
    for (conta = 0; conta < len; conta++) {
        __lat = __lat + mArray[conta].lat();
        __long = __long + mArray[conta].lng();
    }
    __lat = __lat / len;
    __long = __long / len;

    $('#stringaIndirizzo').val("");

    var latlng = new google.maps.LatLng(__lat, __long);
    geocoder.geocode({
        'latLng': latlng
    }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            var indirizzo = results[0].formatted_address;

            var stringona = "<br><br>";

            var via = "";
            var n_civico = 0;
            var citta = "";
            var localita = "";
            var provincia = "";
            var sigla = "";
            var cap = "";
            var stato = "";

            for (var i = 0; i < results[0].address_components.length; i++) {
                var shortname = results[0].address_components[i].short_name;
                var longname = results[0].address_components[i].long_name;
                var type = results[0].address_components[i].types;
                switch (type.toString()) {
                    case 'street_number':
                        n_civico = shortname;
                        break;
                    case 'route':
                        via = shortname;
                        break;
                    case 'sublocality,political':
                        localita = shortname;
                        break;
                    case 'locality,political':
                        citta = shortname;
                        break;
                    case 'administrative_area_level_2,political':
                        provincia = longname;
                        sigla = shortname;
                        break;
                    case 'administrative_area_level_3,political':
                        citta = longname;
                        break;

                    case 'postal_code':
                        cap = shortname;
                        break;
                    case 'country,political':
                        stato = longname + ", " + shortname;

                }
                //stringona = stringona + "t:" + type + "  sh:" + shortname + " lo:" + longname + "<br>";
            }

            //stringona = stringona +"<br><br>";

            if (localita == "")
                localita = citta;

            impostaValoriIndirizzo(via, n_civico, localita, citta, provincia, sigla, stato);

            $('#stringaIndirizzo').val(indirizzo);
            //            $('#stringaIndirizzo').html(indirizzo);
        }
    });
}




/******************* Carica CentroAziendale ************************/
/* funzione per il caricamento tramite ajax dei centri aziendali salvati su l'azienda selezionata */
function CaricaCentroAziendale() {
    var azienda_selezionata = $('#pop_up_impianto_azienda').val();
    if (azienda_selezionata != "") {
        $.ajax({
            type: "POST",
            url: indirizzohttp + "/CaricaCentroAziendale",
            data: "{Piva: '" + azienda_selezionata + "', isSementi: '" + isSementi.toString() + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {

                if (msg.d == 'SessioneScaduta') {
                    $('#dialogSessioneScaduta').dialog("open");
                }
                else {
                    $('#pop_up_centro').html(msg.d);

                    if ($(".ddl_Sa_Cod_sx").length > 0) {

                        $('#pop_up_centro').val($('.ddl_Aziende').val() + "|" + $('.ddl_Sa_Cod_sx').val());
                    }
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
    }
}

/******************* Carica Specie ************************/
/* funzione per il caricamento tramite ajax delle specie  */
function CaricaSpecie(combo_specie, veg_cod) {
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaSpecie",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $(combo_specie).html(msg.d);
                if (veg_cod != '') {
                    $(combo_specie).val(veg_cod)
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

/******************* Carica Tipologia ************************/
/* funzione per il caricamento tramite ajax delle specie  */
function CaricaTipologia(Veg_Cod, combo_tipologia, valoreSelezionato) {
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaTipologia",
        data: "{ Veg_Cod: '" + Veg_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {
            r_ok();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $(combo_tipologia).html(msg.d);
            }
            if (valoreSelezionato != "")
                $(combo_tipologia).val(valoreSelezionato);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

/******************* Carica Varieta ************************/
/* funzione per il caricamento tramite ajax delle specie  */
function CaricaVarieta(combo_varieta, cul_cod) {
    var Veg_Cod;

    if (combo_varieta == '#pop_up_varieta') {
        Veg_Cod = $('#pop_up_specie').val();
    } else {
        //        pop_up_varieta_modifica
        Veg_Cod = $('#pop_up_specie_modifica').val();
    }

    $.logThis("Veg_CodVerieta :" + Veg_Cod);

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaVarieta",
        data: "{ Veg_Cod: '" + Veg_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {
            r_ok();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $(combo_varieta).html(msg.d);
                if (cul_cod != '') {
                    $(combo_varieta).val(cul_cod)
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function r_ok() {
    response_ok = response_ok - 1;
    if (response_ok == 0) {
        $('#WaitFrame').hide();
    }
}

/******************* Carica Disciplinare ************************/
/* funzione per il caricamento tramite ajax delle specie  */
function CaricaDisciplinare() {
    var Veg_Cod = $('#pop_up_specie').val();
    $('#WaitFrame').show();
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaDisciplinare",
        data: "{ Veg_Cod: '" + Veg_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {
            r_ok();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#pop_up_disciplinare').html(msg.d);

            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

/******************* Carica Finalita ************************/
/* funzione per il caricamento tramite ajax delle specie  */
function CaricaFinalita(combo_finalita, finalita) {
    if (combo_finalita == '#pop_up_finalita') {
        var Veg_Cod = $('#pop_up_specie').val();
    } else {
        //        pop_up_varieta_modifica
        var Veg_Cod = $('#pop_up_specie_modifica').val();
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CaricaFinalita",
        data: "{ Veg_Cod: '" + Veg_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {
            r_ok();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $(combo_finalita).html(msg.d);
                if (finalita != '') {
                    $(combo_finalita).val(finalita)
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


/******************* NUOVO IMPIANTO ************************/

/* verifica della correttezza di un poligono */
function VerificaPoligono(Poligono, EliminaPoligono) {
    $('#WaitFrame').show();
    var bTestPoligono = false;
    $.ajax({
        async: false,
        type: "POST",
        url: indirizzohttp + "/VerificaPoligono",
        data: "{ Poligono: '" + Poligono + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (msg) {

            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d != 'Ok') {
                    if (EliminaPoligono) {
                        if (selectedShape != undefined)
                            selectedShape.setMap(null);
                    }
                }
                else {
                    bTestPoligono = true;
                }

            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

    return bTestPoligono;
}

/* funzione per la creazione di un nuvo impianto  */
function InviaDatiNuovoImpianto() {
    $('#WaitFrame').show();
    var hiddenPunti_Nuovo = $('#hiddenPunti_Nuovo').val();
    var oggetto = {
        "piva": $('#pop_up_impianto_azienda').val(),
        "rag_soc": $('#pop_up_impianto_azienda').find(":selected").text(),
        "sa_cod": $('#pop_up_centro').val(),
        "veg_cod": $('#pop_up_specie').val(),
        "sup_imp": $('#pop_up_sup_app').val(),
        "data_inizio": $('#pop_up_data_inizio').val(),
        "data_fine": $('#pop_up_data_fine').val(),
        "varieta": $('#pop_up_varieta').val(),
        "finalita": $('#pop_up_finalita').val(),
        "disciplinare": $('#pop_up_disciplinare').val(),
        "tipologia": $('#pop_up_tipologia').val(),
        "nome": $('#pop_up_nome').val(),
        "lotto": $('#pop_up_lotto').val(),
        "data_semina": $('#pop_up_d_semina').val(),
        "data_raccolta": $('#pop_up_d_raccolta').val(),
        "via_stringa": $('#stringaIndirizzo').val(),
        "hiddenPunti_Nuovo": hiddenPunti_Nuovo
    };

    if (oggetto.finalita == null) {
        oggetto.finalita = "";
    }
    if (oggetto.disciplinare == null) {
        oggetto.disciplinare = "";
    }
    if (oggetto.tipologia == null) {
        oggetto.tipologia = "";
    }


    //se sono tutte valorizzate allora posso procedere
    var blocca = false;



    if (glayerDoveDisegno != "19") {

        if (oggetto.piva == "" || oggetto.sa_cod == "") {
            blocca = true;
        }

    } else {


        if (oggetto.piva == "" || oggetto.sa_cod == "" || oggetto.veg_cod == "" || oggetto.sup_imp == "") {
            blocca = true;
        }

        if (isSementi == true && (oggetto.data_inizio == "" || oggetto.data_fine == "" || oggetto.tipologia == "")) {
            blocca = true;
        }

        // controllo che nono siano nulle
        if (oggetto.piva == null || oggetto.sa_cod == null || oggetto.veg_cod == null || oggetto.sup_imp == null) {
            alert("completare i null");
            return false;
        }

    }

    if (blocca) {
        alert("completare i campi obbligatori");
        $('#WaitFrame').hide();
        return false;
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaNuovoImpianto",
        data: "{ piva: '" + oggetto.piva + "', sa_cod: '" + oggetto.sa_cod + "', veg_cod: '" + oggetto.veg_cod + "', sup_imp: '" + oggetto.sup_imp + "', piva: '" + oggetto.piva + "', data_inizio: '" + oggetto.data_inizio + "', data_fine: '" + oggetto.data_fine + "', varieta: '" + oggetto.varieta + "', finalita: '" + oggetto.finalita + "', disciplinare: '" + oggetto.disciplinare + "', tipologia: '" + oggetto.tipologia + "', nome: '" + oggetto.nome + "', lotto: '" + oggetto.lotto + "', data_semina: '" + oggetto.data_semina + "', data_raccolta: '" + oggetto.data_raccolta + "', via_stringa: '" + oggetto.via_stringa.replace("'", "`") + "', hiddenPunti_Nuovo: '" + oggetto.hiddenPunti_Nuovo + "', layer_cod: '" + glayerDoveDisegno + "', elementografico_des: '" + $("#txtElementoGrafico_Des").val() + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#responseInterferenze').width('0px');
            $('#responseInterferenze').html('');
            $("#pop_up_impianto").dialog("close");

            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $.logThis('SalvaNuovoImpianto, esito = ' + msg.d);

                //'  Vanni, 05/06/2014 09:42:52: verifico se e come ricaricare...
                //RicaricaAziende(oggetto.piva, oggetto.rag_soc);

                var app = msg.d.split(".");
                if (app.length > 1) {
                    RicaricaSituazioneMappa(app[1], "", oggetto);
                }



            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function RicaricaSituazioneMappa(id, chiavealbero, oggetto) {
    var ricaricaNecessario = !contains(layerNonAlbero, glayerDoveDisegno);

    if (ricaricaNecessario) {

        $.logThis("Ricarica necessario");

        if (selectedShape != undefined)
            selectedShape.setMap(null);
        RicaricaAziende(oggetto.piva, oggetto.rag_soc);
    }
    else {
        $.logThis("Ricarica non necessario");
        GestisciShapeAppenaCreatoClient(id, chiavealbero);
    }
}



function GestisciShapeAppenaCreatoClient(id, chiavealbero) {

    var ids = id.split(",");

    $.logThis("GestisciShapeAppenaCreatoClient()");
    $.logThis(selectedShape);

    var col = "000000"

    for (var i = 0; i < ids.length; i++) {

        var lat_centro = 0;
        var lng_centro = 0;

        var p_place = place[i];

        var l_place_vertici = p_place.vertici.length;
        for (var j = 0; j < l_place_vertici; j++) {
            var l_at = p_place.vertici[j].lat;
            var l_ong = p_place.vertici[j].long;
            lat_centro += parseFloat(l_at);
            lng_centro += parseFloat(l_ong);
        }

        lat_centro = lat_centro / j;
        lng_centro = lng_centro / j;

        pushNewPlace(ids[i], chiavealbero);
        ShapeAggiungiOggetti(place[place.length - 1], placeLivelli[glayerDoveDisegno], col, selectedShape.getPath(), lat_centro, lng_centro);
        selectedShape.set('fillColor', "#" + col);
        selectedShape.setMap(map);
        setSelection(selectedShape);
    }



}

function pushNewPlace(id, chiavealbero) {

    $.logThis("pushNewPlace();");

    var entita_cod = id.split("|")[1];

    place.push({
        layer: glayerDoveDisegno,
        id: id,
        tipoicona: "",
        zindex: 10000,
        Entita_Cod: entita_cod,
        veg_cod: -1,
        inserimento: true,
        flag_gps: 0,
        modifica: true,
        cancellazione: true,
        informazioni: "",
        chiavealbero: chiavealbero,
        Testo: $("#txtElementoGrafico_Des").val(),
        AppIdRate: " ",
        TipologiaGML: "Polygon",
        vertici: selectedShape.getPath().getArray()
    });
}



function ConfermaGestioneColoriLayer() {
    //alert('ConfermaGestioneColoriLayer');
    var tabella = $('#place_tabella table tr');

    var stringa_dati = "";
    var conta = 0;
    $('#place_tabella table tr').each(function () {
        if (conta == 0) { //salto la prima riga
            conta = 1;
        }
        else {
            var id = $(this).find(".chiave").val();
            var primario = $(this).find(".primario").val();
            var secondario = $(this).find(".secondario").val();
            var varianza = $(this).find(".varianza").val();
            var zindex = $(this).find(".zindex").val();
            var visible = $(this).find(".flag_visibile").is(":checked");
            if (primario == null)
                primario = "";
            if (secondario == null)
                secondario = "";
            if (varianza == null)
                varianza = "";
            if (zindex == null)
                zindex = "";

            stringa_dati = stringa_dati + id + "|" + primario + "|" + secondario + "|" + varianza + "|" + zindex + "|" + visible + "$";
        }
    });
    var hiddenPrincipale_1_Dettagli_2 = $('#hiddenPrincipale_1_Dettagli_2').val();
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaColoriLayer",
        data: "{ Tipologia:'" + hiddenPrincipale_1_Dettagli_2 + "', Dati: '" + stringa_dati + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#WaitFrame').hide();

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                alert("Colori Impostati, verrà ricaricata la pagina");
                location.href = indirizzohttp;
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

function ConfermaSalvataggioAB() {
    $('#WaitFrame').show();

    var hiddenPunti_A = '(' + $('#hiddenA').val() + ')';
    var hiddenPunti_B = '(' + $('#hiddenB').val() + ')';
    var hiddenPunti_AB = $('#hiddenCurrentSelectedAB').val();

    $('#hiddenCurrentSelectedAB').val('');
    $('#hiddenA').val('');
    $('#hiddenB').val('');

    //    $.logThis('A = ' + hiddenPunti_A);
    //    $.logThis('B = ' + hiddenPunti_B);
    //    $.logThis('AB = ' + hiddenPunti_AB);

    //se sono tutte valorizzate allora posso procedere
    var blocca = false;

    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString(); //.replace(/\\/g, '\\\\'); ;


    //$.logThis(ChiaveAlbero);

    //se sono tutte valorizzate allora posso procedere
    if (ChiaveAlbero == "") {
        alert("nessun impianto o pianificazione selezionata.");
        return false;
    }

    if (blocca) {
        alert("completare i campi obbligatori");
        return false;
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaNuovoAB",
        data: "{ chiaveAlbero: '" + ChiaveAlbero + "', hiddenPunti_A: '" + hiddenPunti_A + "', hiddenPunti_B: '" + hiddenPunti_B + "', hiddenPunti_AB: '" + hiddenPunti_AB + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                //$.logThis(msg.d);
                if (msg.d == 'Ok') {
                    $("#dialogAB").dialog("close");
                    AggiornaTutto();
                }
                else {
                    alert(msg.d);
                }
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

//function ImpostaAziendaAppenaSalvataSuCombo(piva, rag_soc) {

////    if (DammiOptionValueInSelect("#ddl_Aziende") != piva) {
////        $("#ddl_Aziende_toAdd").val(piva + '|' + rag_soc);
////        setTimeout('__doPostBack(\'ddl_Aziende\',\'\')', 0);
////    }

//}


/******************* ELIMINA ************************/

function EliminaImpiantoPuntiScomposti() {

    if ($("#ckConfermaEliminaPuntiScomposti").is(':checked') == false) {
        alert("per procedere spuntare prima di confermare, altrimenti fare click su annulla.");
        return false;
    }

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/EliminaImpiantoPuntiScomposti",
        data: "",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $("#dialogEliminaImpiantoPuntiScomposti").dialog("close");
            $('#WaitFrame').hide();


            if (msg.d == "SessioneScaduta") {
                $('#dialogSessioneScaduta').dialog("open");
            } else {
                if (msg.d != "ok")
                    alert(msg.d);
                else
                    alert("Operezione eseguita correttamente.");
            }

            if ($('#AggiornaFiltro').length > 0) {
                $('#AggiornaFiltro').click();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

function resettaCheckElimina() {


    $("#ckEliminaGrafica").removeAttr('checked');
    $("#ckEliminaPrecision").removeAttr('checked');
    $("#ckEliminaPrecisionABLine").removeAttr('checked');
    $("#ckEliminaImpianto").removeAttr('checked');
    $("#ckEliminaDatoPalm").removeAttr('checked');
    $("#ckConfermaElimina").removeAttr('checked');

}

function dialogEliminaImpiantoOnOpen() {

    var Entita_Cod = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();

    $.logThis("dialogEliminaImpiantoOnOpen = " + Entita_Cod);

    resettaCheckElimina();

    //verifica se posso eliminare i planning.. lo faccio se: non sono sementi, si tratta di un planning.
    if (!isSementi && Entita_Cod != undefined) {
        if (startsWith(Entita_Cod, chiaveAlberoPlanning)) {
            $('#WaitFrame').show();

            $.ajax({
                type: "POST",
                url: indirizzohttp + "/VerificaCancella",
                data: "{ Entita_Cod: '" + Entita_Cod + "' }",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {

                    $('#WaitFrame').hide();

                    if (msg.d == "SessioneScaduta") {
                        $('#dialogSessioneScaduta').dialog("open");
                    } else {
                        if (msg.d == "true") {
                            $("#divEliminaEntitaGIAS").show();
                        }
                        else {
                            $("#divEliminaEntitaGIAS").hide();

                        }
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            });
        }
    }

}


//#region cancellazione

/* funzione per l eliminazione di un impianto esistente */
function EliminaMultipointSelezionati() {

    if ($("#ckConfermaEliminaMultipoint").is(':checked') == false) {
        alert("per procedere spuntare prima di confermare, altrimenti fare click su annulla.");
        return false;
    }

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/CancellaMultipoint",
        data: "{ hiddenPunti_M: '" + $("#hiddenMultipointModifica").val() + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#WaitFrame').hide();
            $("#dialogEliminaMultipoint").dialog('close');
            $("#hiddenMultipointModifica").val('');


            if (msg.d.Esito == true) {
                alert(msg.d.StringaRisposta);
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                alert(msg.d.StringaRisposta);
                if (selectedShape != undefined)
                    selectedShape.setMap(null);
            }

            if ($('#AggiornaFiltro').length > 0) {
                $('#AggiornaFiltro').click();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });


}


/* funzione per l eliminazione di un impianto esistente */
function EliminaImpianto() {
    $('#hiddenID').val(selectedShape.html);

    var eliminaImpinato = $('#ckEliminaImpianto').is(':checked');
    var eliminaGrafica = $('#ckEliminaGrafica').is(':checked');
    var EliminaDatoGiasPalm = $('#ckEliminaDatoPalm').is(':checked');
    var EliminaPrecisionFarming = $('#ckEliminaPrecision').is(':checked');
    var EliminaPrecisionFarmingABLine = $('#ckEliminaPrecisionABLine').is(':checked');

    var pivasuperuser = $('#hiddenID').val().split("|")[0];
    var Entita_Cod = $('#hiddenID').val().split("|")[1];

    //se sono tutte valorizzate allora posso procedere
    if (pivasuperuser == "" || Entita_Cod == "") {
        alert("nessun poligono selezionato.");
        return false;
    }

    if ($("#ckConfermaElimina").is(':checked') == false) {
        alert("per procedere spuntare prima di confermare, altrimenti fare click su annulla.");
        return false;
    }

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/Cancella",
        data: "{ entita_cod: '" + Entita_Cod + "', EliminaGrafica: '" + eliminaGrafica + "', EliminaImpianto: '" + eliminaImpinato + "', EliminaPrecisionFarming: '" + EliminaPrecisionFarming + "', EliminaPrecisionFarmingABLine: '" + EliminaPrecisionFarmingABLine + "', EliminaDatoGiasPalm: '" + EliminaDatoGiasPalm + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $("#dialogEliminaImpianto").dialog("close");
            $('#WaitFrame').hide();

            if (msg.d.Esito == true) {
                alert(msg.d.StringaRisposta);
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                alert(msg.d.StringaRisposta);
                if (selectedShape != undefined)
                    selectedShape.setMap(null);
            }

            if ($('#AggiornaFiltro').length > 0) {
                $('#AggiornaFiltro').click();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

/******************* MODIFICA IMPIANTO ************************/
/* funzione per la modifica di un impianto esistente */
function ModificaImpianto() {
    $('#WaitFrame').show();
    var pivasuperuser = $('#hiddenID').val().split("|")[0];
    var Entita_Cod = $('#hiddenID').val().split("|")[1];

    var nomeAppezzamento = $('#pop_up_nome_appezza_modifica').val();
    var specie = $('#pop_up_specie_modifica').val();
    var varieta = $('#pop_up_varieta_modifica').val();
    var finalita = $('#pop_up_finalita_modifica').val();
    var tipologia = $('#pop_up_tipologia_modifica').val();
    if (tipologia == null)
        tipologia = "0";
    var sup_google = $('#pop_up_sup_google_modifica').val();
    var sup_impianto = $('#pop_up_sup_app_modifica').val();
    var hiddenPunti_modifica = $('#hiddenPunti_modifica').val();
    var mData_Inizio = $('#pop_up_m_data_inizio').val();
    var mData_Fine = $('#pop_up_m_data_fine').val();
    var stop = false;

    //se sono tutte valorizzate allora posso procedere
    if (pivasuperuser == "" || Entita_Cod == "" || specie == "" || varieta == "" || finalita == "" || tipologia == "" || sup_google == "" || sup_impianto == "" || hiddenPunti_modifica == "") {
        stop = true;
    }
    if (isSementi && (mData_Inizio == "" || mData_Fine == "")) {
        stop = true;
    }

    if (stop) {
        alert("Completare i dati obbligatori.");
        $('#WaitFrame').hide();
        return false;
    }

    // controllo se devo associare la superficie a impianto o appezzamento
    if ($('#opt_associa_modifica').val() == '1') {
        //posso fare il semplice salvataggio dei dati senza modificare la superficie
        ModificaDatiImpianto();
    }
    else {
        var MVCArray = selectedShape.getPath();
        var area = sup_impianto;

        $('#WaitFrame').hide();

        //        var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString().replace(/\\/g, '\\\\'); ;
        var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();
        if ($('#opt_associa_modifica').val() == '2') {
            //voglio associare la superficie solamente all'impianto
            // devo controllare se ci sono delle operazioni registrate su questo impianto
            $.ajax({
                type: "POST",
                url: indirizzohttp + "/ControllaSeEsistonoOperazioni",
                data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    if (msg.d == "SessioneScaduta") {
                        $('#dialogSessioneScaduta').dialog("open");
                    } else {
                        if (msg.d == "true") {

                            //non ho alcuna operazione, posso procedere con la modifica della superficie
                            ModificaDatiImpianto();

                            //vanni, 16/01/2015, test senza chiamata a salvataggio diretto, commentata chiamata
                            //salvataggioDiretto(area);

                            $('#pop_up_modificaImpianto').dialog('close');
                        } else {
                            //attenzione
                            $('#lbl_alert_operazioni').html(msg.d);
                            $('#dialogAllertOperazioni_hidden').val(2);
                            $('#dialogAllertOperazioni').dialog("open");
                        }
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            });
        }
        else {
            //voglio associare la superficie a impianto e appezzamento
            //devo controllare se ci sono operazione registrate sull'impianto e se l'appezzamento ha collegato il catasto
            $.ajax({
                type: "POST",
                url: indirizzohttp + "/ControllaSeEsisteCatasto",
                data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    if (msg.d == "SessioneScaduta") {
                        $('#dialogSessioneScaduta').dialog("open");
                    } else {
                        if (msg.d == "true") {
                            alert("L'appezzamento è collegato con il catasto, in questo caso la modifica della superficie è da effettuare a mano. Andare sull'anagrafica dell'appezzamento se si vuole variare la superficie dell'appezzamento..");
                            $('#opt_associa_modifica').val(2);
                        } else {
                            // se non ho il catasto collegato controllo se esistono operazioni 
                            $.ajax({
                                type: "POST",
                                url: indirizzohttp + "/ControllaSeEsistonoOperazioni",
                                data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
                                contentType: "application/json; charset=utf-8",
                                dataType: "json",
                                success: function (msg) {
                                    if (msg.d == "SessioneScaduta") {
                                        $('#dialogSessioneScaduta').dialog("open");
                                    } else {
                                        if (msg.d == "true") {

                                            //non ho alcuna operazione, posso procedere con la modifica della superficie


                                            //vanni, 16/01/2015, test senza chiamata a salvataggio diretto, commentata chiamata a ModificaDatiImpianto
                                            if (isNuovoElemento()) {
                                                salvataggioDirettoConAppezza(area);
                                            }
                                            else {
                                                ModificaDatiImpianto();
                                            }

                                            $('#pop_up_modificaImpianto').dialog('close');
                                        } else {
                                            //attenzione
                                            $('#lbl_alert_operazioni_Appezza').html(msg.d);
                                            $('#dialogAllertOperazioni_hidden').val(2);
                                            $('#dialogAllertOperazioniAppezza').dialog("open");
                                        }
                                    }
                                },
                                error: function (xhr, ajaxOptions, thrownError) {
                                    alert(xhr.status);
                                    alert(thrownError);
                                }
                            });
                        }
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            });
        }
    }

}


function ModificaDatiImpianto() {
    $('#WaitFrame').show();
    var pivasuperuser = $('#hiddenID').val().split("|")[0];
    var Entita_Cod = $('#hiddenID').val().split("|")[1];

    var via_stringa = $('#via_stringa_modifica').val();

    var nome_appezza = $('#pop_up_nome_appezza_modifica').val();
    var specie = $('#pop_up_specie_modifica').val();
    var varieta = $('#pop_up_varieta_modifica').val();
    var finalita = $('#pop_up_finalita_modifica').val();
    var tipologia = $('#pop_up_tipologia_modifica').val();
    var lotto = $('#pop_up_m_lotto').val();
    if (tipologia == null)
        tipologia = "0";
    var sup_google = $('#pop_up_sup_google_modifica').val();

    var sup_impianto;
    if ($('#opt_associa_modifica').val() == 1) {
        sup_impianto = 0;
    }
    else {
        sup_impianto = $('#pop_up_sup_app_modifica').val();
    }

    var hiddenPunti_modifica = $('#hiddenPunti_modifica').val();

    var mData_Inizio = $('#pop_up_m_data_inizio').val();
    var mData_Fine = $('#pop_up_m_data_fine').val();
    var stop = false;

    //se sono tutte valorizzate allora posso procedere
    if (pivasuperuser == "" || Entita_Cod == "" || specie == "" || varieta == "" || finalita == "" || sup_google == "" || hiddenPunti_modifica == "") {
        stop = true;
    }

    if (isSementi && (mData_Inizio == "" || mData_Fine == "")) {
        stop = true;
        alert("2");
    }

    if (stop) {
        alert("Completare i dati obbligatori.");
        $('#WaitFrame').hide();
        return false;
    }
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ModificaImpianto",
        data: "{ entita_cod: '" + Entita_Cod + "', nome_appezza: '" + nome_appezza + "', sup_imp: '" + sup_impianto + "', data_inizio: '" + mData_Inizio + "', data_fine: '" + mData_Fine + "', specie: '" + specie + "', varieta: '" + varieta + "', finalita: '" + finalita + "', tipologia: '" + tipologia + "' , hiddenPunti_modifica: '" + hiddenPunti_modifica + "' , via_stringa: '" + via_stringa + "' , lotto: '" + lotto + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            if (msg.d == 'SessioneScaduta') {
                $("#pop_up_modificaImpianto").dialog("close");
                $('#WaitFrame').hide();
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                alert("salvataggio avvenuto con successo");

                //16/01/2015, ripulisco la selezione.
                $('#hiddenPunti_modifica').val("");

                AggiornaTutto();
                $("#pop_up_modificaImpianto").dialog("close");
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


function AggiornaTutto() {

    CoordFromPoints = "";
    CoordFromPointsMVCArray = new google.maps.MVCArray();

    AggiornaLayer();
    Inizializza();
    redimAlbero();
}



/*******************************************************************/
/********************* SHAPE ***************************************/
/*******************************************************************/
/* tolgo l'editing sullo shape */
function clearSelection() {

    if (selectedShape) {

        $.logThis("clearSelection()");

        selectedShape.set('fillColor', selectedShape.colore_precedente);
        selectedShape.setEditable(false);

        selectedShape = null;
        $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val('');

        $('.jstree-clicked').removeClass('jstree-clicked');
        if (gNuovo)
            $('#disenga_poligono').show();
    }
}

function clearSelectionArray() {

    if (selectedShapeArray) {

        $.logThis("clearSelectionArray()");

        for (i = 0; i < selectedShapeArray.length; i++) {
            var ss = selectedShapeArray[i];
            ss.set('fillColor', ss.colore_precedente);
            ss.setEditable(false);
        }

        selectedShapeArray = new Array();
        $("#ChiaveAlberoMultiSelezione").val("");
        ShapeAddedd = false;
    }
}

function clearSelectionMultipoint() {
    $("#hiddenMultipoint").val("");
    $("#hiddenMultipointModifica").val("");
}

function clearSelectionBoth() {

    $.logThis("clearSelectionBoth()");

    clearSelection();
    clearSelectionArray();
    clearSelectionMultipoint();
}




/* Evento di Selezione di un ab-line */
function setSelectionAB(shape) {



    $('#hiddenCurrentSelectedAB').val(shape.html);
    $("#chkAB").prop("checked", "checked");

    addAB($("#chkAB"), $('#hiddenA'), $('#hiddenB'), null, null, null, null);

    return;



}

function getBounds(obj) {
    var bounds = new google.maps.LatLngBounds();
    var paths = obj.getPaths();
    var path;
    for (var p = 0; p < paths.getLength(); p++) {
        path = paths.getAt(p);
        for (var i = 0; i < path.getLength(); i++) {
            bounds.extend(path.getAt(i));
        }
    }
    return bounds;
}

/* Evento di Selezione di un punto */
function setSelectionPointMouseUp(shape) {

    $.logThis('setSelectionPointMouseUp: ' + shape.html);
    $.logThis('lat: ' + shape.getPosition());

    addMarkerMultiPointModifica(shape.html, shape.getPosition());

    setSelectionAlbero(shape);

}




function setSelectionPoint(shape) {

    if (shape.getIcon() != flgSelezionato) {
        CoordFromPoints = CoordFromPoints + shape.getPosition() + ",";
        CoordFromPointsMVCArray.push(shape.getPosition());
        $.logThis('test: ' + shape.html);
        $.logThis('lat: ' + shape.getPosition());

        shape.setIcon(flgSelezionato);
    }

}

var ShapeAddedd = false;
/* Evento di Selezione nultipla dello shape */
function setMultiSelection(shape) {

    var oldShape = selectedShape;

    $.logThis("setMultiSelection chiamata!");

    setSelection(shape);
    shape.set('fillColor', selectedShape.selectedColor);
    var idNoA = ""

    //la prima selezione la aggiungo..
    if (oldShape && !ShapeAddedd) {
        selectedShapeArray.push(oldShape);
        ShapeAddedd = true;
        if (oldShape.chiavealbero != null) {
            idNoA = oldShape.chiavealbero.toString().replace(' ', '');
            $("#ChiaveAlberoMultiSelezione").val($("#ChiaveAlberoMultiSelezione").val() + idNoA + "|");
        }
    }

    //aggiungo la selezione corrente
    if (ShapeAddedd) {
        if (shape.chiavealbero != null) {
            idNoA = shape.chiavealbero.toString().replace(' ', '');

            if (contains($("#ChiaveAlberoMultiSelezione").val(), idNoA)) {

                $.logThis("deseleziona: 1. " + $("#ChiaveAlberoMultiSelezione").val());
                var valToReplace = $("#ChiaveAlberoMultiSelezione").val().replace(idNoA + "|", "");
                $.logThis("deseleziona: 2. " + valToReplace);

                $("#ChiaveAlberoMultiSelezione").val(
                    valToReplace
                );

                $.logThis("deseleziona: 3. " + $("#ChiaveAlberoMultiSelezione").val());

                selectedShapeArray = jQuery.removeFromArray(shape, selectedShapeArray);
                clearSelection();
            }
            else {
                selectedShapeArray.push(shape);
                $("#ChiaveAlberoMultiSelezione").val($("#ChiaveAlberoMultiSelezione").val() + idNoA + "|");

            }
        }

    }
}

/* Evento di Selezione dello shape */
function setSelection(shape) {

    map.setCenter(getBounds(shape).getCenter(), map.fitBounds(getBounds(shape)));
    var zoom = map.getZoom() - 1;
    map.setZoom(zoom);

    if (!ctrlPressed)
        clearSelectionBoth();

    selectedShape = shape;


    selectedShape.set('fillColor', selectedShape.selectedColor);

    //permessi
    if (selectedShape.modifica == 'True') {
        shape.setEditable(true);
        $('#save-button').show();
    }
    else {
        shape.setEditable(false);
        $('#save-button').hide();
    }

    if (selectedShape.cancellazione == 'True') {
        shape.setEditable(true);
        $('#delete-button').show();
    }
    else {
        shape.setEditable(false);
        $('#delete-button').hide();
    }

    if (selectedShape.informazioni == 'True') {
        shape.setEditable(true);
        //mostrerò ttutte le informanzioni
        $('#info_appezzamento').show();
    }
    else {
        shape.setEditable(false);
        //mostro poche informazioni
        $('#info_appezzamento').show();
    }

    $('#disenga_poligono').hide();
    //fine permessi

    if (shape.chiavealbero != null) {
        setSelectionAlbero(shape);
    }


}


function setSelectionAlbero(shape) {
    var idNoA = shape.chiavealbero.toString().replace(' ', '');
    var id = 'a' + idNoA;
    $('.jstree-clicked').removeClass('jstree-clicked');
    $('#' + id).addClass('jstree-clicked');

    $.logThis(id);
    $.logThis($('#' + id).attr('href'));

    //myScrollTop(id, "#spazio_Albero");
    myScrollTop(id, "#albero");


    $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val(idNoA);

    selezionaIndiceLayerDoveScrivoDaOggettoGrafico();


    var selezionatoLayerDataChiaveAlbero = false;
    for (var i = 0; i < Livelli.length; i++) {
        if (!selezionatoLayerDataChiaveAlbero)
            selezionatoLayerDataChiaveAlbero = selezionaIndiceLayerDoveScrivoDaAlbero(Livelli[i], shape.chiavealbero.toString());
    }
}
function myScrollTop(id, divToScroll) {

    var p;
    try {

        p = $("#treeAlberoAnagraficaAlberoAnagrafica").offset().top;


        //x 4 livelli
        var objcorrente = $(document.getElementById(id));
        for (a = 0; a <= 10; a++) {
            objcorrente = $(objcorrente).parent()
            if ($(objcorrente).html() === undefined)
                break

            $(objcorrente).removeClass("jstree-closed").addClass("jstree-open");

        }





        var p2 = $(document.getElementById(id)).position().top;

        var goToScroll = -p + p2 + offSetScrollTop;

        $.logThis("spazio_Albero = " + $(divToScroll).height() + " - goToScroll = " + goToScroll);


        $(divToScroll).scrollTop(goToScroll);

    }
    catch (e) {
        $.logThis("catch! myScrollTop(" + id + ", " + divToScroll + ")");

    }
}





/* Eliminazione dello shape */
function deleteSelectedShape() {
    if (selectedShape) {
        $("#dialogEliminaImpianto").dialog("open");
        return;
    }

    if ($("#hiddenMultipointModifica")) {
        $("#dialogEliminaMultipoint").dialog("open");
        return;
    }

}

function dialogAB() {
    $("#dialogAB").dialog("open");
}
function dialogMultipoint() {
    $("#dialogMultipoint").dialog("open");
}


function dialogRateo() {
    $("#dialogRateo").dialog("open");
}

function dialogGeneraPlanning() {
    $("#dialogGeneraPlanning").dialog("open");
}

function ClearSelect(obj) {
    $('.toolSelezionato').removeClass('toolSelezionato');
    obj.addClass('toolSelezionato');
    obj.effect("bounce", { direction: 'down', times: 5 }, 300);
}

function BlinkFast(obj) {
    $('.toolSelezionato').removeClass('toolSelezionato');
    obj.addClass('toolSelezionato toolSelezionatoEvidenziato');
    //    obj.effect("bounce", { direction: 'down', times: 30, distance: 50, mode: 'effect' }, 300);
    obj.effect("bounce", { direction: 'down', times: 5 }, 300);
}

function predisponiLayoutDialogImpianto() {
    if (isSementi) {
        $("#lblpop_up_centro").html("Campo");
        $("#lblpop_up_data_inizio").html("Data Inserimento");
        $("#lblpop_up_data_fine").html("Data Raccolto");
        $("#lblpop_up_m_data_inizio").html("Data Inserimento");
        $("#lblpop_up_m_data_fine").html("Data Raccolto");
        $("#pop_up_data_inizio").attr("disabled", "disabled");
        $("#pop_up_m_data_inizio").attr("disabled", "disabled");
        $("#pop_up_data_fine").attr("disabled", "disabled");
        $("#pop_up_m_data_fine").attr("disabled", "disabled");
    }
    else {
        $("#righelloCampoVicino").hide();
    }
}

//Tipologia caricamento 1 --> caricamento della modifica appezzamento
function getProprieta(Veg_Cod, Entita_Cod, selectedShape_testo, tipologiaCaricamento) {
    var ritorno;
    if (contains(Entita_Cod, "§")) {
        var app = Entita_Cod.split("§");
        Entita_Cod = app[app.length - 2].split("|")[1].split("^")[0];
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/getProprieta",
        data: "{ Entita_Cod: '" + Entita_Cod + "',tipologia: '" + tipologiaCaricamento + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            //            var r = eval('(' + msg.d + ')');
            var r = JSON.parse(msg.d);
            //            alert(Veg_Cod);
            //$.logThis("Veg_Cod (getProprieta) :" + Veg_Cod);

            if (tipologiaCaricamento == 1)
                ImpostaValoriModifcaAppezzamento(Veg_Cod, r);

            if (tipologiaCaricamento == 2)
                ImpostaValoriInfoAppezzamento(Entita_Cod, Veg_Cod, r);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function formattaStringaInfo(etichetta, valore) {
    if (valore != "")
        return " " + etichetta + ": " + valore + " <br/> ";
    else
        return "";
}

function ImpostaValoriInfoAppezzamento(Entita_Cod, Veg_Cod, r) {

    //selectedShape.testo
    //infowindow.setContent(selectedShape.Entita_Cod);
    var msg = "<div style='width:250px'> <b> Codice: " + Entita_Cod + " </b> <br/> ";
    var selectedShape_testo = "";
    var area = 0;
    var r_grfi_des = "";

    if (selectedShape !== undefined) {
        if (selectedShape.informazioni == 'True') {
            msg += formattaStringaInfo("Az", r.rag_soc);
            msg += formattaStringaInfo("Centro", r.sa_nome);
            r_grfi_des = r.grfi_des
        }
        selectedShape_testo = selectedShape.testo;
        var MVCArray = selectedShape.getPath();
        area = getArea();

        $.logThis("ImpostaValoriInfoAppezzamento, area: " + area);
    }


    msg += formattaStringaInfo("Descrizione", selectedShape_testo);
    msg += " <br/> ";
    msg += formattaStringaInfo("Sup", r.Superficie);

    if (area != 0)
        msg += formattaStringaInfo("Sup. [google]", area);


    msg += formattaStringaInfo("Indirizzo", r.indirizzo);

    if (r.Progetto_Nome != "")
        msg += formattaStringaInfo("Lotto", r.Progetto_Nome);

    msg += " <br/> ";


    msg += formattaStringaInfo("Specie", r.veg_des);
    msg += formattaStringaInfo("Varietà", r.cul_des);
    msg += formattaStringaInfo("Tipologia", r.grva_des);

    if (r_grfi_des != "") {
        msg += formattaStringaInfo("Finalità", r.grfi_des);
    }
    msg += formattaStringaInfo("Validita Inizio", r.Validita_Inizio);
    msg += formattaStringaInfo("Validita Fine", r.Validita_Fine);

    msg += " </div> ";
    //msg += " Tecnico: " + r.codice_fiscale_tecnico + " <br/> ";

    infowindow.setContent(msg);

}

function ImpostaValoriModifcaAppezzamento(Veg_Cod, r) {
    CaricaTipologia(Veg_Cod, "#pop_up_tipologia_modifica", r.grva_cod);
    CaricaVarieta("#pop_up_varieta_modifica", r.cul_cod);
    CaricaFinalita("#pop_up_finalita_modifica", r.grfi_cod);
    $('#pop_up_sup_precedente').val(r.Superficie);
    $('#pop_up_sup_app_modifica').val(r.Superficie);
    $('#via_stringa_modifica').val(r.indirizzo);

    $('#pop_up_m_lotto').val(r.Progetto_Nome);

    if (r.Validita_Inizio != '01/01/1900') {

        $('#pop_up_m_data_inizio').val(r.Validita_Inizio);
    }
    else {
        $('#pop_up_m_data_inizio').val("");
    }

    if (r.Validita_Fine != '31/12/2100') {
        $('#pop_up_m_data_fine').val(r.Validita_Fine);
    }
    else {
        $('#pop_up_m_data_fine').val("");
    }

    $('#WaitFrame').hide();

}


/* Salvataggio dello Shape */
function preparaXSalvataggioPoligoni() {


    if ($("#hiddenMultipointModifica").val() != "" && selectedShape) {
        alert("modifica di elementi multipli non consentita.");
    }


    if ($("#hiddenMultipointModifica").val() != "") {

        $('#WaitFrame').show();

        //carica App_nome o Programmazione_des
        $.ajax({
            type: "POST",
            url: indirizzohttp + "/ModificaMultipoint",
            data: "{ hiddenPunti_M: '" + $("#hiddenMultipointModifica").val() + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                if (msg.d == "SessioneScaduta") {
                    $('#dialogSessioneScaduta').dialog("open");
                } else {

                    $('#WaitFrame').hide();
                    $("#hiddenMultipointModifica").val('');

                    if (msg.d == "Ok") {
                        alert("salvataggio avvenuto con successo");
                    }
                    else {
                        alert(msg.d);
                    }

                    if ($('#AggiornaFiltro').length > 0) {
                        $('#AggiornaFiltro').click();
                    }
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });
        return;
    }


    if (selectedShape) {
        //i punti Salvati
        var MVCArray = selectedShape.getPath();

        var test;
        test = MVCArray.getArray().toString();
        $.logThis("PIPOPPOO:");


        //controllo se è un nuovo shape o la modifica di uno vecchio
        if (selectedShape.html == undefined) {
            if (VerificaPoligono(test, true) == false) {
                return false;
            }


            $('#hiddenPunti_Nuovo').val(MVCArray.getArray().toString());

            var area = getArea();

            //aggiungo l'infobox
            $('#pop_up_sup_app').val(area);
            $('#pop_up_sup_google').val(area);


            predisponiLayoutDialogImpianto();

            var salvataggio_diretto = false;
            if ($("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val() != '') {
                salvataggio_diretto = true;
            } else {
                //se ho il valore 
            }

            $.logThis("salvataggio_diretto:" + salvataggio_diretto);

            if (salvataggio_diretto == true) {
                $('#lblDialogSup').html(area);
                $('#dialogConfermaAssociazione').dialog("open");

            }
            else {


                $("#pop_up_impianto").dialog("open");
                ImpostaVisibilita_pop_up_impianto();

                initDatePiker();


                $('#WaitFrame').show();

                CaricaSpecie('#pop_up_specie', '');
                CaricaAzienda();

                if (isSementi == false) {
                    CaricaDateDefault('#pop_up_data_inizio', '#pop_up_data_fine');
                }
                ImpostaPulsantiNuovoImpianto();
                $('#WaitFrame').hide();
                identificaIndirizzi(MVCArray);
            }
            selectedShape.setEditable(false);

        } else {

            if (VerificaPoligono(test, false) == false) {
                return false;
            }

            //            $.logThis("selectedShape.html:" + selectedShape.html);

            predisponiLayoutDialogImpianto();

            $('#hiddenPunti_modifica').val(MVCArray.getArray().toString());
            $('#hiddenID').val(selectedShape.html);

            var area = getArea();

            $('#pop_up_sup_google_modifica').val(area);
            //            $('#pop_up_sup_app_modifica').val(area);

            ImpostaVisibilita_pop_up_modificaImpianto();
            $("#pop_up_modificaImpianto").dialog("open");

            $('#WaitFrame').show();


            //carica App_nome o Programmazione_des
            $.ajax({
                type: "POST",
                url: indirizzohttp + "/CaricaAppNomeProgrammazione_des",
                data: "{ ChiaveAlbero: '" + selectedShape.chiavealbero + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (msg) {
                    if (msg.d == "SessioneScaduta") {
                        $('#dialogSessioneScaduta').dialog("open");
                    } else {
                        $('#pop_up_nome_appezza_modifica').val(msg.d);
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.status);
                    alert(thrownError);
                }
            });



            setTimeout(function () {
                var Veg_Cod = selectedShape.vegcod;
                CaricaSpecie("#pop_up_specie_modifica", Veg_Cod);
                var Entita_Cod = selectedShape.Entita_Cod;
                getProprieta(Veg_Cod, Entita_Cod, "", 1);
                if (isSementi == false) {
                    CaricaDateDefault('#pop_up_m_data_inizio', '#pop_up_m_data_fine');
                }
                selectedShape.setEditable(false);
                $('#WaitFrame').hide();
            }, 100);
        }

    } else {
        alert("non è stato selezionato nulla");
    }
}

function ImpostaVisibilita_pop_up_modificaImpianto() {
    $.logThis("ImpostaVisibilita_pop_up_modificaImpianto, glayerDoveDisegno = " + glayerDoveDisegno);

    if (glayerDoveDisegno != "19") {
        $("#pop_up_modificaImpianto_DatiImp").hide();
        $("#Dati_data_inizio_fine_modifica").hide();

    } else {
        $("#pop_up_modificaImpianto_DatiImp").show();
        $("#Dati_data_inizio_fine_modifica").show();
    }

}


function ImpostaVisibilita_pop_up_impianto() {

    $.logThis("ImpostaVisibilita_pop_up_impianto, glayerDoveDisegno = " + glayerDoveDisegno);

    if (glayerDoveDisegno != "19") {
        $("#PopupNuovaImpresa-Button").hide();
        $("#PopupNuovoSa-Button").hide();
        $("#divpop_up_specie").hide();
        $("#placeTipologia").hide();
        $("#divOpzioni_pop_up_impianto").hide();
    } else {
        $("#PopupNuovaImpresa-Button").show();
        $("#PopupNuovoSa-Button").show();
        $("#divpop_up_specie").show();
        $("#placeTipologia").show();
        $("#divOpzioni_pop_up_impianto").show();

    }

}

function ControllaSeEsisteCatasto(area) {
    //    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString().replace(/\\/g, '\\\\'); ;
    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ControllaSeEsisteCatasto",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == "SessioneScaduta") {
                $('#dialogSessioneScaduta').dialog("open");
            } else {
                if (msg.d == "true") {
                    alert("L'appezzamento è collegato con il catasto, in questo caso la modifica della superficie è da effettuare a mano. Andare sull'anagrafica dell'appezzamento se si vuole variare la superficie dell'appezzamento..");
                    $('#option_associa').val(2);
                } else {
                    // se non ho il catasto collegato controllo se esistono operazioni 
                    $.ajax({
                        type: "POST",
                        url: indirizzohttp + "/ControllaSeEsistonoOperazioni",
                        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function (msg) {
                            if (msg.d == "SessioneScaduta") {
                                $('#dialogSessioneScaduta').dialog("open");
                            } else {
                                if (msg.d == "true") {
                                    //non ho alcuna operazione, posso procedere con la modifica della superficie
                                    salvataggioDirettoConAppezza(area);
                                } else {
                                    //attenzione
                                    $('#lbl_alert_operazioni_Appezza').html(msg.d);
                                    $('#dialogAllertOperazioniAppezza').dialog("open");
                                }
                            }
                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                            alert(xhr.status);
                            alert(thrownError);
                        }
                    });
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


function ControllaSeEsistonoOperazioni(area) {

    //    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString().replace(/\\/g, '\\\\'); ;
    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ControllaSeEsistonoOperazioni",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == "SessioneScaduta") {
                $('#dialogSessioneScaduta').dialog("open");
            } else {
                if (msg.d == "true") {
                    //non ho alcuna operazione, posso procedere con la modifica della superficie
                    salvataggioDiretto(area);
                } else {
                    //attenzione
                    $('#lbl_alert_operazioni').html(msg.d);
                    $('#dialogAllertOperazioni_hidden').val(1);
                    $('#dialogAllertOperazioni').dialog("open");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}



function salvataggioDirettoConAppezza(area) {
    //    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString().replace(/\\/g, '\\\\'); ;
    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();
    var hiddenPunti_Nuovo = $('#hiddenPunti_Nuovo').val();

    //vanni, 16/01/2015, per baco su grafica duplicata


    var hiddenPunti_modifica = $('#hiddenPunti_modifica').val();

    var hiddenPunti_daSalvare;

    if (hiddenPunti_modifica != "")
        hiddenPunti_daSalvare = hiddenPunti_modifica;
    else
        hiddenPunti_daSalvare = hiddenPunti_Nuovo;


    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaNuovoElementoGraficoDaChiaveAlberoConAppezza",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "', hiddenPunti_Nuovo: '" + hiddenPunti_daSalvare + "', Area: '" + area + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#responseInterferenze').width('0px');
            $('#responseInterferenze').html('');
            $("#pop_up_impianto").dialog("close");



            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                //16/01/2015, azzero oggetti.
                if (selectedShape != undefined)
                    selectedShape.setMap(null);
                $('#hiddenPunti_modifica').val("");

                AggiornaTutto();
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}



function salvataggioDiretto(area) {

    //    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString().replace(/\\/g, '\\\\');  
    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();
    var hiddenPunti_Nuovo = $('#hiddenPunti_Nuovo').val();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaNuovoElementoGraficoDaChiaveAlbero",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "', hiddenPunti_Nuovo: '" + hiddenPunti_Nuovo + "', Area: '" + area + "', ElementoGrafico_Des: '' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#responseInterferenze').width('0px');
            $('#responseInterferenze').html('');
            $("#pop_up_impianto").dialog("close");

            if (selectedShape != undefined)
                selectedShape.setMap(null);

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                AggiornaTutto();
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


/*******************************************************************/
/********************* LAYER ***************************************/
/*******************************************************************/

function clickLayerSelezionaTutto(selezionaSeTrue) {

    $.logThis("clickLayerSelezionaTutto");

    if (selezionaSeTrue) {
        $(".chkLayer").prop("checked", "checked");
    }
    else {
        $(".chkLayer").removeAttr("checked");
    }

    for (var i = 0; i < Livelli.length; i++) {
        clearSingleOverlay(null, Livelli[i].poligoni, !selezionaSeTrue);
        clearSingleOverlay(null, Livelli[i].punti, !selezionaSeTrue);
        clearSingleOverlay(null, Livelli[i].polyline, !selezionaSeTrue);
        clearSingleOverlay(null, Livelli[i].ABLabel, !selezionaSeTrue);
    }
}

/* se il layer è checked = true lo visualizzo altimenti non lo presento nella mappa */
function clearOverlaysByID(id) {

    for (var i = 0; i < Livelli.length; i++) {
        if (Livelli[i].id == id) {

            clearSingleOverlay(null, Livelli[i].poligoni, true);
            clearSingleOverlay(null, Livelli[i].punti, true);
            clearSingleOverlay(null, Livelli[i].polyline, true);
            clearSingleOverlay(null, Livelli[i].ABLabel, true);

        }
    }
}

/* se il layer è checked = true lo visualizzo altimenti non lo presento nella mappa */
function clearOverlays(obj) {
    var valore = obj.val();
    for (var i = 0; i < Livelli.length; i++) {
        if (Livelli[i].id == obj.attr("id")) {

            clearSingleOverlay(obj, Livelli[i].poligoni, false);
            clearSingleOverlay(obj, Livelli[i].punti, false);
            clearSingleOverlay(obj, Livelli[i].polyline, false);
            clearSingleOverlay(obj, Livelli[i].ABLabel, false);

        }
    }
}

function clearSingleOverlay(obj, oggetti, forzaClear) {
    for (var kk = 0; kk < oggetti.length; kk++) {

        if (obj == null) {
            if (forzaClear) {
                oggetti[kk].setMap(null);
            }
            else {
                oggetti[kk].setMap(map);
            }
        }
        else {
            if (obj.is(':checked') == false || forzaClear == true) {
                oggetti[kk].setMap(null);
            } else {
                oggetti[kk].setMap(map);
            }
        }
    }

}

/*******************************************************************/
/********************* TOOL BOX ************************************/
/*******************************************************************/
/* riposizionamento del tool a destra */
function PosizionaTool() {
    //gestione del pannello
    $("#sidebar").css({
        width: 55
    });
    $("#contenitore_tool").css({
        width: 100
    });

    $("#contenitore_tool").css({
        position: 'absolute',
        top: parseInt((h - $('#contenitore_tool').height()) / 2),
        left: (w - $("#sidebar").width()) - 47
    }).show();


    var pp = $("#map").offset();

    $("#tool_bar").css({
        position: 'absolute',
        top: parseInt(pp.top + 5)
    });

    $("#scala_colori_contenitore").css({
        position: 'absolute',
        top: pp.top + $("#map").height() - 70,
        left: pp.left
    });
}

/* tool per la ricerca dell'indirizzo  */
function PosizionaRicercaIndirizzo() {
    //gestione del pannello
    $("#dialog_Ricerca").css({
        position: 'absolute',
        bottom: 0,
        right: 5
    }).show();
}


function makeToolBar() {

    var checklayer = $('#check-layer');
    checklayer.html('');
    for (var i = 0; i < layers.length; ++i) {

        var chiamataFunzione = 'settaLayerDoveDisegnare(' + layers[i].id + ', \'' + layers[i].icona32 + '\', \'' + layers[i].nome + '\')';

        //$.logThis("chiamataFunzione:" + chiamataFunzione);

        var box_img = '<img src="' + layers[i].icona16 + '" onclick="' + chiamataFunzione + '");" />';
        var box = '<span class="color-button" style="background-color:#' + layers[i].colore_1 + '" alt="' + layers[i].colore_1 + '">' + layers[i].nome + '</span>';
        var box_1 = '<span class="color-button" style="background-color:#' + layers[i].colore_2 + '" alt="' + layers[i].colore_2 + '">' + layers[i].nome + '</span>';

        var html = '<input type="checkbox" class="chkLayer" onclick="clearOverlays($(this));" checked="checked" id="' + layers[i].id + '"/><label for="' + layers[i].id + '">' + layers[i].nome + '</label>';
        checklayer.append("<div style='float:left;'>" + box_img + " " + box + " " + box_1 + html + "</div><div style='clear:both'></div>");
    }
}


function settaLayerDoveDisegnare(idLayer, ico32, nomeLay) {

    $.logThis("function settaLayerDoveDisegnare(idLayer:=" + idLayer + ", ico32:=" + ico32 + ", nomeLay:=" + nomeLay + ")");

    glayerDoveDisegno = idLayer;
    decidiCosaPossoDisegnare();
    $("#LayerDoveDisegno").attr('src', ico32);
    $("#imgpop_up_impianto_icolayer").attr('src', ico32);
    $("#testoLayerDoveDisegno").html(nomeLay);
    $("#pop_up_impianto_nomelayer").html("Layer: " + nomeLay);
}

function isLayerVisualizzato(idL) {
    var trovato = false;
    for (var i = 0; i < layers.length; ++i) {
        if (layers[i].id == idL)
            trovato = true;
    }

    return trovato;
}




function selezioneDaIdAlbero(id, multi) {

    $.logThis('Da modificare per selezione ');


    var trovato = false;
    var selezionatoLayerDataChiaveAlbero = false;
    //scorro tutti i layer e tutti i path per identificare quello attivo
    for (var i = 0; i < Livelli.length; i++) {

        if (!selezionatoLayerDataChiaveAlbero)
            selezionatoLayerDataChiaveAlbero = selezionaIndiceLayerDoveScrivoDaAlbero(Livelli[i], id);

        if (trovato == false) {
            $.logThis('trovato = true');
            for (var kk = 0; kk < Livelli[i].poligoni.length; kk++) {

                if (Livelli[i].poligoni[kk].chiavealbero == id) {
                    trovato = true;
                    if (!multi) {
                        setSelection(Livelli[i].poligoni[kk]);
                        break;
                    } else {
                        ctrlPressed = true;
                        setMultiSelection(Livelli[i].poligoni[kk]);
                        ctrlPressed = false;
                        break;
                    }

                }
            }
        }
        else
        { i = Livelli.length; }
    }
    if (!multi) {
        if (trovato == false) {
            clearSelectionBoth();
            $('#disenga_poligono').show();
        }
    }
}

$(window).resize(function () {
    var p = $("#map").offset();
    h = ($("#map").height() + p.top);
    w = ($("#map").width() + p.left);


    for (var j = 0; j < Livelli.length; j++) {
        CreaPannelloColore('abc', Livelli[j].datiViste);
    }

    PosizionaRicercaIndirizzo();
    PosizionaTool();
});

function pop_up_impianto_close(toClose) {

    $('#responseInterferenze').width('0px');
    $('#responseInterferenze').html('');
    if (toClose != null)
        $(toClose).dialog("close");

    //elimino lo shape
    if (selectedShape != undefined)
        selectedShape.setMap(null);

}



/*******************************************************************/
/********************* DOCUMENT READY ******************************/
/*******************************************************************/
$(document).ready(function () {

    //    $("#arrow").on("click", function () {
    $(document).on("click", "#arrow", function () {
        $('#pop_up_sup_app_modifica').val($("#pop_up_sup_google_modifica").val());
    });


    InizializzaMenuCosaDisegno();



    //$.logThis("$(document).ready");

    $(document).on("click", ".jstree-clicked", function () {
        //    $(".jstree-clicked").on("click", function () {
        //$.logThis("live click jstree-clicked");
        var id = $(this).attr('id');
        id = id.substring(1);
        id = id.replace(/\\/g, '\\\\');

        $.logThis('id: ' + id);


        selezioneDaIdAlbero(id, false);
    });

    $('#select_poligono').click(function () {
        ClearSelect($(this));
    });
    $('#disenga_poligono').click(function () {
        ClearSelect($(this));
    });
    $('#select_poligono').click(function () {
        ClearSelect($(this));
    });
    $('#delete-button').click(function () {
        ClearSelect($(this));
    });
    $('#save-button').click(function () {
        ClearSelect($(this));
    });
    $('#import-button').click(function () {
        ClearSelect($(this));
    });
    $('#export-button').click(function () {
        ClearSelect($(this));
    });
    $('#righello-button').click(function () {
        ClearSelect($(this));
    });
    $('#info_appezzamento').click(function () {
        ClearSelect($(this));
    });


    //àààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààà
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/IsSementieri",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json",
        success: function (msg) {
            if (msg.d == "true")
            { isSementi = true; }
            else
            { isSementi = false; }


        },
        error: function (xhr, ajaxOptions, thrownError) {
            isSementi = false;
            alert(xhr.status);
            alert(thrownError);
        }
    });


    var p = $("#map").offset();
    h = ($("#map").height() + p.top);
    w = ($("#map").width() + p.left);

    maxH = $("#map").height();

    InizializzaDatepicker();

    if (isSementi == false) {
        $('#pop_up_finalita').datepicker({
            dateFormat: 'dd/mm/yy',
            disabled: false,
            changeMonth: true,
            changeYear: true
        });

        $('#pop_up_disciplinare').datepicker({
            dateFormat: 'dd/mm/yy',
            disabled: false,
            changeMonth: true,
            changeYear: true
        });
        $.datepicker.regional['it'];
    }

    initialize();

    PosizionaTool();
    PosizionaRicercaIndirizzo();
    //àààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààààà

    $('.bottone').button();
    $('#CercaIndirizzo').click(function () {
        $('#NascondiMarkerIndirizzo').show();
    });
    $('#NascondiMarkerIndirizzo').click(function () {
        $('#NascondiMarkerIndirizzo').hide();
    });

    $('#aggiorna_date').click(function () {
        var limite_inferiore = $('input[name=limite_inferiore]:checked').val();
        var limite_superiore = $('input[name=limite_superiore]:checked').val();


        $.ajax({
            type: "POST",
            url: indirizzohttp + "/AggiornaFinestraTemporale",
            data: "{da: '" + $('#limita_data_da').val() + "', limite_inferiore:'" + limite_inferiore + "', a: '" + $('#limita_data_a').val() + "', limite_superiore: '" + limite_superiore + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                if (msg.d == 'ok') {
                    $('#AggiornaFiltro').click();
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#WaitFrame').hide();
                alert(xhr.status);
                alert(thrownError);
            }
        });
    });



    $("#espandi_contenuti").click(function () {
        clickPiu();
    });
    $("#espandi_indirizzo").click(function () {
        clickPiu_Indirizzi();
    });
    $("#gestisci_layer_principale").click(function () {
        GestisciLayerPrincipale();
    });
    $("#gestisci_dettagli_layer").click(function () {
        GestisciLayerDettagli();
    });

    $("#tipologia_layer").change(function () {
        AggiornaElencoTipologie();
    });

    /* -- popup Salvatagggio */
    $('#pop_up_impianto_azienda').change(function () {
        CaricaCentroAziendale();
    });

    $('#pop_up_specie').change(function () {
        response_ok = 4;
        if (isSementi == false) {
            CaricaDateDefaultDaVegCod("#pop_up_data_inizio", "#pop_up_data_fine");
        }
        CaricaDisciplinare();

        var Veg_Cod = $('#pop_up_specie').val();
        CaricaTipologia(Veg_Cod, "#pop_up_tipologia", "");

        CaricaVarieta("#pop_up_varieta", '');
        CaricaFinalita("#pop_up_finalita", '');

    });

    $('#pop_up_specie_modifica').change(function () {
        response_ok = 4;
        //            CaricaDisciplinare();

        var Veg_Cod = $('#pop_up_specie_modifica').val();
        CaricaTipologia(Veg_Cod, "#pop_up_tipologia_modifica", "");

        CaricaVarieta("#pop_up_varieta_modifica", '');
        CaricaFinalita("#pop_up_finalita_modifica", '');

    });

    $('#pop_up_d_semina').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });

    $('#pop_up_d_raccolta').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });
    $.datepicker.regional['it'];

    /*POP UP */
    $("#pop_up_impianto").dialog({
        autoOpen: false,
        height: maxH / 2,
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        close: function (event, ui) {
            pop_up_impianto_close(null);
        },
        buttons: {
            "Salva Nuovo Elemento": function () {
                InviaDatiNuovoImpianto();
            },
            "Annulla": function () {
                pop_up_impianto_close(this);
            }
        }
    });

    $("#pop_up_modificaImpianto").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Modifica Impianto": function () {
                ModificaImpianto();
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogRateo").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Conferma": function () {
                pfRateo();
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogGeneraPlanning").dialog({
        autoOpen: false,
        open: function () { GeneraDescrizionePlanning(); },
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Verifica Aggregazione Poligono": function () {
                clickGeneraPlanning(true);
            }, "Conferma": function () {
                clickGeneraPlanning(false);
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogMultipoint").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Conferma": function () {
                ConfermaSalvataggioMultipoint();
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogAB").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Conferma": function () {
                ConfermaSalvataggioAB();
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogAllertOperazioniAppezza").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: '300',
        modal: true,
        buttons: {
            "Avanti": function () {

                var area = getArea();

                if ($('#dialogAllertOperazioni_hidden').val() == 1) {
                    salvataggioDirettoConAppezza(area);
                }
                else {
                    ModificaDatiImpianto();
                    salvataggioDirettoConAppezza(area);
                    $('#pop_up_modificaImpianto').dialog('close');
                }
                $(this).dialog("close");
            },
            "Annulla": function () {
                alert('Impianto e Appezzamento non Modificati');
                AggiornaTutto();
                $(this).dialog("close");
            }
        }
    });

    $("#dialogAllertOperazioni").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: '300',
        modal: true,
        buttons: {
            "Avanti": function () {
                var area = getArea();
                if ($('#dialogAllertOperazioni_hidden').val() == 1) {
                    salvataggioDiretto(area);
                }
                else {
                    ModificaDatiImpianto();
                    salvataggioDiretto(area);
                    $('#pop_up_modificaImpianto').dialog('close');
                }
                $(this).dialog("close");
            },
            "Annulla": function () {
                alert('Impianto non Modificato');
                AggiornaTutto();
                $(this).dialog("close");
            }
        }
    });

    $("#dialogConfermaAssociazione").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: '300',
        modal: true,
        buttons: {
            "Avanti": function () {

                if ($('#option_associa').val() == '1') {
                    //posso fare il semplice salvataggio dei dati senza modificare la superficie
                    salvataggioDiretto('');
                }
                else {

                    area = getArea();

                    if ($('#option_associa').val() == '2') {
                        //voglio associare la superficie solamente all'impianto
                        // devo controllare se ci sono delle operazioni registrate su questo impianto
                        ControllaSeEsistonoOperazioni(area);
                    }
                    else {
                        //voglio associare la superficie a impianto e appezzamento
                        //devo controllare se ci sono operazione registrate sull'impianto e se l'appezzamento ha collegato il catasto
                        ControllaSeEsisteCatasto(area);
                    }
                }
                $(this).dialog("close");
            }
        }
    });
    $("#pop_up_opAgenda").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_opAgenda_Preselezione").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogGestioneColoriLayer").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Conferma": function () {
                $('#dialogGestioneColoriLayer').dialog("close");
                ConfermaGestioneColoriLayer();

            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogSessioneScaduta").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        open: function (event, ui) { impostaRedirectStart(); }
    });

    $("#dialogEliminaImpianto").dialog({
        autoOpen: false,
        open: function () { dialogEliminaImpiantoOnOpen(); },
        height: 'auto',
        maxHeight: maxH,
        width: '300',
        modal: true,
        buttons: {
            "Elimina": function () {
                EliminaImpianto();
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_export_shape").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {
            "Chiudi": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_Ricette").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {
            "Chiudi": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_Catasto").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {
            "Chiudi": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_import_shape").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {

            "Annulla": function () {
                CiSonoVecchiDatiNonImportati = false;
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#pop_up_Ritaglia").dialog({
        autoOpen: false,
        height: centoH,
        width: centoW,
        modal: true,
        buttons: {
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });
    $("#dialogEliminaMultipoint").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        open: function (event, ui) { popup_nuova_azienda_open(); },
        buttons: {
            "Elimina": function () {
                EliminaMultipointSelezionati();
                //elimino lo shape salvato
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });
    $("#dialogEliminaImpiantoPuntiScomposti").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        open: function (event, ui) { popup_nuova_azienda_open(); },
        buttons: {
            "Elimina": function () {
                EliminaImpiantoPuntiScomposti();
                //elimino lo shape salvato
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#popup_nuova_azienda").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        open: function (event, ui) { popup_nuova_azienda_open(); },
        buttons: {
            "Salva Nuova Azienda": function () {
                InviaDatiNuovaAzienda();
                //elimino lo shape salvato
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#popup_nuovo_centro").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true,
        buttons: {
            "Salva Nuovo Centro": function () {
                InviaDatiNuovoCentro();
                //elimino lo shape salvato
            },
            "Annulla": function () {
                $(this).dialog("close");
                //elimino lo shape salvato
            }
        }
    });

    $("#dialogCultivarRicette").dialog({
        autoOpen: false,
        height: 'auto',
        maxHeight: maxH,
        width: 'auto',
        modal: true
    });

    $("#PopupNuovaImpresa-Button").click(function () {
        $('#popup_nuova_azienda').dialog("open");
    });

    $("#PopupNuovoSa-Button").click(function () {
        $('#popup_nuovo_centro').dialog("open");
    });

    $("#import-button").click(function () {
        var url = "../CaricaShape.aspx";
        if (CiSonoVecchiDatiNonImportati) {
            url = url + "?isFromAlert=1";
            $("#pop_up_import_shape").dialog({
                height: centoH_xs,
                width: centoW_xs
            });

        }
        else {
            $("#pop_up_import_shape").dialog({
                height: centoH,
                width: centoW
            });


        }

        $("#frameShape").attr("src", url);

        $("#pop_up_import_shape").dialog("open");
    });

    $("#nuova_ricetta").click(function () {
        clickRicetta();
    });

    $("#selectPerSpecie").click(function () {
        clickselectPerSpecie();
    });

    $("#ripartoCatasto-button").click(function () {
        catasto();
    });
    $("#nuova_agenda").click(function () {
        apriPreselezioneAgenda();
    });
    $("#ritaglio-edit-punti-gps-button").click(function () {
        editPunti();
    });

    $("#CopiaOggetto").click(function () {
        copiaIncolla();
    });

    $("#ritaglio-sfondo").click(function () {

        //map.setZoom(zoomRicercaIndirizzoxRitaglio);

        $('#WaitFrame').show();
        var Piva;

        var LatLong1;
        var LatLong2;

        var bounds = map.getBounds();
        //        alert(bounds);
        var AmaxX = bounds.getSouthWest().lng().toString();
        var AmaxY = bounds.getNorthEast().lat().toString();
        var AminX = bounds.getNorthEast().lng().toString();
        var AminY = bounds.getSouthWest().lat().toString();

        //controllo la chiave dell'albero selezionata

        var Entita_Cod = "";
        Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();

        if (Entita_Cod == "") {
            alert("selezionare un centro aziendale a cui associare il ritaglio della mappa");
            $('#WaitFrame').hide();
            return false;
        }

        if (Entita_Cod.split("§")[0] != "3") {
            alert("selezionare il centro aziendale");
            $('#WaitFrame').hide();
            return false;
        }


        $.ajax({
            type: "POST",
            url: indirizzohttp + "/getUrlRitaglio",
            data: "{AmaxX: '" + AmaxX + "', AmaxY: '" + AmaxY + "', AminX: '" + AminX + "', AminY: '" + AminY + "', Entita_Cod: '" + Entita_Cod + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                if (msg.d == 'errore') {
                    alert("Selezionare un'azienda");
                }
                else {
                    //                    window.open(msg.d, "", "scrollbars=yes,resizable=yes,width=" + centoW + ",height=" + centoH + ",top=" + 0 + ",left=" + 0);
                    alert('ritaglio di mappa associato al centro aziendale');
                    $('#WaitFrame').hide();
                    //                    $("#frameRitaglia").attr("src", msg.d);
                    //                    $('#pop_up_Ritaglia').dialog("open");
                    //                    $('#pop_up_Ritaglia').parent().appendTo($('form:first'));

                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#WaitFrame').hide();
                alert(xhr.status);
                alert(thrownError);
            }
        });
    });

    $("#nuovapiva-button").click(function () {
        $('#WaitFrame').show();
        $.ajax({
            type: "POST",
            url: indirizzohttp + "/GetRandomPiva",
            data: "{ }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                $('#WaitFrame').hide();
                if (msg.d == 'SessioneScaduta') {
                    $('#dialogSessioneScaduta').dialog("open");
                }
                else {
                    $('#txt_Piva').val(msg.d);

                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#WaitFrame').hide();
                alert(xhr.status);
                alert(thrownError);
            }
        });
    });

    $("#righelloSpecie").click(function () {
        verificaInterferenze("VerificaInterferenze");
    });

    $("#righelloCampoVicino").click(function () {
        verificaInterferenze("MostraCampoPiuVicino");
    });

    $("#export-button").click(function () {

        var Entita_Cod = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString();
        var ePiva = "";
        var eSa_cod = "-1";
        var eApp = Entita_Cod.split("§")

        if (eApp[0] == "3") {

            ePiva = eApp[1];
            eSa_cod = eApp[2];

        }

        $("#pop_up_export_shape").dialog("open");
        $("#frameShapePF").attr("src", "../EsportaPF.aspx?piva=" + ePiva + "&sa_cod=" + eSa_cod);

    });
});




function verificaInterferenze(webService) {
    var Veg_Cod = $('#pop_up_specie').val()
    if (Veg_Cod == "") alert("selezionare una specie");
    else {

        var hiddenPunti_Nuovo = $('#hiddenPunti_Nuovo').val();
        var myData_Inizio = $('#pop_up_data_inizio').val();
        var myData_Fine = $('#pop_up_data_fine').val();
        var azienda_selezionata = $('#pop_up_impianto_azienda').val();
        var pop_up_tipologia = $('#pop_up_tipologia').val();

        $('#WaitFrame').show();

        $.ajax({
            type: "POST",
            url: indirizzohttp + "/" + webService,
            data: "{ veg_cod: '" + Veg_Cod + "', grva_cod:'" + pop_up_tipologia + "', data_inizio: '" + myData_Inizio + "', data_fine: '" + myData_Fine + "', hiddenPunti_Nuovo: '" + hiddenPunti_Nuovo + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {

                $('#WaitFrame').hide();
                if (msg.d == 'SessioneScaduta') {
                    $('#dialogSessioneScaduta').dialog("open");
                }
                else {

                    $('#responseInterferenze').html(msg.d);
                    $('#responseInterferenze').width('300px');
                    $('#pop_up_impianto').width($('#pop_up_impianto').width() + 20);
                    //$('#pop_up_specie').html(msg.d);
                }

            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#WaitFrame').hide();
                alert(xhr.status);
                alert(thrownError);
            }
        });
    }

}


function exportConfirm() {
    var id_agenda = 21720;
    var id_formato = $('#cmbFormatoExport').val();
    var filename = "";
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/EsportaShp",
        data: "{ id_agenda: '" + id_agenda + "', filename: '" + filename + "', id_formato: '" + id_formato + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#txt_linkScaricaShape').html(msg.d);

            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


/*************X SHJAPE **************/
function ChiudiImportaShape() {
    $("#pop_up_import_shape").dialog("close");
}

function NascondiRighelloSpecie() {
    $('#righelloSpecie').hide();
}

function InizializzaDatepicker() {

    var appDatiTipologia;
    var appData_Inizio_Fine;

    appDatiTipologia = $('#DatiTipologia').html();
    appData_Inizio_Fine = $('#Dati_data_inizio_fine').html();

    $('#DatiTipologia').html('');
    $('#placeTipologia').append(appDatiTipologia);

    $('#Dati_data_inizio_fine').html('')
    $('#placeData_Inizio_Fine').append(appData_Inizio_Fine);

    $('#pop_up_data_inizio').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });

    $('#pop_up_data_fine').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });

    $('#pop_up_m_data_inizio').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });

    $('#pop_up_m_data_fine').datepicker({
        dateFormat: 'dd/mm/yy',
        disabled: false,
        changeMonth: true,
        changeYear: true
    });
    $.datepicker.regional['it'];


    //se sono in modalità sementi

    if (isSementi == true) {

        $('#pop_up_m_data_inizio').val(data_inizio_sportello);
        $('#pop_up_m_data_fine').val(data_fine_sportello);

        $('#pop_up_data_fine').val(data_fine_sportello);
        var m = new Date();
        var month = m.getMonth() + 1
        var day = m.getDate()
        var year = m.getFullYear()
        $('#pop_up_data_inizio').val(day + "/" + month + "/" + year);

    }
}


//inizializzazione da server
function InizializzaProprietajs(serverLeggiDatiGIASAlarm, serverSementieri, iSementieri_Sportello_Configurazione_cod, serverCiSonoVecchiDatiNonImportati, serverAbilitaPF) {
    AggiornaDatiGiasAlarm = serverLeggiDatiGIASAlarm;
    isSementi = serverSementieri;
    Sementieri_Sportello_Configurazione_cod = iSementieri_Sportello_Configurazione_cod;
    CiSonoVecchiDatiNonImportati = serverCiSonoVecchiDatiNonImportati;
    AbilitaPF = serverAbilitaPF;


    $.logThis("InizializzaProprietajs (inizializzazione da server) ");
    $.logThis("AggiornaDatiGiasAlarm = " + AggiornaDatiGiasAlarm.toString());
    $.logThis("isSementi = " + isSementi.toString());
    $.logThis("Sementieri_Sportello_Configurazione_cod = " + Sementieri_Sportello_Configurazione_cod.toString());
    $.logThis("CiSonoVecchiDatiNonImportati = " + CiSonoVecchiDatiNonImportati.toString());
    $.logThis("AbilitaPF = " + AbilitaPF.toString());


    if (CiSonoVecchiDatiNonImportati) {
        BlinkFast($('#import-button'));
        $("#import-button").click();
    }


    $.logThis("abilitaPF - " + AbilitaPF);
    if (!AbilitaPF) {
        $('#nuova_ricetta').hide();
        $('#PianoRateoVariabile').hide();
        $('#ab-button').hide();
        $('#img_tool').hide();
        $('#scala_colori_contenitore').hide();

    }


    //    if (isSementi) {
    //        $('#CopiaOggetto').hide();
    //        $('#GeneraPlanning').hide();
    //        $('#selectPerSpecie').hide();
    //        //$('#import-button').hide();
    //        $('#export-button').hide();
    //        $('#nuova_ricetta').hide();
    //        $('#img_tool').hide();
    //        $('#ripartoCatasto-button').hide();
    //        $('#scala_colori_contenitore').hide();
    //        $('#PianoRateoVariabile').hide();

    //        $('#divEliminaEntitaGIAS').show();

    //    }
    //    else {
    //        $('#divEliminaEntitaGIAS').show();
    //        //$('#divEliminaEntitaGIAS').hide();
    //    }


}


function MostraNascondiPulsanti(bool_catasto, bool_precision, bool_esportazione) {
    if (bool_catasto == 'False') {
        $('#ripartoCatasto-button').hide();
    }
    else
    { $('#ripartoCatasto-button').show(); }

    if (bool_precision == 'False') {
        $('#ab-button').hide();
        $('#nuova_ricetta').hide();
        $('#img_tool').hide();
        $('#PianoRateoVariabile').hide();
        $('#GeneraPlanning').hide();
        $('#divEliminaPrecision').hide();

        $('#divEliminaPrecision').hide();
        $('#divEliminaPrecisionAB').hide();
    }
    else {
        $('#ab-button').show();
        $('#nuova_ricetta').show();
        $('#img_tool').show();
        $('#PianoRateoVariabile').show();
        $('#GeneraPlanning').show();

        $('#divEliminaPrecision').show();
        $('#divEliminaPrecisionAB').show();
    }

    if (bool_esportazione == 'False')
    { $('#export-button').hide(); }
    else
    { $('#export-button').show(); }

}

function ImpostaVisibilitaPulsanti(nuovo, salva, elimina, esporta, importa, ab) {

    gNuovo = nuovo;

    if (nuovo)
        $('#disenga_poligono').show();
    else
        $('#disenga_poligono').hide();

    if (salva)
        $('#save-button').show();
    else
        $('#save-button').hide();

    if (elimina)
        $('#delete-button').show();
    else
        $('#delete-button').hide();

    if (importa)
        $('#import-button').show();
    else
        $('#import-button').hide();

    if (esporta)
        $('#export-button').show();
    else
        $('#export-button').hide();

    if (ab)
        $('#ab-button').show();
    else
        $('#ab-button').hide();
}



function GestisciLayerDettagli() {
    $('#WaitFrame').show();

    $('#hiddenPrincipale_1_Dettagli_2').val(2);


    $.ajax({
        type: "POST",
        url: indirizzohttp + "/Carica_ddlTipologiaLayerDettagli",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#dialogGestioneColoriLayer').dialog("open");
                if (msg.d.toString() != '') {
                    $("#ddlTipologiaLayer").html(msg.d);
                    Caricaplace_tabella_Dettagli($("#ddlTipologiaLayer").val());
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function Caricaplace_tabella_Dettagli(valoreSelezionato) {
    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/Caricaplace_tabella_Dettagli",
        data: "{ valoreSelezionato: '" + valoreSelezionato + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d.toString() != '') {
                    $("#place_tabella").html(msg.d);
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}






function Cambia_ddlTipologiaLayer() {
    //    Caricaplace_tabella_Dettagli($("#ddlTipologiaLayer").val());
    Caricaplace_tabella($("#ddlTipologiaLayer").val());
}



function GestisciLayerPrincipale() {
    $('#WaitFrame').show();

    $('#hiddenPrincipale_1_Dettagli_2').val(1);


    $.ajax({
        type: "POST",
        url: indirizzohttp + "/Carica_ddlTipologiaLayer",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#dialogGestioneColoriLayer').dialog("open");
                if (msg.d.toString() != '') {
                    $("#ddlTipologiaLayer").html(msg.d);
                    Caricaplace_tabella($("#ddlTipologiaLayer").val());
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function Caricaplace_tabella(valoreSelezionato) {
    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/Caricaplace_tabella",
        data: "{ valoreSelezionato: '" + valoreSelezionato + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();

            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                if (msg.d.toString() != '') {
                    $("#place_tabella").html(msg.d);
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}




function AggiornaElencoTipologie() {

    var Layer_Selezionato;
    Layer_Selezionato = $('#tipologia_layer').val();
    //alert("l:" + Layer_Selezionato);

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/AggiornaElencoTipologie",
        data: "{ Layer_Selezionato: '" + Layer_Selezionato + "', Sementieri_Sportello_Configurazione_cod: '" + Sementieri_Sportello_Configurazione_cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {


                svuotaTutto();

                //reinizilaizzo i poligoni
                //                layers = eval('(' + msg.d + ')');

                layers = JSON.parse(msg.d);

                ImpostaLayer();
                makeToolBar();

                AggiornaLayer();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}


function svuotaTutto_nuoviVettori() {
    var i;

    if (MarkGps !== null) {
        if (MarkGps != undefined) {
            for (i = 0; i < MarkGps.length; i++) {
                MarkGps[i].setMap(null);
            }
        }
    }
    MarkGps = new Array();



    if (Livelli !== null) {
        if (Livelli != undefined) {
            for (i = 0; i < Livelli.length; i++) {
                for (var kk = 0; kk < Livelli[i].poligoni.length; kk++) {
                    Livelli[i].poligoni[kk].setMap(null);
                }
                for (var kk = 0; kk < Livelli[i].punti.length; kk++) {
                    Livelli[i].punti[kk].setMap(null);
                }
                for (var kk = 0; kk < Livelli[i].polyline.length; kk++) {
                    Livelli[i].polyline[kk].setMap(null);
                }
                for (var kk = 0; kk < Livelli[i].ABLabel.length; kk++) {
                    Livelli[i].ABLabel[kk].setMap(null);
                }

                Livelli[i].poligoni = new Array();
                Livelli[i].punti = new Array();
                Livelli[i].polyline = new Array();
                Livelli[i].ABLabel = new Array();
            }
        }
    }
}
function svuotaTutto() {

    for (var i = 0; i < Livelli.length; i++) {
        for (var kk = 0; kk < Livelli[i].poligoni.length; kk++) {
            Livelli[i].poligoni[kk].setMap(null);
        }
        for (var kk = 0; kk < Livelli[i].punti.length; kk++) {
            Livelli[i].punti[kk].setMap(null);
        }
        for (var kk = 0; kk < Livelli[i].polyline.length; kk++) {
            Livelli[i].polyline[kk].setMap(null);
        }
        for (var kk = 0; kk < Livelli[i].ABLabel.length; kk++) {
            Livelli[i].ABLabel[kk].setMap(null);
        }
    }

}


//#region "per sessione"
var sec = 7;
var cdID;

function impostaRedirect() {
    var m = "<p>Pagina di login ... (" + sec.toString() + ")</p>";
    $('#lblAutoLogin').html(m);
    if (sec == 0) {
        window.location = "../GST_Autenticazione/Autenticazione.aspx";
        window.clearInterval(cdID);
    }

    --sec;

}

function impostaRedirectStart() {
    cdID = window.setInterval('impostaRedirect();', 1000);
}

//# end region "per sessione"


function coordinateFromViaCentro() {
    var Layer_Selezionato;
    Layer_Selezionato = $('#tipologia_layer').val();
    $.ajax({
        type: "POST",
        url: indirizzohttp + "/coordinateFromViaCentro",
        data: "{}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $('#address').val(msg.d);
                $('#CercaIndirizzo').click();
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}


function AggiornaLayer() {
    if (Livelli !== null)
        svuotaTutto_nuoviVettori();

    var Layer_Selezionato;
    Layer_Selezionato = $('#tipologia_layer').val();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/AggiornaLayer",
        data: "{ Layer_Selezionato: '" + Layer_Selezionato + "', AggiornaDatiGiasAlarm: '" + AggiornaDatiGiasAlarm.toString() + "', Sementieri_Sportello_Configurazione_cod: '" + Sementieri_Sportello_Configurazione_cod.toString() + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $.logThis("AggiornaLayer");
                if (msg.d == "[]") {
                    //mi posiziono sul centro dell'indirizzo
                    coordinateFromViaCentro();
                    $('#WaitFrame').hide();
                }
                else {

                    var start;
                    var diff;

                    start = (new Date).getTime();

                    //parte core: popolo oggetto place da lettura server.
                    //$.logThis(msg.d);
                    place = JSON.parse(msg.d);

                    diff = (new Date).getTime() - start;
                    $.logThis("spacchetta= " + diff + ")");









                    var l_place = place.length;
                    var l_livelli = Livelli.length;
                    start = (new Date).getTime();
                    ImpostaShape(true);
                    diff = (new Date).getTime() - start;
                    $.logThis("tutto impostashape= " + diff + ")");


                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
};


//#region "Operazioni Agenda"

function apriPreselezioneAgenda() {

    var Entita_Cod;
    Entita_Cod = getEntitaCod();

    if (Entita_Cod == "") {
        alert("Nessun elemento selezionato");
        return "true";
    }

    if (Entita_Cod.split(separatoreChiaveAlbero)[25] != "0") {
        preselezioneAgenda("0");
    } else {
        apriPreselezioneAgenda();
    }


}



function apriPreselezioneAgenda() {

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/ElencoOperazioniAgendaGraficabili",
        data: "",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                if (!startsWith(msg.d, '<')) {
                    alert(msg.d);
                } else {
                    $.logThis("#contentpop_up_opAgenda_Preselezione = " + msg.d);
                    $("#contentpop_up_opAgenda_Preselezione").html(msg.d);
                    $("#pop_up_opAgenda_Preselezione").dialog("open");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });


}
function getEntitaCod() {
    //selezione multipla --> ok passo alla ricetta
    var listaImpiantiDaChiaveAlbero = $("#ChiaveAlberoMultiSelezione").val();
    if (listaImpiantiDaChiaveAlbero != "") {
        $.logThis("ChiaveAlberoMultiSelezione: " + listaImpiantiDaChiaveAlbero);
        listaImpiantiDaChiaveAlbero = listaImpiantiDaChiaveAlbero.substring(0, listaImpiantiDaChiaveAlbero.length - 2);
        Entita_Cod = listaImpiantiDaChiaveAlbero;
    }
    else {


        Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();       


    }

    return Entita_Cod;
}


function preselezioneAgenda(lav_cod) {

    var Entita_Cod = "";
    Entita_Cod = getEntitaCod();

    if (Entita_Cod == "") {
        alert("Nessun Elemento selezionato");
        return true;
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/clickOpAgenda",
        data: "{ lav_cod: '" + lav_cod + "', ChiaveAlbero: '" + Entita_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                if (startsWith(msg.d, 'errore')) {
                    alert(msg.d);
                } else {
                    $("#framepop_up_opAgenda").attr("src", "about:blank");
                    $("#framepop_up_opAgenda").attr("src", msg.d);
                    $.logThis("redir to: " + msg.d);
                    $("#pop_up_opAgenda").dialog("open");
                    $("#pop_up_opAgenda_Preselezione").dialog("close");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

function chiudiFinestra(id) {
    $(id).dialog("close");
}


//#end region "Operazioni Agenda"



//#region "gestione multipoint"

var A_Multipoint = new Array();
var iLast = 0;

function addMarkerMultiPointModifica(codice, posizione) {
    $("#hiddenMultipointModifica").val($("#hiddenMultipointModifica").val() + codice + '^' + posizione + '§');
}


function addMarkerMultiPoint(obj, hiddenMultipoint, A, posizione) {

    if (obj.is(":checked")) {

        if (A == null) {
            $.logThis("crea nuovo multipoint a:");
            A = new google.maps.Marker({
                position: posizione,
                map: map,
                draggable: true
            });
        }
        else {
            A.draggable = true;
        }
        A_Multipoint.push(A);
        hiddenMultipoint.val(hiddenMultipoint.val() + '(' + A_Multipoint[iLast].getPosition().lat() + ', ' + A_Multipoint[iLast].getPosition().lng() + ')|');

        $.logThis("aggiunto: hiddenMultipoint.val" + hiddenMultipoint.val());

        iLast = iLast + 1;
    }

}

function ConfermaSalvataggioMultipoint() {
    $('#WaitFrame').show();

    var hiddenPunti_M = $('#hiddenMultipoint').val();
    var txtDialogMultipointDes = $("#txtDialogMultipointDes").val();


    //    $.logThis('M = ' + hiddenPunti_M);

    //se sono tutte valorizzate allora posso procedere
    var blocca = false;

    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString(); //.replace(/\\/g, '\\\\'); ;


    //$.logThis(ChiaveAlbero);

    //se sono tutte valorizzate allora posso procedere
    if (ChiaveAlbero == "") {
        alert("nessun Elemento selezionato.");
        $('#WaitFrame').hide();
        return false;
    }

    if (blocca) {
        alert("completare i campi obbligatori");
        $('#WaitFrame').hide();
        return false;
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/SalvaNuovoMultipoint",
        data: "{ chiaveAlbero: '" + ChiaveAlbero + "', hiddenPunti_M: '" + hiddenPunti_M + "', txtDialogMultipointDes: '" + txtDialogMultipointDes + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {

            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $.logThis("SalvaNuovoMultipoint, valore restituito: " + msg.d);
                if (msg.d.split(".")[0] == 'Operazione eseguita correttamente') {
                    $("#dialogMultipoint").dialog("close");
                    $('#hiddenMultipoint').val('');
                    for (var i = 0; i < A_Multipoint.length; i++) {
                        A_Multipoint[i].setMap(null);
                    }
                    AggiornaTutto();
                }
                else {
                    alert(msg.d);
                }
            }

        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

//# end region "gestione multipoint"


//#region "utils "


function isNuovoElemento() {
    var rval = true;
    if (selectedShape != undefined)
        rval = (selectedShape.html == undefined);

    return rval
}

//#end region "utils "