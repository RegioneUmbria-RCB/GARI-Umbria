﻿
//#region Rateo

function pfRateo() {


    var ChiaveAlbero = $("#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica").val().toString(); //.replace(/\\/g, '\\\\'); ;
    var noSel = "Nessuna ricetta selezionata.";

    if (ChiaveAlbero == "") {
        alert(noSel);
        return false;
    }

    var sChiaveAlbero = ChiaveAlbero.split(separatoreChiaveAlbero)[0];
    var sRicettaOperazioneCod = ChiaveAlbero.split(separatoreChiaveAlbero)[28];

    if (!(sChiaveAlbero == "a60" || sChiaveAlbero == "60")) {
        alert(noSel);
        return false;
    }

    if (sRicettaOperazioneCod == 0) {
        alert(noSel);
        return false;
    }


    $('#WaitFrame').show();


    $.ajax({
        type: "POST",
        url: indirizzohttp + "/pfRateo",
        data: "{ ChiaveAlbero: '" + ChiaveAlbero + "', cellsize: '" + $("#txtCellSize").val() + "'  }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            $("#dialogRateo").dialog("close");
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                if (msg.d == "True")
                    alert("Piano creato, è necessario fare click sul pulsante aggiorna filtri per vederlo.");
                else
                    alert("Si è verificato un problema durante la creazione. - " + msg.d);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            alert(xhr.status);
            alert(thrownError);
        }
    });

}

//#end region Rateo

//#region gestione planning da impianti
function GeneraDescrizionePlanning() {
    //selezione multipla --> ok passo a generazione planning
    var listaImpiantiDaChiaveAlbero = $("#ChiaveAlberoMultiSelezione").val();
    if (listaImpiantiDaChiaveAlbero != "") {
        listaImpiantiDaChiaveAlbero = listaImpiantiDaChiaveAlbero.substring(0, listaImpiantiDaChiaveAlbero.length - 2);
        GeneraDescrizionePlanning_final(listaImpiantiDaChiaveAlbero);
        return true;
    }

    var Entita_Cod = "";
    Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();
    $("#hidCultivarRicetteNodoPartenza").val($('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString());

    if (Entita_Cod != "") {
        GeneraDescrizionePlanning_final(Entita_Cod);
        return true;
    }

    alert("nessun elemento selezionato.");
}


function GeneraDescrizionePlanning_final(Entita_Cod) {

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/GeneraDescrizionePlanning",
        data: "{ ChiaveAlbero: '" + Entita_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                $("#txtNomePlanning").val(msg.d);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function clickGeneraPlanningT() {
    clickGeneraPlanning(true);
}

function clickGeneraPlanning(isTest) {
    //selezione multipla --> ok passo a generazione planning
    var listaImpiantiDaChiaveAlbero = $("#ChiaveAlberoMultiSelezione").val();
    if (listaImpiantiDaChiaveAlbero != "") {
        listaImpiantiDaChiaveAlbero = listaImpiantiDaChiaveAlbero.substring(0, listaImpiantiDaChiaveAlbero.length - 2);
        if (isTest)
            clickGeneraPlanning_Test(listaImpiantiDaChiaveAlbero);
        else
            clickGeneraPlanning_Final(listaImpiantiDaChiaveAlbero);
        return true;
    }

    var Entita_Cod = "";
    Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();
    $("#hidCultivarRicetteNodoPartenza").val($('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString());

    if (Entita_Cod != "") {
        if (isTest)
            clickGeneraPlanning_Test(Entita_Cod);
        else
            clickGeneraPlanning_Final(Entita_Cod);
        return true;
    }

    alert("nessun elemento selezionato.");
}

function clickGeneraPlanning_Test(Entita_Cod) {

    var AggregaGrafica = "0"
    AggregaGrafica = $("#txtAggregaEntitaGrafichePerPianificazioneScartoM").val();

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/clickVerificaCartografiaAggregatoDaChiaveAlbero",
        data: "{ ChiaveAlbero: '" + Entita_Cod + "', AggregaGrafica: '" + AggregaGrafica + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {
                alert(msg.d);
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });
}

function clickGeneraPlanning_Final(Entita_Cod) {

    var AggregaGrafica = "-1"
    if ($("#ckAggregaEntitaGrafichePerPianificazione").is(":checked")) {
        AggregaGrafica = $("#txtAggregaEntitaGrafichePerPianificazioneScartoM").val();
    }

    var Programmazione_Des = $("#txtNomePlanning").val();

    $('#WaitFrame').show();

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/clickGeneraPlanning",
        data: "{ Programmazione_Des: '" + Programmazione_Des + "', ChiaveAlbero: '" + Entita_Cod + "', AggregaGrafica: '" + AggregaGrafica + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                if (startsWith(msg.d, 'errore')) {
                    alert(msg.d);
                } else {
                    $.logThis("redir to: " + msg.d);
                    alert(msg.d);
                    $("#dialogGeneraPlanning").dialog("close");
                    if ($('#AggiornaFiltro').length > 0) {
                        $('#AggiornaFiltro').click();
                    }
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });
}
//#end gestione planning



//#region selezione per appezzamenti con impianti di specie omogenea

function clickselectPerSpecie() {

    var Entita_Cod = "";
    Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();
    $("#hidCultivarRicetteNodoPartenza").val($('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString());

    if (Entita_Cod == "") {
        Entita_Cod = $("#hidCultivarRicetteNodoPartenza").val().toString();
        $("#hidCultivarRicetteNodoPartenza").val("");
    }

    var lista_cul_cod = collassaDatiTabella("#tblCultivarXRicette", "#hidCultivarRicette");
    if (lista_cul_cod == "-1" || lista_cul_cod == -1)
        lista_cul_cod = "";

    //se sono tutte valorizzate allora posso procedere
    if (Entita_Cod == "") {
        $.logThis("no imp = " + Entita_Cod);
        alert("nessun impianto selezionato.");
        return false;
    }

    ElencoImpiantiOmogenei(Entita_Cod, lista_cul_cod, "impianti");
}

function clickselectPerSpecie_final(Entita_Cod) {

    //selezione multipla
    var elementiAlbero = Entita_Cod.split("|");
    $.logThis("lll: " + elementiAlbero.length);

    clearSelectionBoth();

    for (var i = 0; i < elementiAlbero.length; i++)
        selezioneDaIdAlbero(elementiAlbero[i], true);
}

function ElencoImpiantiOmogenei(Entita_Cod, lista_cul_cod, dialogDaMostrare) {

    var splitted = Entita_Cod.split(separatoreChiaveAlbero);
    if (splitted[5] != "0") {
        clickRicetta_Final(Entita_Cod);
    }
    else {

        $('#WaitFrame').show();

        $.ajax({
            type: "POST",
            url: indirizzohttp + "/PopolaDatiSpecie",
            data: "{ ChiaveAlbero: '" + Entita_Cod + "', lista_cul_cod: '" + lista_cul_cod + "', ckRibaltaGrafica: '" + $(ckRibaltaGrafica).is(":checked") + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                $('#WaitFrame').hide();
                if (msg.d == 'SessioneScaduta') {
                    $('#dialogSessioneScaduta').dialog("open");
                }
                else {

                    if (startsWith(msg.d, 'errore')) {
                        alert(msg.d);
                    } else {
                        if (startsWith(msg.d, '<')) {
                            $("#tblCultivarRicette").html(msg.d);

                            if (dialogDaMostrare == "ricette") {
                                $("#dialogCultivarRicette").dialog({ buttons: {
                                    "Procedi": function () {
                                        clickRicetta()
                                        $(this).dialog("close");
                                    },
                                    "Annulla": function () {
                                        $(this).dialog("close");
                                    }
                                }
                                });

                            }
                            else {

                                $("#dialogCultivarRicette").dialog({ buttons: {
                                    "Seleziona": function () {
                                        clickselectPerSpecie()
                                        $(this).dialog("close");
                                    },
                                    "Annulla": function () {
                                        $(this).dialog("close");
                                    }
                                }
                                });

                            }

                            $("#dialogCultivarRicette").dialog("open");
                        }
                        else {
                            lista_cul_cod = "";
                            $("#hidCultivarRicette").val("");
                            $("#tblCultivarXRicette").html("");

                            $.logThis("dialogDaMostrare:" + dialogDaMostrare);
                            if (dialogDaMostrare == "ricette") {
                                clickRicetta_Final(msg.d);
                            }
                            else {
                                clickselectPerSpecie_final(msg.d);
                            }


                        }
                    }
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#WaitFrame').hide();
                alert(xhr.status);
                alert(thrownError);
            }
        });
    }
}


//#end region selezione per appezzamenti con impianti di specie omogenea



//#region gesione ricette

function clickRicetta() {

    //selezione multipla --> ok passo alla ricetta
    var listaImpiantiDaChiaveAlbero = $("#ChiaveAlberoMultiSelezione").val();
    if (listaImpiantiDaChiaveAlbero != "") {
        $.logThis("ChiaveAlberoMultiSelezione: " + listaImpiantiDaChiaveAlbero);
        listaImpiantiDaChiaveAlbero = listaImpiantiDaChiaveAlbero.substring(0, listaImpiantiDaChiaveAlbero.length - 2);
        clickRicetta_Final(listaImpiantiDaChiaveAlbero);
        return true;
    }

    //selezione di un planning --> ok passso alla ricetta
    var Entita_Cod = "";
    Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();
    $("#hidCultivarRicetteNodoPartenza").val($('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString());

    if (startsWith(Entita_Cod, chiaveAlberoPlanning)) {
        clickRicetta_Final(Entita_Cod);
        return true;
    }

    var lista_cul_cod = collassaDatiTabella("#tblCultivarXRicette", "#hidCultivarRicette");
    if (lista_cul_cod == "-1" || lista_cul_cod == -1)
        lista_cul_cod = "";


    if (Entita_Cod == "") {
        Entita_Cod = $("#hidCultivarRicetteNodoPartenza").val().toString();
        $("#hidCultivarRicetteNodoPartenza").val("");
    }

    //se sono tutte valorizzate allora posso procedere
    if (Entita_Cod == "") {
        $.logThis("no imp = " + Entita_Cod + " - lista cul cod " + lista_cul_cod);
        alert("nessun impianto selezionato.");
        return false;
    }

    $.logThis("cc = " + lista_cul_cod);

    ElencoImpiantiOmogenei(Entita_Cod, lista_cul_cod, "ricette");

}


function clickRicetta_Final(Entita_Cod) {
    //var Entita_Cod = $('#HiddenSelezioneAlberoAnagraficaAlberoAnagrafica').val().toString();  //.replace(/\\/g, '\\\\'); //selectedShape.chiavealbero.toString();
    //$.logThis(Entita_Cod);

    //se sono tutte valorizzate allora posso procedere
    if (Entita_Cod == "") {
        alert("nessun impianto selezionato.");
        return false;
    }

    $.ajax({
        type: "POST",
        url: indirizzohttp + "/clickRicetta",
        data: "{ ChiaveAlbero: '" + Entita_Cod + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            $('#WaitFrame').hide();
            if (msg.d == 'SessioneScaduta') {
                $('#dialogSessioneScaduta').dialog("open");
            }
            else {

                if (startsWith(msg.d, 'errore')) {
                    alert(msg.d);
                } else {
                    $("#frameRicette").attr("src", msg.d);
                    $.logThis("redir to: " + msg.d);
                    $("#pop_up_Ricette").dialog("open");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {
            $('#WaitFrame').hide();
            alert(xhr.status);
            alert(thrownError);
        }
    });

}
//#end region gestione ricette
